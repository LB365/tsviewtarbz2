(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}




var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log = F2(function(tag, value)
{
	return value;
});

var _Debug_log_UNUSED = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString(value)
{
	return '<internals>';
}

function _Debug_toString_UNUSED(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash_UNUSED(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.jl.kW === region.hJ.kW)
	{
		return 'on line ' + region.jl.kW;
	}
	return 'on lines ' + region.jl.kW + ' through ' + region.hJ.kW;
}



// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**_UNUSED/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**_UNUSED/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**/
	if (typeof x.$ === 'undefined')
	//*/
	/**_UNUSED/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0 = 0;
var _Utils_Tuple0_UNUSED = { $: '#0' };

function _Utils_Tuple2(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2_UNUSED(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3_UNUSED(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr(c) { return c; }
function _Utils_chr_UNUSED(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



var _List_Nil = { $: 0 };
var _List_Nil_UNUSED = { $: '[]' };

function _List_Cons(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons_UNUSED(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**_UNUSED/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap_UNUSED(value) { return { $: 0, a: value }; }
function _Json_unwrap_UNUSED(value) { return value.a; }

function _Json_wrap(value) { return value; }
function _Json_unwrap(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.kM,
		impl.mc,
		impl.l_,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**_UNUSED/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}




// HELPERS


var _VirtualDom_divertHrefToApp;

var _VirtualDom_doc = typeof document !== 'undefined' ? document : {};


function _VirtualDom_appendChild(parent, child)
{
	parent.appendChild(child);
}

var _VirtualDom_init = F4(function(virtualNode, flagDecoder, debugMetadata, args)
{
	// NOTE: this function needs _Platform_export available to work

	/**/
	var node = args['node'];
	//*/
	/**_UNUSED/
	var node = args && args['node'] ? args['node'] : _Debug_crash(0);
	//*/

	node.parentNode.replaceChild(
		_VirtualDom_render(virtualNode, function() {}),
		node
	);

	return {};
});



// TEXT


function _VirtualDom_text(string)
{
	return {
		$: 0,
		a: string
	};
}



// NODE


var _VirtualDom_nodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 1,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_node = _VirtualDom_nodeNS(undefined);



// KEYED NODE


var _VirtualDom_keyedNodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 2,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_keyedNode = _VirtualDom_keyedNodeNS(undefined);



// CUSTOM


function _VirtualDom_custom(factList, model, render, diff)
{
	return {
		$: 3,
		d: _VirtualDom_organizeFacts(factList),
		g: model,
		h: render,
		i: diff
	};
}



// MAP


var _VirtualDom_map = F2(function(tagger, node)
{
	return {
		$: 4,
		j: tagger,
		k: node,
		b: 1 + (node.b || 0)
	};
});



// LAZY


function _VirtualDom_thunk(refs, thunk)
{
	return {
		$: 5,
		l: refs,
		m: thunk,
		k: undefined
	};
}

var _VirtualDom_lazy = F2(function(func, a)
{
	return _VirtualDom_thunk([func, a], function() {
		return func(a);
	});
});

var _VirtualDom_lazy2 = F3(function(func, a, b)
{
	return _VirtualDom_thunk([func, a, b], function() {
		return A2(func, a, b);
	});
});

var _VirtualDom_lazy3 = F4(function(func, a, b, c)
{
	return _VirtualDom_thunk([func, a, b, c], function() {
		return A3(func, a, b, c);
	});
});

var _VirtualDom_lazy4 = F5(function(func, a, b, c, d)
{
	return _VirtualDom_thunk([func, a, b, c, d], function() {
		return A4(func, a, b, c, d);
	});
});

var _VirtualDom_lazy5 = F6(function(func, a, b, c, d, e)
{
	return _VirtualDom_thunk([func, a, b, c, d, e], function() {
		return A5(func, a, b, c, d, e);
	});
});

var _VirtualDom_lazy6 = F7(function(func, a, b, c, d, e, f)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f], function() {
		return A6(func, a, b, c, d, e, f);
	});
});

var _VirtualDom_lazy7 = F8(function(func, a, b, c, d, e, f, g)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g], function() {
		return A7(func, a, b, c, d, e, f, g);
	});
});

var _VirtualDom_lazy8 = F9(function(func, a, b, c, d, e, f, g, h)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g, h], function() {
		return A8(func, a, b, c, d, e, f, g, h);
	});
});



// FACTS


var _VirtualDom_on = F2(function(key, handler)
{
	return {
		$: 'a0',
		n: key,
		o: handler
	};
});
var _VirtualDom_style = F2(function(key, value)
{
	return {
		$: 'a1',
		n: key,
		o: value
	};
});
var _VirtualDom_property = F2(function(key, value)
{
	return {
		$: 'a2',
		n: key,
		o: value
	};
});
var _VirtualDom_attribute = F2(function(key, value)
{
	return {
		$: 'a3',
		n: key,
		o: value
	};
});
var _VirtualDom_attributeNS = F3(function(namespace, key, value)
{
	return {
		$: 'a4',
		n: key,
		o: { f: namespace, o: value }
	};
});



// XSS ATTACK VECTOR CHECKS
//
// For some reason, tabs can appear in href protocols and it still works.
// So '\tjava\tSCRIPT:alert("!!!")' and 'javascript:alert("!!!")' are the same
// in practice. That is why _VirtualDom_RE_js and _VirtualDom_RE_js_html look
// so freaky.
//
// Pulling the regular expressions out to the top level gives a slight speed
// boost in small benchmarks (4-10%) but hoisting values to reduce allocation
// can be unpredictable in large programs where JIT may have a harder time with
// functions are not fully self-contained. The benefit is more that the js and
// js_html ones are so weird that I prefer to see them near each other.


var _VirtualDom_RE_script = /^script$/i;
var _VirtualDom_RE_on_formAction = /^(on|formAction$)/i;
var _VirtualDom_RE_js = /^\s*j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:/i;
var _VirtualDom_RE_js_html = /^\s*(j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:|d\s*a\s*t\s*a\s*:\s*t\s*e\s*x\s*t\s*\/\s*h\s*t\s*m\s*l\s*(,|;))/i;


function _VirtualDom_noScript(tag)
{
	return _VirtualDom_RE_script.test(tag) ? 'p' : tag;
}

function _VirtualDom_noOnOrFormAction(key)
{
	return _VirtualDom_RE_on_formAction.test(key) ? 'data-' + key : key;
}

function _VirtualDom_noInnerHtmlOrFormAction(key)
{
	return key == 'innerHTML' || key == 'formAction' ? 'data-' + key : key;
}

function _VirtualDom_noJavaScriptUri(value)
{
	return _VirtualDom_RE_js.test(value)
		? /**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlUri(value)
{
	return _VirtualDom_RE_js_html.test(value)
		? /**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlJson(value)
{
	return (typeof _Json_unwrap(value) === 'string' && _VirtualDom_RE_js_html.test(_Json_unwrap(value)))
		? _Json_wrap(
			/**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		) : value;
}



// MAP FACTS


var _VirtualDom_mapAttribute = F2(function(func, attr)
{
	return (attr.$ === 'a0')
		? A2(_VirtualDom_on, attr.n, _VirtualDom_mapHandler(func, attr.o))
		: attr;
});

function _VirtualDom_mapHandler(func, handler)
{
	var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

	// 0 = Normal
	// 1 = MayStopPropagation
	// 2 = MayPreventDefault
	// 3 = Custom

	return {
		$: handler.$,
		a:
			!tag
				? A2($elm$json$Json$Decode$map, func, handler.a)
				:
			A3($elm$json$Json$Decode$map2,
				tag < 3
					? _VirtualDom_mapEventTuple
					: _VirtualDom_mapEventRecord,
				$elm$json$Json$Decode$succeed(func),
				handler.a
			)
	};
}

var _VirtualDom_mapEventTuple = F2(function(func, tuple)
{
	return _Utils_Tuple2(func(tuple.a), tuple.b);
});

var _VirtualDom_mapEventRecord = F2(function(func, record)
{
	return {
		bE: func(record.bE),
		gP: record.gP,
		gu: record.gu
	}
});



// ORGANIZE FACTS


function _VirtualDom_organizeFacts(factList)
{
	for (var facts = {}; factList.b; factList = factList.b) // WHILE_CONS
	{
		var entry = factList.a;

		var tag = entry.$;
		var key = entry.n;
		var value = entry.o;

		if (tag === 'a2')
		{
			(key === 'className')
				? _VirtualDom_addClass(facts, key, _Json_unwrap(value))
				: facts[key] = _Json_unwrap(value);

			continue;
		}

		var subFacts = facts[tag] || (facts[tag] = {});
		(tag === 'a3' && key === 'class')
			? _VirtualDom_addClass(subFacts, key, value)
			: subFacts[key] = value;
	}

	return facts;
}

function _VirtualDom_addClass(object, key, newClass)
{
	var classes = object[key];
	object[key] = classes ? classes + ' ' + newClass : newClass;
}



// RENDER


function _VirtualDom_render(vNode, eventNode)
{
	var tag = vNode.$;

	if (tag === 5)
	{
		return _VirtualDom_render(vNode.k || (vNode.k = vNode.m()), eventNode);
	}

	if (tag === 0)
	{
		return _VirtualDom_doc.createTextNode(vNode.a);
	}

	if (tag === 4)
	{
		var subNode = vNode.k;
		var tagger = vNode.j;

		while (subNode.$ === 4)
		{
			typeof tagger !== 'object'
				? tagger = [tagger, subNode.j]
				: tagger.push(subNode.j);

			subNode = subNode.k;
		}

		var subEventRoot = { j: tagger, p: eventNode };
		var domNode = _VirtualDom_render(subNode, subEventRoot);
		domNode.elm_event_node_ref = subEventRoot;
		return domNode;
	}

	if (tag === 3)
	{
		var domNode = vNode.h(vNode.g);
		_VirtualDom_applyFacts(domNode, eventNode, vNode.d);
		return domNode;
	}

	// at this point `tag` must be 1 or 2

	var domNode = vNode.f
		? _VirtualDom_doc.createElementNS(vNode.f, vNode.c)
		: _VirtualDom_doc.createElement(vNode.c);

	if (_VirtualDom_divertHrefToApp && vNode.c == 'a')
	{
		domNode.addEventListener('click', _VirtualDom_divertHrefToApp(domNode));
	}

	_VirtualDom_applyFacts(domNode, eventNode, vNode.d);

	for (var kids = vNode.e, i = 0; i < kids.length; i++)
	{
		_VirtualDom_appendChild(domNode, _VirtualDom_render(tag === 1 ? kids[i] : kids[i].b, eventNode));
	}

	return domNode;
}



// APPLY FACTS


function _VirtualDom_applyFacts(domNode, eventNode, facts)
{
	for (var key in facts)
	{
		var value = facts[key];

		key === 'a1'
			? _VirtualDom_applyStyles(domNode, value)
			:
		key === 'a0'
			? _VirtualDom_applyEvents(domNode, eventNode, value)
			:
		key === 'a3'
			? _VirtualDom_applyAttrs(domNode, value)
			:
		key === 'a4'
			? _VirtualDom_applyAttrsNS(domNode, value)
			:
		((key !== 'value' && key !== 'checked') || domNode[key] !== value) && (domNode[key] = value);
	}
}



// APPLY STYLES


function _VirtualDom_applyStyles(domNode, styles)
{
	var domNodeStyle = domNode.style;

	for (var key in styles)
	{
		domNodeStyle[key] = styles[key];
	}
}



// APPLY ATTRS


function _VirtualDom_applyAttrs(domNode, attrs)
{
	for (var key in attrs)
	{
		var value = attrs[key];
		typeof value !== 'undefined'
			? domNode.setAttribute(key, value)
			: domNode.removeAttribute(key);
	}
}



// APPLY NAMESPACED ATTRS


function _VirtualDom_applyAttrsNS(domNode, nsAttrs)
{
	for (var key in nsAttrs)
	{
		var pair = nsAttrs[key];
		var namespace = pair.f;
		var value = pair.o;

		typeof value !== 'undefined'
			? domNode.setAttributeNS(namespace, key, value)
			: domNode.removeAttributeNS(namespace, key);
	}
}



// APPLY EVENTS


function _VirtualDom_applyEvents(domNode, eventNode, events)
{
	var allCallbacks = domNode.elmFs || (domNode.elmFs = {});

	for (var key in events)
	{
		var newHandler = events[key];
		var oldCallback = allCallbacks[key];

		if (!newHandler)
		{
			domNode.removeEventListener(key, oldCallback);
			allCallbacks[key] = undefined;
			continue;
		}

		if (oldCallback)
		{
			var oldHandler = oldCallback.q;
			if (oldHandler.$ === newHandler.$)
			{
				oldCallback.q = newHandler;
				continue;
			}
			domNode.removeEventListener(key, oldCallback);
		}

		oldCallback = _VirtualDom_makeCallback(eventNode, newHandler);
		domNode.addEventListener(key, oldCallback,
			_VirtualDom_passiveSupported
			&& { passive: $elm$virtual_dom$VirtualDom$toHandlerInt(newHandler) < 2 }
		);
		allCallbacks[key] = oldCallback;
	}
}



// PASSIVE EVENTS


var _VirtualDom_passiveSupported;

try
{
	window.addEventListener('t', null, Object.defineProperty({}, 'passive', {
		get: function() { _VirtualDom_passiveSupported = true; }
	}));
}
catch(e) {}



// EVENT HANDLERS


function _VirtualDom_makeCallback(eventNode, initialHandler)
{
	function callback(event)
	{
		var handler = callback.q;
		var result = _Json_runHelp(handler.a, event);

		if (!$elm$core$Result$isOk(result))
		{
			return;
		}

		var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

		// 0 = Normal
		// 1 = MayStopPropagation
		// 2 = MayPreventDefault
		// 3 = Custom

		var value = result.a;
		var message = !tag ? value : tag < 3 ? value.a : value.bE;
		var stopPropagation = tag == 1 ? value.b : tag == 3 && value.gP;
		var currentEventNode = (
			stopPropagation && event.stopPropagation(),
			(tag == 2 ? value.b : tag == 3 && value.gu) && event.preventDefault(),
			eventNode
		);
		var tagger;
		var i;
		while (tagger = currentEventNode.j)
		{
			if (typeof tagger == 'function')
			{
				message = tagger(message);
			}
			else
			{
				for (var i = tagger.length; i--; )
				{
					message = tagger[i](message);
				}
			}
			currentEventNode = currentEventNode.p;
		}
		currentEventNode(message, stopPropagation); // stopPropagation implies isSync
	}

	callback.q = initialHandler;

	return callback;
}

function _VirtualDom_equalEvents(x, y)
{
	return x.$ == y.$ && _Json_equality(x.a, y.a);
}



// DIFF


// TODO: Should we do patches like in iOS?
//
// type Patch
//   = At Int Patch
//   | Batch (List Patch)
//   | Change ...
//
// How could it not be better?
//
function _VirtualDom_diff(x, y)
{
	var patches = [];
	_VirtualDom_diffHelp(x, y, patches, 0);
	return patches;
}


function _VirtualDom_pushPatch(patches, type, index, data)
{
	var patch = {
		$: type,
		r: index,
		s: data,
		t: undefined,
		u: undefined
	};
	patches.push(patch);
	return patch;
}


function _VirtualDom_diffHelp(x, y, patches, index)
{
	if (x === y)
	{
		return;
	}

	var xType = x.$;
	var yType = y.$;

	// Bail if you run into different types of nodes. Implies that the
	// structure has changed significantly and it's not worth a diff.
	if (xType !== yType)
	{
		if (xType === 1 && yType === 2)
		{
			y = _VirtualDom_dekey(y);
			yType = 1;
		}
		else
		{
			_VirtualDom_pushPatch(patches, 0, index, y);
			return;
		}
	}

	// Now we know that both nodes are the same $.
	switch (yType)
	{
		case 5:
			var xRefs = x.l;
			var yRefs = y.l;
			var i = xRefs.length;
			var same = i === yRefs.length;
			while (same && i--)
			{
				same = xRefs[i] === yRefs[i];
			}
			if (same)
			{
				y.k = x.k;
				return;
			}
			y.k = y.m();
			var subPatches = [];
			_VirtualDom_diffHelp(x.k, y.k, subPatches, 0);
			subPatches.length > 0 && _VirtualDom_pushPatch(patches, 1, index, subPatches);
			return;

		case 4:
			// gather nested taggers
			var xTaggers = x.j;
			var yTaggers = y.j;
			var nesting = false;

			var xSubNode = x.k;
			while (xSubNode.$ === 4)
			{
				nesting = true;

				typeof xTaggers !== 'object'
					? xTaggers = [xTaggers, xSubNode.j]
					: xTaggers.push(xSubNode.j);

				xSubNode = xSubNode.k;
			}

			var ySubNode = y.k;
			while (ySubNode.$ === 4)
			{
				nesting = true;

				typeof yTaggers !== 'object'
					? yTaggers = [yTaggers, ySubNode.j]
					: yTaggers.push(ySubNode.j);

				ySubNode = ySubNode.k;
			}

			// Just bail if different numbers of taggers. This implies the
			// structure of the virtual DOM has changed.
			if (nesting && xTaggers.length !== yTaggers.length)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			// check if taggers are "the same"
			if (nesting ? !_VirtualDom_pairwiseRefEqual(xTaggers, yTaggers) : xTaggers !== yTaggers)
			{
				_VirtualDom_pushPatch(patches, 2, index, yTaggers);
			}

			// diff everything below the taggers
			_VirtualDom_diffHelp(xSubNode, ySubNode, patches, index + 1);
			return;

		case 0:
			if (x.a !== y.a)
			{
				_VirtualDom_pushPatch(patches, 3, index, y.a);
			}
			return;

		case 1:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKids);
			return;

		case 2:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKeyedKids);
			return;

		case 3:
			if (x.h !== y.h)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
			factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

			var patch = y.i(x.g, y.g);
			patch && _VirtualDom_pushPatch(patches, 5, index, patch);

			return;
	}
}

// assumes the incoming arrays are the same length
function _VirtualDom_pairwiseRefEqual(as, bs)
{
	for (var i = 0; i < as.length; i++)
	{
		if (as[i] !== bs[i])
		{
			return false;
		}
	}

	return true;
}

function _VirtualDom_diffNodes(x, y, patches, index, diffKids)
{
	// Bail if obvious indicators have changed. Implies more serious
	// structural changes such that it's not worth it to diff.
	if (x.c !== y.c || x.f !== y.f)
	{
		_VirtualDom_pushPatch(patches, 0, index, y);
		return;
	}

	var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
	factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

	diffKids(x, y, patches, index);
}



// DIFF FACTS


// TODO Instead of creating a new diff object, it's possible to just test if
// there *is* a diff. During the actual patch, do the diff again and make the
// modifications directly. This way, there's no new allocations. Worth it?
function _VirtualDom_diffFacts(x, y, category)
{
	var diff;

	// look for changes and removals
	for (var xKey in x)
	{
		if (xKey === 'a1' || xKey === 'a0' || xKey === 'a3' || xKey === 'a4')
		{
			var subDiff = _VirtualDom_diffFacts(x[xKey], y[xKey] || {}, xKey);
			if (subDiff)
			{
				diff = diff || {};
				diff[xKey] = subDiff;
			}
			continue;
		}

		// remove if not in the new facts
		if (!(xKey in y))
		{
			diff = diff || {};
			diff[xKey] =
				!category
					? (typeof x[xKey] === 'string' ? '' : null)
					:
				(category === 'a1')
					? ''
					:
				(category === 'a0' || category === 'a3')
					? undefined
					:
				{ f: x[xKey].f, o: undefined };

			continue;
		}

		var xValue = x[xKey];
		var yValue = y[xKey];

		// reference equal, so don't worry about it
		if (xValue === yValue && xKey !== 'value' && xKey !== 'checked'
			|| category === 'a0' && _VirtualDom_equalEvents(xValue, yValue))
		{
			continue;
		}

		diff = diff || {};
		diff[xKey] = yValue;
	}

	// add new stuff
	for (var yKey in y)
	{
		if (!(yKey in x))
		{
			diff = diff || {};
			diff[yKey] = y[yKey];
		}
	}

	return diff;
}



// DIFF KIDS


function _VirtualDom_diffKids(xParent, yParent, patches, index)
{
	var xKids = xParent.e;
	var yKids = yParent.e;

	var xLen = xKids.length;
	var yLen = yKids.length;

	// FIGURE OUT IF THERE ARE INSERTS OR REMOVALS

	if (xLen > yLen)
	{
		_VirtualDom_pushPatch(patches, 6, index, {
			v: yLen,
			i: xLen - yLen
		});
	}
	else if (xLen < yLen)
	{
		_VirtualDom_pushPatch(patches, 7, index, {
			v: xLen,
			e: yKids
		});
	}

	// PAIRWISE DIFF EVERYTHING ELSE

	for (var minLen = xLen < yLen ? xLen : yLen, i = 0; i < minLen; i++)
	{
		var xKid = xKids[i];
		_VirtualDom_diffHelp(xKid, yKids[i], patches, ++index);
		index += xKid.b || 0;
	}
}



// KEYED DIFF


function _VirtualDom_diffKeyedKids(xParent, yParent, patches, rootIndex)
{
	var localPatches = [];

	var changes = {}; // Dict String Entry
	var inserts = []; // Array { index : Int, entry : Entry }
	// type Entry = { tag : String, vnode : VNode, index : Int, data : _ }

	var xKids = xParent.e;
	var yKids = yParent.e;
	var xLen = xKids.length;
	var yLen = yKids.length;
	var xIndex = 0;
	var yIndex = 0;

	var index = rootIndex;

	while (xIndex < xLen && yIndex < yLen)
	{
		var x = xKids[xIndex];
		var y = yKids[yIndex];

		var xKey = x.a;
		var yKey = y.a;
		var xNode = x.b;
		var yNode = y.b;

		var newMatch = undefined;
		var oldMatch = undefined;

		// check if keys match

		if (xKey === yKey)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNode, localPatches, index);
			index += xNode.b || 0;

			xIndex++;
			yIndex++;
			continue;
		}

		// look ahead 1 to detect insertions and removals.

		var xNext = xKids[xIndex + 1];
		var yNext = yKids[yIndex + 1];

		if (xNext)
		{
			var xNextKey = xNext.a;
			var xNextNode = xNext.b;
			oldMatch = yKey === xNextKey;
		}

		if (yNext)
		{
			var yNextKey = yNext.a;
			var yNextNode = yNext.b;
			newMatch = xKey === yNextKey;
		}


		// swap x and y
		if (newMatch && oldMatch)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			_VirtualDom_insertNode(changes, localPatches, xKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNextNode, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		// insert y
		if (newMatch)
		{
			index++;
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			index += xNode.b || 0;

			xIndex += 1;
			yIndex += 2;
			continue;
		}

		// remove x
		if (oldMatch)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 1;
			continue;
		}

		// remove x, insert y
		if (xNext && xNextKey === yNextKey)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNextNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		break;
	}

	// eat up any remaining nodes with removeNode and insertNode

	while (xIndex < xLen)
	{
		index++;
		var x = xKids[xIndex];
		var xNode = x.b;
		_VirtualDom_removeNode(changes, localPatches, x.a, xNode, index);
		index += xNode.b || 0;
		xIndex++;
	}

	while (yIndex < yLen)
	{
		var endInserts = endInserts || [];
		var y = yKids[yIndex];
		_VirtualDom_insertNode(changes, localPatches, y.a, y.b, undefined, endInserts);
		yIndex++;
	}

	if (localPatches.length > 0 || inserts.length > 0 || endInserts)
	{
		_VirtualDom_pushPatch(patches, 8, rootIndex, {
			w: localPatches,
			x: inserts,
			y: endInserts
		});
	}
}



// CHANGES FROM KEYED DIFF


var _VirtualDom_POSTFIX = '_elmW6BL';


function _VirtualDom_insertNode(changes, localPatches, key, vnode, yIndex, inserts)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		entry = {
			c: 0,
			z: vnode,
			r: yIndex,
			s: undefined
		};

		inserts.push({ r: yIndex, A: entry });
		changes[key] = entry;

		return;
	}

	// this key was removed earlier, a match!
	if (entry.c === 1)
	{
		inserts.push({ r: yIndex, A: entry });

		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(entry.z, vnode, subPatches, entry.r);
		entry.r = yIndex;
		entry.s.s = {
			w: subPatches,
			A: entry
		};

		return;
	}

	// this key has already been inserted or moved, a duplicate!
	_VirtualDom_insertNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, yIndex, inserts);
}


function _VirtualDom_removeNode(changes, localPatches, key, vnode, index)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		var patch = _VirtualDom_pushPatch(localPatches, 9, index, undefined);

		changes[key] = {
			c: 1,
			z: vnode,
			r: index,
			s: patch
		};

		return;
	}

	// this key was inserted earlier, a match!
	if (entry.c === 0)
	{
		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(vnode, entry.z, subPatches, index);

		_VirtualDom_pushPatch(localPatches, 9, index, {
			w: subPatches,
			A: entry
		});

		return;
	}

	// this key has already been removed or moved, a duplicate!
	_VirtualDom_removeNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, index);
}



// ADD DOM NODES
//
// Each DOM node has an "index" assigned in order of traversal. It is important
// to minimize our crawl over the actual DOM, so these indexes (along with the
// descendantsCount of virtual nodes) let us skip touching entire subtrees of
// the DOM if we know there are no patches there.


function _VirtualDom_addDomNodes(domNode, vNode, patches, eventNode)
{
	_VirtualDom_addDomNodesHelp(domNode, vNode, patches, 0, 0, vNode.b, eventNode);
}


// assumes `patches` is non-empty and indexes increase monotonically.
function _VirtualDom_addDomNodesHelp(domNode, vNode, patches, i, low, high, eventNode)
{
	var patch = patches[i];
	var index = patch.r;

	while (index === low)
	{
		var patchType = patch.$;

		if (patchType === 1)
		{
			_VirtualDom_addDomNodes(domNode, vNode.k, patch.s, eventNode);
		}
		else if (patchType === 8)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var subPatches = patch.s.w;
			if (subPatches.length > 0)
			{
				_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
			}
		}
		else if (patchType === 9)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var data = patch.s;
			if (data)
			{
				data.A.s = domNode;
				var subPatches = data.w;
				if (subPatches.length > 0)
				{
					_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
				}
			}
		}
		else
		{
			patch.t = domNode;
			patch.u = eventNode;
		}

		i++;

		if (!(patch = patches[i]) || (index = patch.r) > high)
		{
			return i;
		}
	}

	var tag = vNode.$;

	if (tag === 4)
	{
		var subNode = vNode.k;

		while (subNode.$ === 4)
		{
			subNode = subNode.k;
		}

		return _VirtualDom_addDomNodesHelp(domNode, subNode, patches, i, low + 1, high, domNode.elm_event_node_ref);
	}

	// tag must be 1 or 2 at this point

	var vKids = vNode.e;
	var childNodes = domNode.childNodes;
	for (var j = 0; j < vKids.length; j++)
	{
		low++;
		var vKid = tag === 1 ? vKids[j] : vKids[j].b;
		var nextLow = low + (vKid.b || 0);
		if (low <= index && index <= nextLow)
		{
			i = _VirtualDom_addDomNodesHelp(childNodes[j], vKid, patches, i, low, nextLow, eventNode);
			if (!(patch = patches[i]) || (index = patch.r) > high)
			{
				return i;
			}
		}
		low = nextLow;
	}
	return i;
}



// APPLY PATCHES


function _VirtualDom_applyPatches(rootDomNode, oldVirtualNode, patches, eventNode)
{
	if (patches.length === 0)
	{
		return rootDomNode;
	}

	_VirtualDom_addDomNodes(rootDomNode, oldVirtualNode, patches, eventNode);
	return _VirtualDom_applyPatchesHelp(rootDomNode, patches);
}

function _VirtualDom_applyPatchesHelp(rootDomNode, patches)
{
	for (var i = 0; i < patches.length; i++)
	{
		var patch = patches[i];
		var localDomNode = patch.t
		var newNode = _VirtualDom_applyPatch(localDomNode, patch);
		if (localDomNode === rootDomNode)
		{
			rootDomNode = newNode;
		}
	}
	return rootDomNode;
}

function _VirtualDom_applyPatch(domNode, patch)
{
	switch (patch.$)
	{
		case 0:
			return _VirtualDom_applyPatchRedraw(domNode, patch.s, patch.u);

		case 4:
			_VirtualDom_applyFacts(domNode, patch.u, patch.s);
			return domNode;

		case 3:
			domNode.replaceData(0, domNode.length, patch.s);
			return domNode;

		case 1:
			return _VirtualDom_applyPatchesHelp(domNode, patch.s);

		case 2:
			if (domNode.elm_event_node_ref)
			{
				domNode.elm_event_node_ref.j = patch.s;
			}
			else
			{
				domNode.elm_event_node_ref = { j: patch.s, p: patch.u };
			}
			return domNode;

		case 6:
			var data = patch.s;
			for (var i = 0; i < data.i; i++)
			{
				domNode.removeChild(domNode.childNodes[data.v]);
			}
			return domNode;

		case 7:
			var data = patch.s;
			var kids = data.e;
			var i = data.v;
			var theEnd = domNode.childNodes[i];
			for (; i < kids.length; i++)
			{
				domNode.insertBefore(_VirtualDom_render(kids[i], patch.u), theEnd);
			}
			return domNode;

		case 9:
			var data = patch.s;
			if (!data)
			{
				domNode.parentNode.removeChild(domNode);
				return domNode;
			}
			var entry = data.A;
			if (typeof entry.r !== 'undefined')
			{
				domNode.parentNode.removeChild(domNode);
			}
			entry.s = _VirtualDom_applyPatchesHelp(domNode, data.w);
			return domNode;

		case 8:
			return _VirtualDom_applyPatchReorder(domNode, patch);

		case 5:
			return patch.s(domNode);

		default:
			_Debug_crash(10); // 'Ran into an unknown patch!'
	}
}


function _VirtualDom_applyPatchRedraw(domNode, vNode, eventNode)
{
	var parentNode = domNode.parentNode;
	var newNode = _VirtualDom_render(vNode, eventNode);

	if (!newNode.elm_event_node_ref)
	{
		newNode.elm_event_node_ref = domNode.elm_event_node_ref;
	}

	if (parentNode && newNode !== domNode)
	{
		parentNode.replaceChild(newNode, domNode);
	}
	return newNode;
}


function _VirtualDom_applyPatchReorder(domNode, patch)
{
	var data = patch.s;

	// remove end inserts
	var frag = _VirtualDom_applyPatchReorderEndInsertsHelp(data.y, patch);

	// removals
	domNode = _VirtualDom_applyPatchesHelp(domNode, data.w);

	// inserts
	var inserts = data.x;
	for (var i = 0; i < inserts.length; i++)
	{
		var insert = inserts[i];
		var entry = insert.A;
		var node = entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u);
		domNode.insertBefore(node, domNode.childNodes[insert.r]);
	}

	// add end inserts
	if (frag)
	{
		_VirtualDom_appendChild(domNode, frag);
	}

	return domNode;
}


function _VirtualDom_applyPatchReorderEndInsertsHelp(endInserts, patch)
{
	if (!endInserts)
	{
		return;
	}

	var frag = _VirtualDom_doc.createDocumentFragment();
	for (var i = 0; i < endInserts.length; i++)
	{
		var insert = endInserts[i];
		var entry = insert.A;
		_VirtualDom_appendChild(frag, entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u)
		);
	}
	return frag;
}


function _VirtualDom_virtualize(node)
{
	// TEXT NODES

	if (node.nodeType === 3)
	{
		return _VirtualDom_text(node.textContent);
	}


	// WEIRD NODES

	if (node.nodeType !== 1)
	{
		return _VirtualDom_text('');
	}


	// ELEMENT NODES

	var attrList = _List_Nil;
	var attrs = node.attributes;
	for (var i = attrs.length; i--; )
	{
		var attr = attrs[i];
		var name = attr.name;
		var value = attr.value;
		attrList = _List_Cons( A2(_VirtualDom_attribute, name, value), attrList );
	}

	var tag = node.tagName.toLowerCase();
	var kidList = _List_Nil;
	var kids = node.childNodes;

	for (var i = kids.length; i--; )
	{
		kidList = _List_Cons(_VirtualDom_virtualize(kids[i]), kidList);
	}
	return A3(_VirtualDom_node, tag, attrList, kidList);
}

function _VirtualDom_dekey(keyedNode)
{
	var keyedKids = keyedNode.e;
	var len = keyedKids.length;
	var kids = new Array(len);
	for (var i = 0; i < len; i++)
	{
		kids[i] = keyedKids[i].b;
	}

	return {
		$: 1,
		c: keyedNode.c,
		d: keyedNode.d,
		e: kids,
		f: keyedNode.f,
		b: keyedNode.b
	};
}




// ELEMENT


var _Debugger_element;

var _Browser_element = _Debugger_element || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.kM,
		impl.mc,
		impl.l_,
		function(sendToApp, initialModel) {
			var view = impl.mg;
			/**/
			var domNode = args['node'];
			//*/
			/**_UNUSED/
			var domNode = args && args['node'] ? args['node'] : _Debug_crash(0);
			//*/
			var currNode = _VirtualDom_virtualize(domNode);

			return _Browser_makeAnimator(initialModel, function(model)
			{
				var nextNode = view(model);
				var patches = _VirtualDom_diff(currNode, nextNode);
				domNode = _VirtualDom_applyPatches(domNode, currNode, patches, sendToApp);
				currNode = nextNode;
			});
		}
	);
});



// DOCUMENT


var _Debugger_document;

var _Browser_document = _Debugger_document || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.kM,
		impl.mc,
		impl.l_,
		function(sendToApp, initialModel) {
			var divertHrefToApp = impl.gH && impl.gH(sendToApp)
			var view = impl.mg;
			var title = _VirtualDom_doc.title;
			var bodyNode = _VirtualDom_doc.body;
			var currNode = _VirtualDom_virtualize(bodyNode);
			return _Browser_makeAnimator(initialModel, function(model)
			{
				_VirtualDom_divertHrefToApp = divertHrefToApp;
				var doc = view(model);
				var nextNode = _VirtualDom_node('body')(_List_Nil)(doc.e6);
				var patches = _VirtualDom_diff(currNode, nextNode);
				bodyNode = _VirtualDom_applyPatches(bodyNode, currNode, patches, sendToApp);
				currNode = nextNode;
				_VirtualDom_divertHrefToApp = 0;
				(title !== doc.l4) && (_VirtualDom_doc.title = title = doc.l4);
			});
		}
	);
});



// ANIMATION


var _Browser_cancelAnimationFrame =
	typeof cancelAnimationFrame !== 'undefined'
		? cancelAnimationFrame
		: function(id) { clearTimeout(id); };

var _Browser_requestAnimationFrame =
	typeof requestAnimationFrame !== 'undefined'
		? requestAnimationFrame
		: function(callback) { return setTimeout(callback, 1000 / 60); };


function _Browser_makeAnimator(model, draw)
{
	draw(model);

	var state = 0;

	function updateIfNeeded()
	{
		state = state === 1
			? 0
			: ( _Browser_requestAnimationFrame(updateIfNeeded), draw(model), 1 );
	}

	return function(nextModel, isSync)
	{
		model = nextModel;

		isSync
			? ( draw(model),
				state === 2 && (state = 1)
				)
			: ( state === 0 && _Browser_requestAnimationFrame(updateIfNeeded),
				state = 2
				);
	};
}



// APPLICATION


function _Browser_application(impl)
{
	var onUrlChange = impl.lq;
	var onUrlRequest = impl.lr;
	var key = function() { key.a(onUrlChange(_Browser_getUrl())); };

	return _Browser_document({
		gH: function(sendToApp)
		{
			key.a = sendToApp;
			_Browser_window.addEventListener('popstate', key);
			_Browser_window.navigator.userAgent.indexOf('Trident') < 0 || _Browser_window.addEventListener('hashchange', key);

			return F2(function(domNode, event)
			{
				if (!event.ctrlKey && !event.metaKey && !event.shiftKey && event.button < 1 && !domNode.target && !domNode.hasAttribute('download'))
				{
					event.preventDefault();
					var href = domNode.href;
					var curr = _Browser_getUrl();
					var next = $elm$url$Url$fromString(href).a;
					sendToApp(onUrlRequest(
						(next
							&& curr.iW === next.iW
							&& curr.hZ === next.hZ
							&& curr.iP.a === next.iP.a
						)
							? $elm$browser$Browser$Internal(next)
							: $elm$browser$Browser$External(href)
					));
				}
			});
		},
		kM: function(flags)
		{
			return A3(impl.kM, flags, _Browser_getUrl(), key);
		},
		mg: impl.mg,
		mc: impl.mc,
		l_: impl.l_
	});
}

function _Browser_getUrl()
{
	return $elm$url$Url$fromString(_VirtualDom_doc.location.href).a || _Debug_crash(1);
}

var _Browser_go = F2(function(key, n)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		n && history.go(n);
		key();
	}));
});

var _Browser_pushUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.pushState({}, '', url);
		key();
	}));
});

var _Browser_replaceUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.replaceState({}, '', url);
		key();
	}));
});



// GLOBAL EVENTS


var _Browser_fakeNode = { addEventListener: function() {}, removeEventListener: function() {} };
var _Browser_doc = typeof document !== 'undefined' ? document : _Browser_fakeNode;
var _Browser_window = typeof window !== 'undefined' ? window : _Browser_fakeNode;

var _Browser_on = F3(function(node, eventName, sendToSelf)
{
	return _Scheduler_spawn(_Scheduler_binding(function(callback)
	{
		function handler(event)	{ _Scheduler_rawSpawn(sendToSelf(event)); }
		node.addEventListener(eventName, handler, _VirtualDom_passiveSupported && { passive: true });
		return function() { node.removeEventListener(eventName, handler); };
	}));
});

var _Browser_decodeEvent = F2(function(decoder, event)
{
	var result = _Json_runHelp(decoder, event);
	return $elm$core$Result$isOk(result) ? $elm$core$Maybe$Just(result.a) : $elm$core$Maybe$Nothing;
});



// PAGE VISIBILITY


function _Browser_visibilityInfo()
{
	return (typeof _VirtualDom_doc.hidden !== 'undefined')
		? { kF: 'hidden', j5: 'visibilitychange' }
		:
	(typeof _VirtualDom_doc.mozHidden !== 'undefined')
		? { kF: 'mozHidden', j5: 'mozvisibilitychange' }
		:
	(typeof _VirtualDom_doc.msHidden !== 'undefined')
		? { kF: 'msHidden', j5: 'msvisibilitychange' }
		:
	(typeof _VirtualDom_doc.webkitHidden !== 'undefined')
		? { kF: 'webkitHidden', j5: 'webkitvisibilitychange' }
		: { kF: 'hidden', j5: 'visibilitychange' };
}



// ANIMATION FRAMES


function _Browser_rAF()
{
	return _Scheduler_binding(function(callback)
	{
		var id = _Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(Date.now()));
		});

		return function() {
			_Browser_cancelAnimationFrame(id);
		};
	});
}


function _Browser_now()
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(Date.now()));
	});
}



// DOM STUFF


function _Browser_withNode(id, doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			var node = document.getElementById(id);
			callback(node
				? _Scheduler_succeed(doStuff(node))
				: _Scheduler_fail($elm$browser$Browser$Dom$NotFound(id))
			);
		});
	});
}


function _Browser_withWindow(doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(doStuff()));
		});
	});
}


// FOCUS and BLUR


var _Browser_call = F2(function(functionName, id)
{
	return _Browser_withNode(id, function(node) {
		node[functionName]();
		return _Utils_Tuple0;
	});
});



// WINDOW VIEWPORT


function _Browser_getViewport()
{
	return {
		i9: _Browser_getScene(),
		jE: {
			de: _Browser_window.pageXOffset,
			cl: _Browser_window.pageYOffset,
			jI: _Browser_doc.documentElement.clientWidth,
			fB: _Browser_doc.documentElement.clientHeight
		}
	};
}

function _Browser_getScene()
{
	var body = _Browser_doc.body;
	var elem = _Browser_doc.documentElement;
	return {
		jI: Math.max(body.scrollWidth, body.offsetWidth, elem.scrollWidth, elem.offsetWidth, elem.clientWidth),
		fB: Math.max(body.scrollHeight, body.offsetHeight, elem.scrollHeight, elem.offsetHeight, elem.clientHeight)
	};
}

var _Browser_setViewport = F2(function(x, y)
{
	return _Browser_withWindow(function()
	{
		_Browser_window.scroll(x, y);
		return _Utils_Tuple0;
	});
});



// ELEMENT VIEWPORT


function _Browser_getViewportOf(id)
{
	return _Browser_withNode(id, function(node)
	{
		return {
			i9: {
				jI: node.scrollWidth,
				fB: node.scrollHeight
			},
			jE: {
				de: node.scrollLeft,
				cl: node.scrollTop,
				jI: node.clientWidth,
				fB: node.clientHeight
			}
		};
	});
}


var _Browser_setViewportOf = F3(function(id, x, y)
{
	return _Browser_withNode(id, function(node)
	{
		node.scrollLeft = x;
		node.scrollTop = y;
		return _Utils_Tuple0;
	});
});



// ELEMENT


function _Browser_getElement(id)
{
	return _Browser_withNode(id, function(node)
	{
		var rect = node.getBoundingClientRect();
		var x = _Browser_window.pageXOffset;
		var y = _Browser_window.pageYOffset;
		return {
			i9: _Browser_getScene(),
			jE: {
				de: x,
				cl: y,
				jI: _Browser_doc.documentElement.clientWidth,
				fB: _Browser_doc.documentElement.clientHeight
			},
			kx: {
				de: x + rect.left,
				cl: y + rect.top,
				jI: rect.width,
				fB: rect.height
			}
		};
	});
}



// LOAD and RELOAD


function _Browser_reload(skipCache)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		_VirtualDom_doc.location.reload(skipCache);
	}));
}

function _Browser_load(url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		try
		{
			_Browser_window.location = url;
		}
		catch(err)
		{
			// Only Firefox can throw a NS_ERROR_MALFORMED_URI exception here.
			// Other browsers reload the page, so let's be consistent about that.
			_VirtualDom_doc.location.reload(false);
		}
	}));
}



// SEND REQUEST

var _Http_toTask = F3(function(router, toTask, request)
{
	return _Scheduler_binding(function(callback)
	{
		function done(response) {
			callback(toTask(request.fp.a(response)));
		}

		var xhr = new XMLHttpRequest();
		xhr.addEventListener('error', function() { done($elm$http$Http$NetworkError_); });
		xhr.addEventListener('timeout', function() { done($elm$http$Http$Timeout_); });
		xhr.addEventListener('load', function() { done(_Http_toResponse(request.fp.b, xhr)); });
		$elm$core$Maybe$isJust(request.g_) && _Http_track(router, xhr, request.g_.a);

		try {
			xhr.open(request.f_, request.g2, true);
		} catch (e) {
			return done($elm$http$Http$BadUrl_(request.g2));
		}

		_Http_configureRequest(xhr, request);

		request.e6.a && xhr.setRequestHeader('Content-Type', request.e6.a);
		xhr.send(request.e6.b);

		return function() { xhr.c = true; xhr.abort(); };
	});
});


// CONFIGURE

function _Http_configureRequest(xhr, request)
{
	for (var headers = request.fA; headers.b; headers = headers.b) // WHILE_CONS
	{
		xhr.setRequestHeader(headers.a.a, headers.a.b);
	}
	xhr.timeout = request.gV.a || 0;
	xhr.responseType = request.fp.d;
	xhr.withCredentials = request.jQ;
}


// RESPONSES

function _Http_toResponse(toBody, xhr)
{
	return A2(
		200 <= xhr.status && xhr.status < 300 ? $elm$http$Http$GoodStatus_ : $elm$http$Http$BadStatus_,
		_Http_toMetadata(xhr),
		toBody(xhr.response)
	);
}


// METADATA

function _Http_toMetadata(xhr)
{
	return {
		g2: xhr.responseURL,
		lV: xhr.status,
		lW: xhr.statusText,
		fA: _Http_parseHeaders(xhr.getAllResponseHeaders())
	};
}


// HEADERS

function _Http_parseHeaders(rawHeaders)
{
	if (!rawHeaders)
	{
		return $elm$core$Dict$empty;
	}

	var headers = $elm$core$Dict$empty;
	var headerPairs = rawHeaders.split('\r\n');
	for (var i = headerPairs.length; i--; )
	{
		var headerPair = headerPairs[i];
		var index = headerPair.indexOf(': ');
		if (index > 0)
		{
			var key = headerPair.substring(0, index);
			var value = headerPair.substring(index + 2);

			headers = A3($elm$core$Dict$update, key, function(oldValue) {
				return $elm$core$Maybe$Just($elm$core$Maybe$isJust(oldValue)
					? value + ', ' + oldValue.a
					: value
				);
			}, headers);
		}
	}
	return headers;
}


// EXPECT

var _Http_expect = F3(function(type, toBody, toValue)
{
	return {
		$: 0,
		d: type,
		b: toBody,
		a: toValue
	};
});

var _Http_mapExpect = F2(function(func, expect)
{
	return {
		$: 0,
		d: expect.d,
		b: expect.b,
		a: function(x) { return func(expect.a(x)); }
	};
});

function _Http_toDataView(arrayBuffer)
{
	return new DataView(arrayBuffer);
}


// BODY and PARTS

var _Http_emptyBody = { $: 0 };
var _Http_pair = F2(function(a, b) { return { $: 0, a: a, b: b }; });

function _Http_toFormData(parts)
{
	for (var formData = new FormData(); parts.b; parts = parts.b) // WHILE_CONS
	{
		var part = parts.a;
		formData.append(part.a, part.b);
	}
	return formData;
}

var _Http_bytesToBlob = F2(function(mime, bytes)
{
	return new Blob([bytes], { type: mime });
});


// PROGRESS

function _Http_track(router, xhr, tracker)
{
	// TODO check out lengthComputable on loadstart event

	xhr.upload.addEventListener('progress', function(event) {
		if (xhr.c) { return; }
		_Scheduler_rawSpawn(A2($elm$core$Platform$sendToSelf, router, _Utils_Tuple2(tracker, $elm$http$Http$Sending({
			lT: event.loaded,
			jg: event.total
		}))));
	});
	xhr.addEventListener('progress', function(event) {
		if (xhr.c) { return; }
		_Scheduler_rawSpawn(A2($elm$core$Platform$sendToSelf, router, _Utils_Tuple2(tracker, $elm$http$Http$Receiving({
			lB: event.loaded,
			jg: event.lengthComputable ? $elm$core$Maybe$Just(event.total) : $elm$core$Maybe$Nothing
		}))));
	});
}

function _Url_percentEncode(string)
{
	return encodeURIComponent(string);
}

function _Url_percentDecode(string)
{
	try
	{
		return $elm$core$Maybe$Just(decodeURIComponent(string));
	}
	catch (e)
	{
		return $elm$core$Maybe$Nothing;
	}
}


var _Bitwise_and = F2(function(a, b)
{
	return a & b;
});

var _Bitwise_or = F2(function(a, b)
{
	return a | b;
});

var _Bitwise_xor = F2(function(a, b)
{
	return a ^ b;
});

function _Bitwise_complement(a)
{
	return ~a;
};

var _Bitwise_shiftLeftBy = F2(function(offset, a)
{
	return a << offset;
});

var _Bitwise_shiftRightBy = F2(function(offset, a)
{
	return a >> offset;
});

var _Bitwise_shiftRightZfBy = F2(function(offset, a)
{
	return a >>> offset;
});



function _Time_now(millisToPosix)
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(millisToPosix(Date.now())));
	});
}

var _Time_setInterval = F2(function(interval, task)
{
	return _Scheduler_binding(function(callback)
	{
		var id = setInterval(function() { _Scheduler_rawSpawn(task); }, interval);
		return function() { clearInterval(id); };
	});
});

function _Time_here()
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(
			A2($elm$time$Time$customZone, -(new Date().getTimezoneOffset()), _List_Nil)
		));
	});
}


function _Time_getZoneName()
{
	return _Scheduler_binding(function(callback)
	{
		try
		{
			var name = $elm$time$Time$Name(Intl.DateTimeFormat().resolvedOptions().timeZone);
		}
		catch (e)
		{
			var name = $elm$time$Time$Offset(new Date().getTimezoneOffset());
		}
		callback(_Scheduler_succeed(name));
	});
}




// STRINGS


var _Parser_isSubString = F5(function(smallString, offset, row, col, bigString)
{
	var smallLength = smallString.length;
	var isGood = offset + smallLength <= bigString.length;

	for (var i = 0; isGood && i < smallLength; )
	{
		var code = bigString.charCodeAt(offset);
		isGood =
			smallString[i++] === bigString[offset++]
			&& (
				code === 0x000A /* \n */
					? ( row++, col=1 )
					: ( col++, (code & 0xF800) === 0xD800 ? smallString[i++] === bigString[offset++] : 1 )
			)
	}

	return _Utils_Tuple3(isGood ? offset : -1, row, col);
});



// CHARS


var _Parser_isSubChar = F3(function(predicate, offset, string)
{
	return (
		string.length <= offset
			? -1
			:
		(string.charCodeAt(offset) & 0xF800) === 0xD800
			? (predicate(_Utils_chr(string.substr(offset, 2))) ? offset + 2 : -1)
			:
		(predicate(_Utils_chr(string[offset]))
			? ((string[offset] === '\n') ? -2 : (offset + 1))
			: -1
		)
	);
});


var _Parser_isAsciiCode = F3(function(code, offset, string)
{
	return string.charCodeAt(offset) === code;
});



// NUMBERS


var _Parser_chompBase10 = F2(function(offset, string)
{
	for (; offset < string.length; offset++)
	{
		var code = string.charCodeAt(offset);
		if (code < 0x30 || 0x39 < code)
		{
			return offset;
		}
	}
	return offset;
});


var _Parser_consumeBase = F3(function(base, offset, string)
{
	for (var total = 0; offset < string.length; offset++)
	{
		var digit = string.charCodeAt(offset) - 0x30;
		if (digit < 0 || base <= digit) break;
		total = base * total + digit;
	}
	return _Utils_Tuple2(offset, total);
});


var _Parser_consumeBase16 = F2(function(offset, string)
{
	for (var total = 0; offset < string.length; offset++)
	{
		var code = string.charCodeAt(offset);
		if (0x30 <= code && code <= 0x39)
		{
			total = 16 * total + code - 0x30;
		}
		else if (0x41 <= code && code <= 0x46)
		{
			total = 16 * total + code - 55;
		}
		else if (0x61 <= code && code <= 0x66)
		{
			total = 16 * total + code - 87;
		}
		else
		{
			break;
		}
	}
	return _Utils_Tuple2(offset, total);
});



// FIND STRING


var _Parser_findSubString = F5(function(smallString, offset, row, col, bigString)
{
	var newOffset = bigString.indexOf(smallString, offset);
	var target = newOffset < 0 ? bigString.length : newOffset + smallString.length;

	while (offset < target)
	{
		var code = bigString.charCodeAt(offset++);
		code === 0x000A /* \n */
			? ( col=1, row++ )
			: ( col++, (code & 0xF800) === 0xD800 && offset++ )
	}

	return _Utils_Tuple3(newOffset, row, col);
});
var $elm$core$List$cons = _List_cons;
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (!node.$) {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === -2) {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Basics$EQ = 1;
var $elm$core$Basics$GT = 2;
var $elm$core$Basics$LT = 0;
var $author$project$Horizon$FromLocalStorage = function (a) {
	return {$: 0, a: a};
};
var $author$project$Tsinfo$FromZoom = function (a) {
	return {$: 42, a: a};
};
var $author$project$Tsinfo$NewDataFromHover = function (a) {
	return {$: 52, a: a};
};
var $author$project$Tsinfo$NewDragMode = function (a) {
	return {$: 43, a: a};
};
var $elm$core$Result$Err = function (a) {
	return {$: 1, a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 0, a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 2, a: a};
};
var $elm$core$Basics$False = 1;
var $elm$core$Basics$add = _Basics_add;
var $elm$core$Maybe$Just = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Maybe$Nothing = {$: 1};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$core$Basics$append = _Utils_append;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\n    ',
		A2($elm$core$String$split, '\n', str));
};
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\n\n(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 0:
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 1) {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\'' + (f + '\']'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 1:
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 2:
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\n\n',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\n\n';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\n\n    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\n\n' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 0, a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 1, a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$eq = _Utils_equal;
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.D) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.J),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.J);
		} else {
			var treeLen = builder.D * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.O) : builder.O;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.D);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.J) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.J);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{O: nodeList, D: (len / $elm$core$Array$branchFactor) | 0, J: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Basics$True = 0;
var $elm$core$Result$isOk = function (result) {
	if (!result.$) {
		return true;
	} else {
		return false;
	}
};
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$core$Platform$Sub$batch = _Platform_batch;
var $author$project$Tsinfo$Horizon = function (a) {
	return {$: 40, a: a};
};
var $author$project$Tsinfo$convertMsg = function (msg) {
	return $author$project$Tsinfo$Horizon(msg);
};
var $elm$json$Json$Decode$string = _Json_decodeString;
var $author$project$Tsinfo$dataFromHover = _Platform_incomingPort('dataFromHover', $elm$json$Json$Decode$string);
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$json$Json$Decode$map2 = _Json_map2;
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $elm$virtual_dom$VirtualDom$toHandlerInt = function (handler) {
	switch (handler.$) {
		case 0:
			return 0;
		case 1:
			return 1;
		case 2:
			return 2;
		default:
			return 3;
	}
};
var $elm$browser$Browser$External = function (a) {
	return {$: 1, a: a};
};
var $elm$browser$Browser$Internal = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $elm$browser$Browser$Dom$NotFound = $elm$core$Basics$identity;
var $elm$url$Url$Http = 0;
var $elm$url$Url$Https = 1;
var $elm$url$Url$Url = F6(
	function (protocol, host, port_, path, query, fragment) {
		return {hT: fragment, hZ: host, iM: path, iP: port_, iW: protocol, iX: query};
	});
var $elm$core$String$contains = _String_contains;
var $elm$core$String$length = _String_length;
var $elm$core$String$slice = _String_slice;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $elm$core$String$indexes = _String_indexes;
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $elm$core$String$left = F2(
	function (n, string) {
		return (n < 1) ? '' : A3($elm$core$String$slice, 0, n, string);
	});
var $elm$core$String$toInt = _String_toInt;
var $elm$url$Url$chompBeforePath = F5(
	function (protocol, path, params, frag, str) {
		if ($elm$core$String$isEmpty(str) || A2($elm$core$String$contains, '@', str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, ':', str);
			if (!_v0.b) {
				return $elm$core$Maybe$Just(
					A6($elm$url$Url$Url, protocol, str, $elm$core$Maybe$Nothing, path, params, frag));
			} else {
				if (!_v0.b.b) {
					var i = _v0.a;
					var _v1 = $elm$core$String$toInt(
						A2($elm$core$String$dropLeft, i + 1, str));
					if (_v1.$ === 1) {
						return $elm$core$Maybe$Nothing;
					} else {
						var port_ = _v1;
						return $elm$core$Maybe$Just(
							A6(
								$elm$url$Url$Url,
								protocol,
								A2($elm$core$String$left, i, str),
								port_,
								path,
								params,
								frag));
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}
		}
	});
var $elm$url$Url$chompBeforeQuery = F4(
	function (protocol, params, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '/', str);
			if (!_v0.b) {
				return A5($elm$url$Url$chompBeforePath, protocol, '/', params, frag, str);
			} else {
				var i = _v0.a;
				return A5(
					$elm$url$Url$chompBeforePath,
					protocol,
					A2($elm$core$String$dropLeft, i, str),
					params,
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompBeforeFragment = F3(
	function (protocol, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '?', str);
			if (!_v0.b) {
				return A4($elm$url$Url$chompBeforeQuery, protocol, $elm$core$Maybe$Nothing, frag, str);
			} else {
				var i = _v0.a;
				return A4(
					$elm$url$Url$chompBeforeQuery,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompAfterProtocol = F2(
	function (protocol, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '#', str);
			if (!_v0.b) {
				return A3($elm$url$Url$chompBeforeFragment, protocol, $elm$core$Maybe$Nothing, str);
			} else {
				var i = _v0.a;
				return A3(
					$elm$url$Url$chompBeforeFragment,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$core$String$startsWith = _String_startsWith;
var $elm$url$Url$fromString = function (str) {
	return A2($elm$core$String$startsWith, 'http://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		0,
		A2($elm$core$String$dropLeft, 7, str)) : (A2($elm$core$String$startsWith, 'https://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		1,
		A2($elm$core$String$dropLeft, 8, str)) : $elm$core$Maybe$Nothing);
};
var $elm$core$Basics$never = function (_v0) {
	never:
	while (true) {
		var nvr = _v0;
		var $temp$_v0 = nvr;
		_v0 = $temp$_v0;
		continue never;
	}
};
var $elm$core$Task$Perform = $elm$core$Basics$identity;
var $elm$core$Task$succeed = _Scheduler_succeed;
var $elm$core$Task$init = $elm$core$Task$succeed(0);
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$core$Task$andThen = _Scheduler_andThen;
var $elm$core$Task$map = F2(
	function (func, taskA) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return $elm$core$Task$succeed(
					func(a));
			},
			taskA);
	});
var $elm$core$Task$map2 = F3(
	function (func, taskA, taskB) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return A2(
					$elm$core$Task$andThen,
					function (b) {
						return $elm$core$Task$succeed(
							A2(func, a, b));
					},
					taskB);
			},
			taskA);
	});
var $elm$core$Task$sequence = function (tasks) {
	return A3(
		$elm$core$List$foldr,
		$elm$core$Task$map2($elm$core$List$cons),
		$elm$core$Task$succeed(_List_Nil),
		tasks);
};
var $elm$core$Platform$sendToApp = _Platform_sendToApp;
var $elm$core$Task$spawnCmd = F2(
	function (router, _v0) {
		var task = _v0;
		return _Scheduler_spawn(
			A2(
				$elm$core$Task$andThen,
				$elm$core$Platform$sendToApp(router),
				task));
	});
var $elm$core$Task$onEffects = F3(
	function (router, commands, state) {
		return A2(
			$elm$core$Task$map,
			function (_v0) {
				return 0;
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$map,
					$elm$core$Task$spawnCmd(router),
					commands)));
	});
var $elm$core$Task$onSelfMsg = F3(
	function (_v0, _v1, _v2) {
		return $elm$core$Task$succeed(0);
	});
var $elm$core$Task$cmdMap = F2(
	function (tagger, _v0) {
		var task = _v0;
		return A2($elm$core$Task$map, tagger, task);
	});
_Platform_effectManagers['Task'] = _Platform_createManager($elm$core$Task$init, $elm$core$Task$onEffects, $elm$core$Task$onSelfMsg, $elm$core$Task$cmdMap);
var $elm$core$Task$command = _Platform_leaf('Task');
var $elm$core$Task$perform = F2(
	function (toMessage, task) {
		return $elm$core$Task$command(
			A2($elm$core$Task$map, toMessage, task));
	});
var $elm$browser$Browser$element = _Browser_element;
var $elm$json$Json$Decode$field = _Json_decodeField;
var $author$project$Tsinfo$GetPermissions = function (a) {
	return {$: 4, a: a};
};
var $author$project$Tsinfo$GotSysMeta = function (a) {
	return {$: 0, a: a};
};
var $author$project$Tsinfo$GotUserMeta = function (a) {
	return {$: 1, a: a};
};
var $author$project$Horizon$Loading = 1;
var $author$project$NavTabs$Plot = 0;
var $author$project$Info$Primary = 0;
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $elm$core$Dict$RBEmpty_elm_builtin = {$: -2};
var $elm$core$Dict$empty = $elm$core$Dict$RBEmpty_elm_builtin;
var $elm$core$Basics$round = _Basics_round;
var $Gizra$elm_debouncer$Debouncer$Internal$fromSeconds = function (s) {
	return $elm$core$Basics$round(s * 1000);
};
var $Gizra$elm_debouncer$Debouncer$Messages$fromSeconds = $Gizra$elm_debouncer$Debouncer$Internal$fromSeconds;
var $author$project$Tsinfo$GotCachePolicy = function (a) {
	return {$: 19, a: a};
};
var $elm$url$Url$Builder$toQueryPair = function (_v0) {
	var key = _v0.a;
	var value = _v0.b;
	return key + ('=' + value);
};
var $elm$url$Url$Builder$toQuery = function (parameters) {
	if (!parameters.b) {
		return '';
	} else {
		return '?' + A2(
			$elm$core$String$join,
			'&',
			A2($elm$core$List$map, $elm$url$Url$Builder$toQueryPair, parameters));
	}
};
var $elm$url$Url$Builder$crossOrigin = F3(
	function (prePath, pathSegments, parameters) {
		return prePath + ('/' + (A2($elm$core$String$join, '/', pathSegments) + $elm$url$Url$Builder$toQuery(parameters)));
	});
var $elm$http$Http$BadStatus_ = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $elm$http$Http$BadUrl_ = function (a) {
	return {$: 0, a: a};
};
var $elm$http$Http$GoodStatus_ = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $elm$http$Http$NetworkError_ = {$: 2};
var $elm$http$Http$Receiving = function (a) {
	return {$: 1, a: a};
};
var $elm$http$Http$Sending = function (a) {
	return {$: 0, a: a};
};
var $elm$http$Http$Timeout_ = {$: 1};
var $elm$core$Maybe$isJust = function (maybe) {
	if (!maybe.$) {
		return true;
	} else {
		return false;
	}
};
var $elm$core$Platform$sendToSelf = _Platform_sendToSelf;
var $elm$core$Basics$compare = _Utils_compare;
var $elm$core$Dict$get = F2(
	function (targetKey, dict) {
		get:
		while (true) {
			if (dict.$ === -2) {
				return $elm$core$Maybe$Nothing;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var _v1 = A2($elm$core$Basics$compare, targetKey, key);
				switch (_v1) {
					case 0:
						var $temp$targetKey = targetKey,
							$temp$dict = left;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
					case 1:
						return $elm$core$Maybe$Just(value);
					default:
						var $temp$targetKey = targetKey,
							$temp$dict = right;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
				}
			}
		}
	});
var $elm$core$Dict$Black = 1;
var $elm$core$Dict$RBNode_elm_builtin = F5(
	function (a, b, c, d, e) {
		return {$: -1, a: a, b: b, c: c, d: d, e: e};
	});
var $elm$core$Dict$Red = 0;
var $elm$core$Dict$balance = F5(
	function (color, key, value, left, right) {
		if ((right.$ === -1) && (!right.a)) {
			var _v1 = right.a;
			var rK = right.b;
			var rV = right.c;
			var rLeft = right.d;
			var rRight = right.e;
			if ((left.$ === -1) && (!left.a)) {
				var _v3 = left.a;
				var lK = left.b;
				var lV = left.c;
				var lLeft = left.d;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					key,
					value,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					rK,
					rV,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, left, rLeft),
					rRight);
			}
		} else {
			if ((((left.$ === -1) && (!left.a)) && (left.d.$ === -1)) && (!left.d.a)) {
				var _v5 = left.a;
				var lK = left.b;
				var lV = left.c;
				var _v6 = left.d;
				var _v7 = _v6.a;
				var llK = _v6.b;
				var llV = _v6.c;
				var llLeft = _v6.d;
				var llRight = _v6.e;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					lK,
					lV,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, llK, llV, llLeft, llRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, key, value, lRight, right));
			} else {
				return A5($elm$core$Dict$RBNode_elm_builtin, color, key, value, left, right);
			}
		}
	});
var $elm$core$Dict$insertHelp = F3(
	function (key, value, dict) {
		if (dict.$ === -2) {
			return A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, $elm$core$Dict$RBEmpty_elm_builtin, $elm$core$Dict$RBEmpty_elm_builtin);
		} else {
			var nColor = dict.a;
			var nKey = dict.b;
			var nValue = dict.c;
			var nLeft = dict.d;
			var nRight = dict.e;
			var _v1 = A2($elm$core$Basics$compare, key, nKey);
			switch (_v1) {
				case 0:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						A3($elm$core$Dict$insertHelp, key, value, nLeft),
						nRight);
				case 1:
					return A5($elm$core$Dict$RBNode_elm_builtin, nColor, nKey, value, nLeft, nRight);
				default:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						nLeft,
						A3($elm$core$Dict$insertHelp, key, value, nRight));
			}
		}
	});
var $elm$core$Dict$insert = F3(
	function (key, value, dict) {
		var _v0 = A3($elm$core$Dict$insertHelp, key, value, dict);
		if ((_v0.$ === -1) && (!_v0.a)) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, 1, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Dict$getMin = function (dict) {
	getMin:
	while (true) {
		if ((dict.$ === -1) && (dict.d.$ === -1)) {
			var left = dict.d;
			var $temp$dict = left;
			dict = $temp$dict;
			continue getMin;
		} else {
			return dict;
		}
	}
};
var $elm$core$Dict$moveRedLeft = function (dict) {
	if (((dict.$ === -1) && (dict.d.$ === -1)) && (dict.e.$ === -1)) {
		if ((dict.e.d.$ === -1) && (!dict.e.d.a)) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var lLeft = _v1.d;
			var lRight = _v1.e;
			var _v2 = dict.e;
			var rClr = _v2.a;
			var rK = _v2.b;
			var rV = _v2.c;
			var rLeft = _v2.d;
			var _v3 = rLeft.a;
			var rlK = rLeft.b;
			var rlV = rLeft.c;
			var rlL = rLeft.d;
			var rlR = rLeft.e;
			var rRight = _v2.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				0,
				rlK,
				rlV,
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					rlL),
				A5($elm$core$Dict$RBNode_elm_builtin, 1, rK, rV, rlR, rRight));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v4 = dict.d;
			var lClr = _v4.a;
			var lK = _v4.b;
			var lV = _v4.c;
			var lLeft = _v4.d;
			var lRight = _v4.e;
			var _v5 = dict.e;
			var rClr = _v5.a;
			var rK = _v5.b;
			var rV = _v5.c;
			var rLeft = _v5.d;
			var rRight = _v5.e;
			if (clr === 1) {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$moveRedRight = function (dict) {
	if (((dict.$ === -1) && (dict.d.$ === -1)) && (dict.e.$ === -1)) {
		if ((dict.d.d.$ === -1) && (!dict.d.d.a)) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var _v2 = _v1.d;
			var _v3 = _v2.a;
			var llK = _v2.b;
			var llV = _v2.c;
			var llLeft = _v2.d;
			var llRight = _v2.e;
			var lRight = _v1.e;
			var _v4 = dict.e;
			var rClr = _v4.a;
			var rK = _v4.b;
			var rV = _v4.c;
			var rLeft = _v4.d;
			var rRight = _v4.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				0,
				lK,
				lV,
				A5($elm$core$Dict$RBNode_elm_builtin, 1, llK, llV, llLeft, llRight),
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					lRight,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight)));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v5 = dict.d;
			var lClr = _v5.a;
			var lK = _v5.b;
			var lV = _v5.c;
			var lLeft = _v5.d;
			var lRight = _v5.e;
			var _v6 = dict.e;
			var rClr = _v6.a;
			var rK = _v6.b;
			var rV = _v6.c;
			var rLeft = _v6.d;
			var rRight = _v6.e;
			if (clr === 1) {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$removeHelpPrepEQGT = F7(
	function (targetKey, dict, color, key, value, left, right) {
		if ((left.$ === -1) && (!left.a)) {
			var _v1 = left.a;
			var lK = left.b;
			var lV = left.c;
			var lLeft = left.d;
			var lRight = left.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				lK,
				lV,
				lLeft,
				A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, lRight, right));
		} else {
			_v2$2:
			while (true) {
				if ((right.$ === -1) && (right.a === 1)) {
					if (right.d.$ === -1) {
						if (right.d.a === 1) {
							var _v3 = right.a;
							var _v4 = right.d;
							var _v5 = _v4.a;
							return $elm$core$Dict$moveRedRight(dict);
						} else {
							break _v2$2;
						}
					} else {
						var _v6 = right.a;
						var _v7 = right.d;
						return $elm$core$Dict$moveRedRight(dict);
					}
				} else {
					break _v2$2;
				}
			}
			return dict;
		}
	});
var $elm$core$Dict$removeMin = function (dict) {
	if ((dict.$ === -1) && (dict.d.$ === -1)) {
		var color = dict.a;
		var key = dict.b;
		var value = dict.c;
		var left = dict.d;
		var lColor = left.a;
		var lLeft = left.d;
		var right = dict.e;
		if (lColor === 1) {
			if ((lLeft.$ === -1) && (!lLeft.a)) {
				var _v3 = lLeft.a;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					key,
					value,
					$elm$core$Dict$removeMin(left),
					right);
			} else {
				var _v4 = $elm$core$Dict$moveRedLeft(dict);
				if (_v4.$ === -1) {
					var nColor = _v4.a;
					var nKey = _v4.b;
					var nValue = _v4.c;
					var nLeft = _v4.d;
					var nRight = _v4.e;
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						$elm$core$Dict$removeMin(nLeft),
						nRight);
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			}
		} else {
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				key,
				value,
				$elm$core$Dict$removeMin(left),
				right);
		}
	} else {
		return $elm$core$Dict$RBEmpty_elm_builtin;
	}
};
var $elm$core$Dict$removeHelp = F2(
	function (targetKey, dict) {
		if (dict.$ === -2) {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		} else {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_cmp(targetKey, key) < 0) {
				if ((left.$ === -1) && (left.a === 1)) {
					var _v4 = left.a;
					var lLeft = left.d;
					if ((lLeft.$ === -1) && (!lLeft.a)) {
						var _v6 = lLeft.a;
						return A5(
							$elm$core$Dict$RBNode_elm_builtin,
							color,
							key,
							value,
							A2($elm$core$Dict$removeHelp, targetKey, left),
							right);
					} else {
						var _v7 = $elm$core$Dict$moveRedLeft(dict);
						if (_v7.$ === -1) {
							var nColor = _v7.a;
							var nKey = _v7.b;
							var nValue = _v7.c;
							var nLeft = _v7.d;
							var nRight = _v7.e;
							return A5(
								$elm$core$Dict$balance,
								nColor,
								nKey,
								nValue,
								A2($elm$core$Dict$removeHelp, targetKey, nLeft),
								nRight);
						} else {
							return $elm$core$Dict$RBEmpty_elm_builtin;
						}
					}
				} else {
					return A5(
						$elm$core$Dict$RBNode_elm_builtin,
						color,
						key,
						value,
						A2($elm$core$Dict$removeHelp, targetKey, left),
						right);
				}
			} else {
				return A2(
					$elm$core$Dict$removeHelpEQGT,
					targetKey,
					A7($elm$core$Dict$removeHelpPrepEQGT, targetKey, dict, color, key, value, left, right));
			}
		}
	});
var $elm$core$Dict$removeHelpEQGT = F2(
	function (targetKey, dict) {
		if (dict.$ === -1) {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_eq(targetKey, key)) {
				var _v1 = $elm$core$Dict$getMin(right);
				if (_v1.$ === -1) {
					var minKey = _v1.b;
					var minValue = _v1.c;
					return A5(
						$elm$core$Dict$balance,
						color,
						minKey,
						minValue,
						left,
						$elm$core$Dict$removeMin(right));
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			} else {
				return A5(
					$elm$core$Dict$balance,
					color,
					key,
					value,
					left,
					A2($elm$core$Dict$removeHelp, targetKey, right));
			}
		} else {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		}
	});
var $elm$core$Dict$remove = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$removeHelp, key, dict);
		if ((_v0.$ === -1) && (!_v0.a)) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, 1, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Dict$update = F3(
	function (targetKey, alter, dictionary) {
		var _v0 = alter(
			A2($elm$core$Dict$get, targetKey, dictionary));
		if (!_v0.$) {
			var value = _v0.a;
			return A3($elm$core$Dict$insert, targetKey, value, dictionary);
		} else {
			return A2($elm$core$Dict$remove, targetKey, dictionary);
		}
	});
var $elm$core$Basics$composeR = F3(
	function (f, g, x) {
		return g(
			f(x));
	});
var $elm$http$Http$expectStringResponse = F2(
	function (toMsg, toResult) {
		return A3(
			_Http_expect,
			'',
			$elm$core$Basics$identity,
			A2($elm$core$Basics$composeR, toResult, toMsg));
	});
var $elm$http$Http$BadBody = function (a) {
	return {$: 4, a: a};
};
var $elm$http$Http$BadStatus = function (a) {
	return {$: 3, a: a};
};
var $elm$http$Http$BadUrl = function (a) {
	return {$: 0, a: a};
};
var $elm$http$Http$NetworkError = {$: 2};
var $elm$http$Http$Timeout = {$: 1};
var $elm$core$Result$mapError = F2(
	function (f, result) {
		if (!result.$) {
			var v = result.a;
			return $elm$core$Result$Ok(v);
		} else {
			var e = result.a;
			return $elm$core$Result$Err(
				f(e));
		}
	});
var $elm$http$Http$resolve = F2(
	function (toResult, response) {
		switch (response.$) {
			case 0:
				var url = response.a;
				return $elm$core$Result$Err(
					$elm$http$Http$BadUrl(url));
			case 1:
				return $elm$core$Result$Err($elm$http$Http$Timeout);
			case 2:
				return $elm$core$Result$Err($elm$http$Http$NetworkError);
			case 3:
				var metadata = response.a;
				return $elm$core$Result$Err(
					$elm$http$Http$BadStatus(metadata.lV));
			default:
				var body = response.b;
				return A2(
					$elm$core$Result$mapError,
					$elm$http$Http$BadBody,
					toResult(body));
		}
	});
var $elm$http$Http$expectString = function (toMsg) {
	return A2(
		$elm$http$Http$expectStringResponse,
		toMsg,
		$elm$http$Http$resolve($elm$core$Result$Ok));
};
var $elm$http$Http$emptyBody = _Http_emptyBody;
var $elm$http$Http$Request = function (a) {
	return {$: 1, a: a};
};
var $elm$http$Http$State = F2(
	function (reqs, subs) {
		return {i1: reqs, jo: subs};
	});
var $elm$http$Http$init = $elm$core$Task$succeed(
	A2($elm$http$Http$State, $elm$core$Dict$empty, _List_Nil));
var $elm$core$Process$kill = _Scheduler_kill;
var $elm$core$Process$spawn = _Scheduler_spawn;
var $elm$http$Http$updateReqs = F3(
	function (router, cmds, reqs) {
		updateReqs:
		while (true) {
			if (!cmds.b) {
				return $elm$core$Task$succeed(reqs);
			} else {
				var cmd = cmds.a;
				var otherCmds = cmds.b;
				if (!cmd.$) {
					var tracker = cmd.a;
					var _v2 = A2($elm$core$Dict$get, tracker, reqs);
					if (_v2.$ === 1) {
						var $temp$router = router,
							$temp$cmds = otherCmds,
							$temp$reqs = reqs;
						router = $temp$router;
						cmds = $temp$cmds;
						reqs = $temp$reqs;
						continue updateReqs;
					} else {
						var pid = _v2.a;
						return A2(
							$elm$core$Task$andThen,
							function (_v3) {
								return A3(
									$elm$http$Http$updateReqs,
									router,
									otherCmds,
									A2($elm$core$Dict$remove, tracker, reqs));
							},
							$elm$core$Process$kill(pid));
					}
				} else {
					var req = cmd.a;
					return A2(
						$elm$core$Task$andThen,
						function (pid) {
							var _v4 = req.g_;
							if (_v4.$ === 1) {
								return A3($elm$http$Http$updateReqs, router, otherCmds, reqs);
							} else {
								var tracker = _v4.a;
								return A3(
									$elm$http$Http$updateReqs,
									router,
									otherCmds,
									A3($elm$core$Dict$insert, tracker, pid, reqs));
							}
						},
						$elm$core$Process$spawn(
							A3(
								_Http_toTask,
								router,
								$elm$core$Platform$sendToApp(router),
								req)));
				}
			}
		}
	});
var $elm$http$Http$onEffects = F4(
	function (router, cmds, subs, state) {
		return A2(
			$elm$core$Task$andThen,
			function (reqs) {
				return $elm$core$Task$succeed(
					A2($elm$http$Http$State, reqs, subs));
			},
			A3($elm$http$Http$updateReqs, router, cmds, state.i1));
	});
var $elm$core$List$maybeCons = F3(
	function (f, mx, xs) {
		var _v0 = f(mx);
		if (!_v0.$) {
			var x = _v0.a;
			return A2($elm$core$List$cons, x, xs);
		} else {
			return xs;
		}
	});
var $elm$core$List$filterMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			$elm$core$List$maybeCons(f),
			_List_Nil,
			xs);
	});
var $elm$http$Http$maybeSend = F4(
	function (router, desiredTracker, progress, _v0) {
		var actualTracker = _v0.a;
		var toMsg = _v0.b;
		return _Utils_eq(desiredTracker, actualTracker) ? $elm$core$Maybe$Just(
			A2(
				$elm$core$Platform$sendToApp,
				router,
				toMsg(progress))) : $elm$core$Maybe$Nothing;
	});
var $elm$http$Http$onSelfMsg = F3(
	function (router, _v0, state) {
		var tracker = _v0.a;
		var progress = _v0.b;
		return A2(
			$elm$core$Task$andThen,
			function (_v1) {
				return $elm$core$Task$succeed(state);
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$filterMap,
					A3($elm$http$Http$maybeSend, router, tracker, progress),
					state.jo)));
	});
var $elm$http$Http$Cancel = function (a) {
	return {$: 0, a: a};
};
var $elm$http$Http$cmdMap = F2(
	function (func, cmd) {
		if (!cmd.$) {
			var tracker = cmd.a;
			return $elm$http$Http$Cancel(tracker);
		} else {
			var r = cmd.a;
			return $elm$http$Http$Request(
				{
					jQ: r.jQ,
					e6: r.e6,
					fp: A2(_Http_mapExpect, func, r.fp),
					fA: r.fA,
					f_: r.f_,
					gV: r.gV,
					g_: r.g_,
					g2: r.g2
				});
		}
	});
var $elm$http$Http$MySub = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$http$Http$subMap = F2(
	function (func, _v0) {
		var tracker = _v0.a;
		var toMsg = _v0.b;
		return A2(
			$elm$http$Http$MySub,
			tracker,
			A2($elm$core$Basics$composeR, toMsg, func));
	});
_Platform_effectManagers['Http'] = _Platform_createManager($elm$http$Http$init, $elm$http$Http$onEffects, $elm$http$Http$onSelfMsg, $elm$http$Http$cmdMap, $elm$http$Http$subMap);
var $elm$http$Http$command = _Platform_leaf('Http');
var $elm$http$Http$subscription = _Platform_leaf('Http');
var $elm$http$Http$request = function (r) {
	return $elm$http$Http$command(
		$elm$http$Http$Request(
			{jQ: false, e6: r.e6, fp: r.fp, fA: r.fA, f_: r.f_, gV: r.gV, g_: r.g_, g2: r.g2}));
};
var $elm$http$Http$get = function (r) {
	return $elm$http$Http$request(
		{e6: $elm$http$Http$emptyBody, fp: r.fp, fA: _List_Nil, f_: 'GET', gV: $elm$core$Maybe$Nothing, g_: $elm$core$Maybe$Nothing, g2: r.g2});
};
var $elm$url$Url$Builder$QueryParameter = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$url$Url$percentEncode = _Url_percentEncode;
var $elm$url$Url$Builder$string = F2(
	function (key, value) {
		return A2(
			$elm$url$Url$Builder$QueryParameter,
			$elm$url$Url$percentEncode(key),
			$elm$url$Url$percentEncode(value));
	});
var $author$project$Tsinfo$getcachepolicy = F2(
	function (baseUrl, name) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString($author$project$Tsinfo$GotCachePolicy),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					baseUrl,
					_List_fromArray(
						['api', 'cache', 'series-policy']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name)
						]))
			});
	});
var $author$project$Tsinfo$GotSource = function (a) {
	return {$: 2, a: a};
};
var $author$project$Tsinfo$getsource = F2(
	function (baseurl, name) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString($author$project$Tsinfo$GotSource),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					baseurl,
					_List_fromArray(
						['api', 'series', 'source']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name)
						]))
			});
	});
var $author$project$Metadata$getsysmetadata = F4(
	function (urlprefix, name, callback, dtype) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(callback),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					urlprefix,
					_List_fromArray(
						['api', dtype, 'metadata']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name),
							A2($elm$url$Url$Builder$string, 'type', 'internal')
						]))
			});
	});
var $author$project$Metadata$getusermetadata = F4(
	function (urlprefix, name, callback, dtype) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(callback),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					urlprefix,
					_List_fromArray(
						['api', dtype, 'metadata']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name)
						]))
			});
	});
var $author$project$Info$getwriteperms = F2(
	function (urlprefix, event) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(event),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					urlprefix,
					_List_fromArray(
						['tsinfo', 'canwrite']),
					_List_Nil)
			});
	});
var $author$project$Horizon$All = {$: 0};
var $author$project$Horizon$buildBounds = F2(
	function (min, max) {
		return ((min === 'None') || (min === '')) ? $elm$core$Maybe$Nothing : (((max === 'None') || (max === '')) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
			_Utils_Tuple2(min, max)));
	});
var $author$project$Horizon$completeDate = function (date) {
	return ($elm$core$String$length(date) === 10) ? (date + ' 00:00:00') : date;
};
var $author$project$Horizon$completeDates = function (bounds) {
	if (bounds.$ === 1) {
		return $elm$core$Maybe$Nothing;
	} else {
		var _v1 = bounds.a;
		var min = _v1.a;
		var max = _v1.b;
		return $elm$core$Maybe$Just(
			_Utils_Tuple2(
				$author$project$Horizon$completeDate(min),
				$author$project$Horizon$completeDate(max)));
	}
};
var $author$project$Horizon$timezones = _List_fromArray(
	['UTC', 'CET', 'Europe/London']);
var $author$project$Horizon$initHorizon = F5(
	function (baseUrl, min, max, debug, status) {
		return {
			dl: baseUrl,
			b0: $elm$core$Maybe$Nothing,
			bc: 'yyyy-mm-dd',
			ff: debug === '1',
			b1: false,
			ax: {aA: $elm$core$Maybe$Nothing, aF: $elm$core$Maybe$Nothing},
			fz: true,
			A: $author$project$Horizon$All,
			bh: $elm$core$Maybe$Nothing,
			dB: _List_Nil,
			Y: false,
			T: status,
			aD: $author$project$Horizon$completeDates(
				A2($author$project$Horizon$buildBounds, min, max)),
			ab: 'UTC',
			gW: $author$project$Horizon$timezones,
			d1: false,
			bW: $elm$core$Maybe$Nothing,
			e_: $elm$core$Maybe$Nothing
		};
	});
var $Gizra$elm_debouncer$Debouncer$Internal$Config = $elm$core$Basics$identity;
var $Gizra$elm_debouncer$Debouncer$Internal$lastInput = F2(
	function (i, o) {
		return $elm$core$Maybe$Just(i);
	});
var $Gizra$elm_debouncer$Debouncer$Internal$manual = {bY: $Gizra$elm_debouncer$Debouncer$Internal$lastInput, aU: $elm$core$Maybe$Nothing, aV: $elm$core$Maybe$Nothing, a1: $elm$core$Maybe$Nothing};
var $Gizra$elm_debouncer$Debouncer$Basic$manual = $Gizra$elm_debouncer$Debouncer$Internal$manual;
var $Gizra$elm_debouncer$Debouncer$Messages$manual = $Gizra$elm_debouncer$Debouncer$Basic$manual;
var $Gizra$elm_debouncer$Debouncer$Internal$settleWhenQuietFor = F2(
	function (time, _v0) {
		var config = _v0;
		return _Utils_update(
			config,
			{a1: time});
	});
var $Gizra$elm_debouncer$Debouncer$Basic$settleWhenQuietFor = $Gizra$elm_debouncer$Debouncer$Internal$settleWhenQuietFor;
var $Gizra$elm_debouncer$Debouncer$Messages$settleWhenQuietFor = $Gizra$elm_debouncer$Debouncer$Basic$settleWhenQuietFor;
var $Gizra$elm_debouncer$Debouncer$Internal$Debouncer = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $Gizra$elm_debouncer$Debouncer$Internal$Settled = {$: 0};
var $elm$core$Maybe$andThen = F2(
	function (callback, maybeValue) {
		if (!maybeValue.$) {
			var value = maybeValue.a;
			return callback(value);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $Gizra$elm_debouncer$Debouncer$Internal$nothingIfNegative = $elm$core$Maybe$andThen(
	function (num) {
		return (num < 0) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(num);
	});
var $Gizra$elm_debouncer$Debouncer$Internal$sanitizeConfig = function (_v0) {
	var config = _v0;
	return {
		bY: config.bY,
		aU: $Gizra$elm_debouncer$Debouncer$Internal$nothingIfNegative(config.aU),
		aV: $Gizra$elm_debouncer$Debouncer$Internal$nothingIfNegative(config.aV),
		a1: $Gizra$elm_debouncer$Debouncer$Internal$nothingIfNegative(config.a1)
	};
};
var $Gizra$elm_debouncer$Debouncer$Internal$toDebouncer = function (config) {
	return A2(
		$Gizra$elm_debouncer$Debouncer$Internal$Debouncer,
		$Gizra$elm_debouncer$Debouncer$Internal$sanitizeConfig(config),
		$Gizra$elm_debouncer$Debouncer$Internal$Settled);
};
var $Gizra$elm_debouncer$Debouncer$Basic$toDebouncer = $Gizra$elm_debouncer$Debouncer$Internal$toDebouncer;
var $Gizra$elm_debouncer$Debouncer$Messages$toDebouncer = $Gizra$elm_debouncer$Debouncer$Basic$toDebouncer;
var $author$project$Tsinfo$init = function (input) {
	var debouncerconfig = $Gizra$elm_debouncer$Debouncer$Messages$toDebouncer(
		A2(
			$Gizra$elm_debouncer$Debouncer$Messages$settleWhenQuietFor,
			$elm$core$Maybe$Just(
				$Gizra$elm_debouncer$Debouncer$Messages$fromSeconds(0.015)),
			$Gizra$elm_debouncer$Debouncer$Messages$manual));
	return _Utils_Tuple2(
		{
			df: 0,
			bv: input.bv,
			j2: false,
			$7: 'bi bi-clipboard',
			aI: $elm$core$Maybe$Nothing,
			ki: 0,
			eb: debouncerconfig,
			ff: false,
			kn: false,
			cu: false,
			ed: false,
			ku: $elm$core$Dict$empty,
			hI: false,
			hL: _List_Nil,
			ft: $elm$core$Dict$empty,
			hR: 0,
			hS: 0,
			kG: 0,
			ei: debouncerconfig,
			ej: $elm$core$Array$empty,
			b5: false,
			kH: $elm$core$Dict$empty,
			A: A5($author$project$Horizon$initHorizon, input.bv, input.f0, input.fY, input.ff, 1),
			kN: $elm$core$Array$empty,
			ih: $elm$core$Array$empty,
			im: _List_Nil,
			kX: $elm$core$Maybe$Just(10),
			aM: $elm$core$Maybe$Just(0),
			cN: $elm$core$Dict$empty,
			iq: _Utils_Tuple2('', ''),
			ao: input.ao,
			bH: 0,
			iA: $elm$core$Maybe$Nothing,
			eD: false,
			dK: $elm$core$Dict$empty,
			dL: 0,
			lE: false,
			jd: 0,
			gO: '',
			eT: $elm$core$Dict$empty,
			g3: $elm$core$Dict$empty
		},
		$elm$core$Platform$Cmd$batch(
			_List_fromArray(
				[
					A4($author$project$Metadata$getsysmetadata, input.bv, input.ao, $author$project$Tsinfo$GotSysMeta, 'series'),
					A4($author$project$Metadata$getusermetadata, input.bv, input.ao, $author$project$Tsinfo$GotUserMeta, 'series'),
					A2($author$project$Tsinfo$getsource, input.bv, input.ao),
					A2($author$project$Info$getwriteperms, input.bv, $author$project$Tsinfo$GetPermissions),
					A2($author$project$Tsinfo$getcachepolicy, input.bv, input.ao)
				])));
};
var $author$project$Horizon$loadFromLocalStorage = _Platform_incomingPort('loadFromLocalStorage', $elm$json$Json$Decode$string);
var $elm$json$Json$Decode$bool = _Json_decodeBool;
var $author$project$Tsinfo$panActive = _Platform_incomingPort('panActive', $elm$json$Json$Decode$bool);
var $author$project$Tsinfo$Deleted = function (a) {
	return {$: 32, a: a};
};
var $author$project$Horizon$Failure = 3;
var $author$project$Info$Formula = 1;
var $author$project$Tsinfo$GotFormula = function (a) {
	return {$: 10, a: a};
};
var $author$project$Tsinfo$GotLog = function (a) {
	return {$: 5, a: a};
};
var $author$project$Tsinfo$HistoryMode = function (a) {
	return {$: 41, a: a};
};
var $author$project$Tsinfo$InsertionDates = function (a) {
	return {$: 11, a: a};
};
var $author$project$Metadata$MString = function (a) {
	return {$: 0, a: a};
};
var $author$project$Tsinfo$MetaSaved = function (a) {
	return {$: 28, a: a};
};
var $author$project$Tsinfo$Renamed = function (a) {
	return {$: 37, a: a};
};
var $author$project$Tsinfo$ResetClipboardClass = {$: 39};
var $elm$core$List$append = F2(
	function (xs, ys) {
		if (!ys.b) {
			return xs;
		} else {
			return A3($elm$core$List$foldr, $elm$core$List$cons, ys, xs);
		}
	});
var $author$project$Util$adderror = F2(
	function (model, error) {
		return _Utils_update(
			model,
			{
				hL: A2(
					$elm$core$List$append,
					model.hL,
					_List_fromArray(
						[error]))
			});
	});
var $author$project$Tsinfo$addError = F3(
	function (model, tag, error) {
		return A2($author$project$Util$adderror, model, tag + (' -> ' + error));
	});
var $elm$core$Basics$always = F2(
	function (a, _v0) {
		return a;
	});
var $author$project$Util$cleanupdate = function (date) {
	var _v0 = A2($elm$core$String$split, '+', date);
	if (_v0.b) {
		var head = _v0.a;
		var _v1 = A2($elm$core$String$split, '.', head);
		if (_v1.b) {
			var newhead = _v1.a;
			return newhead;
		} else {
			return '';
		}
	} else {
		return '';
	}
};
var $elm$json$Json$Encode$string = _Json_wrap;
var $author$project$Tsinfo$copyToClipboard = _Platform_outgoingPort('copyToClipboard', $elm$json$Json$Encode$string);
var $author$project$Tsinfo$DataFromHover = F2(
	function (name, data) {
		return {kh: data, ao: name};
	});
var $author$project$Tsinfo$DataItem = F2(
	function (date, value) {
		return {ea: date, me: value};
	});
var $elm$json$Json$Decode$float = _Json_decodeFloat;
var $author$project$Tsinfo$dataItemDecoder = A3(
	$elm$json$Json$Decode$map2,
	$author$project$Tsinfo$DataItem,
	A2($elm$json$Json$Decode$field, 'date', $elm$json$Json$Decode$string),
	A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$float));
var $elm$json$Json$Decode$list = _Json_decodeList;
var $author$project$Tsinfo$dataFromHoverDecoder = A3(
	$elm$json$Json$Decode$map2,
	$author$project$Tsinfo$DataFromHover,
	A2($elm$json$Json$Decode$field, 'name', $elm$json$Json$Decode$string),
	A2(
		$elm$json$Json$Decode$field,
		'data',
		$elm$json$Json$Decode$list($author$project$Tsinfo$dataItemDecoder)));
var $elm$json$Json$Decode$decodeString = _Json_runOnString;
var $author$project$Metadata$MBool = function (a) {
	return {$: 3, a: a};
};
var $author$project$Metadata$MFloat = function (a) {
	return {$: 2, a: a};
};
var $author$project$Metadata$MInt = function (a) {
	return {$: 1, a: a};
};
var $author$project$Metadata$MList = function (a) {
	return {$: 4, a: a};
};
var $author$project$Metadata$Mnull = function (a) {
	return {$: 5, a: a};
};
var $elm$json$Json$Decode$int = _Json_decodeInt;
var $elm$json$Json$Decode$lazy = function (thunk) {
	return A2(
		$elm$json$Json$Decode$andThen,
		thunk,
		$elm$json$Json$Decode$succeed(0));
};
var $elm$json$Json$Decode$null = _Json_decodeNull;
var $elm$json$Json$Decode$oneOf = _Json_oneOf;
function $author$project$Metadata$cyclic$decodemetaval() {
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				A2($elm$json$Json$Decode$map, $author$project$Metadata$MString, $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$map, $author$project$Metadata$MInt, $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$map, $author$project$Metadata$MFloat, $elm$json$Json$Decode$float),
				A2($elm$json$Json$Decode$map, $author$project$Metadata$MBool, $elm$json$Json$Decode$bool),
				A2(
				$elm$json$Json$Decode$map,
				$author$project$Metadata$Mnull,
				$elm$json$Json$Decode$null('')),
				A2(
				$elm$json$Json$Decode$map,
				$author$project$Metadata$MList,
				$elm$json$Json$Decode$list(
					$elm$json$Json$Decode$lazy(
						function (_v0) {
							return $author$project$Metadata$cyclic$decodemetaval();
						})))
			]));
}
var $author$project$Metadata$decodemetaval = $author$project$Metadata$cyclic$decodemetaval();
$author$project$Metadata$cyclic$decodemetaval = function () {
	return $author$project$Metadata$decodemetaval;
};
var $elm$core$Dict$fromList = function (assocs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, dict) {
				var key = _v0.a;
				var value = _v0.b;
				return A3($elm$core$Dict$insert, key, value, dict);
			}),
		$elm$core$Dict$empty,
		assocs);
};
var $elm$json$Json$Decode$keyValuePairs = _Json_decodeKeyValuePairs;
var $elm$json$Json$Decode$dict = function (decoder) {
	return A2(
		$elm$json$Json$Decode$map,
		$elm$core$Dict$fromList,
		$elm$json$Json$Decode$keyValuePairs(decoder));
};
var $author$project$Metadata$decodemeta = $elm$json$Json$Decode$dict($author$project$Metadata$decodemetaval);
var $author$project$Tsinfo$defaultRevMaxFormula = 10;
var $author$project$Tsinfo$defaultRevMaxPrimary = 70;
var $author$project$Info$delete = F3(
	function (model, dtype, event) {
		return $elm$http$Http$request(
			{
				e6: $elm$http$Http$emptyBody,
				fp: $elm$http$Http$expectString(event),
				fA: _List_Nil,
				f_: 'delete',
				gV: $elm$core$Maybe$Nothing,
				g_: $elm$core$Maybe$Nothing,
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.bv,
					_List_fromArray(
						['api', dtype, 'state']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', model.ao)
						]))
			});
	});
var $author$project$Tsinfo$CacheDeleted = function (a) {
	return {$: 18, a: a};
};
var $elm$http$Http$jsonBody = function (value) {
	return A2(
		_Http_pair,
		'application/json',
		A2($elm$json$Json$Encode$encode, 0, value));
};
var $elm$json$Json$Encode$object = function (pairs) {
	return _Json_wrap(
		A3(
			$elm$core$List$foldl,
			F2(
				function (_v0, obj) {
					var k = _v0.a;
					var v = _v0.b;
					return A3(_Json_addField, k, v, obj);
				}),
			_Json_emptyObject(0),
			pairs));
};
var $author$project$Tsinfo$deletecache = function (model) {
	return $elm$http$Http$request(
		{
			e6: $elm$http$Http$jsonBody(
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'name',
							$elm$json$Json$Encode$string(model.ao))
						]))),
			fp: $elm$http$Http$expectString($author$project$Tsinfo$CacheDeleted),
			fA: _List_Nil,
			f_: 'DELETE',
			gV: $elm$core$Maybe$Nothing,
			g_: $elm$core$Maybe$Nothing,
			g2: A3(
				$elm$url$Url$Builder$crossOrigin,
				model.bv,
				_List_fromArray(
					['api', 'cache', 'series-has-cache']),
				_List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao)
					]))
		});
};
var $author$project$Horizon$Zoom = F2(
	function (x, y) {
		return {de: x, cl: y};
	});
var $elm$core$String$replace = F3(
	function (before, after, string) {
		return A2(
			$elm$core$String$join,
			after,
			A2($elm$core$String$split, before, string));
	});
var $author$project$Horizon$curateDate = function (_v0) {
	var start = _v0.a;
	var end = _v0.b;
	return _Utils_Tuple2(
		A2($elm$core$String$replace, ' ', 'T')(start),
		A2($elm$core$String$replace, ' ', 'T')(end));
};
var $elm$core$Basics$isNaN = _Basics_isNaN;
var $elm$core$Tuple$second = function (_v0) {
	var y = _v0.b;
	return y;
};
var $author$project$Horizon$extractZoomDates = function (zoom) {
	var yZoom = function () {
		var _v3 = $elm$core$Basics$isNaN(zoom.b.a);
		if (_v3) {
			return $elm$core$Maybe$Nothing;
		} else {
			return $elm$core$Maybe$Just(zoom.b);
		}
	}();
	var xZoom = _Utils_eq(
		zoom.a,
		_Utils_Tuple2('', '')) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
		$author$project$Horizon$curateDate(zoom.a));
	if (xZoom.$ === 1) {
		if (yZoom.$ === 1) {
			return A2($author$project$Horizon$Zoom, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing);
		} else {
			var yzoom = yZoom.a;
			return A2(
				$author$project$Horizon$Zoom,
				$elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just(yzoom));
		}
	} else {
		var xzoom = xZoom.a;
		if (yZoom.$ === 1) {
			return A2(
				$author$project$Horizon$Zoom,
				$elm$core$Maybe$Just(xzoom),
				$elm$core$Maybe$Nothing);
		} else {
			var yzoom = yZoom.a;
			return A2(
				$author$project$Horizon$Zoom,
				$elm$core$Maybe$Just(xzoom),
				$elm$core$Maybe$Just(yzoom));
		}
	}
};
var $elm$core$Array$fromListHelp = F3(
	function (list, nodeList, nodeListSize) {
		fromListHelp:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, list);
			var jsArray = _v0.a;
			var remainingItems = _v0.b;
			if (_Utils_cmp(
				$elm$core$Elm$JsArray$length(jsArray),
				$elm$core$Array$branchFactor) < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					true,
					{O: nodeList, D: nodeListSize, J: jsArray});
			} else {
				var $temp$list = remainingItems,
					$temp$nodeList = A2(
					$elm$core$List$cons,
					$elm$core$Array$Leaf(jsArray),
					nodeList),
					$temp$nodeListSize = nodeListSize + 1;
				list = $temp$list;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue fromListHelp;
			}
		}
	});
var $elm$core$Array$fromList = function (list) {
	if (!list.b) {
		return $elm$core$Array$empty;
	} else {
		return A3($elm$core$Array$fromListHelp, list, _List_Nil, 0);
	}
};
var $elm$core$Array$filter = F2(
	function (isGood, array) {
		return $elm$core$Array$fromList(
			A3(
				$elm$core$Array$foldr,
				F2(
					function (x, xs) {
						return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
					}),
				_List_Nil,
				array));
	});
var $author$project$Util$first = $elm$core$Tuple$first;
var $author$project$Info$FormulaResponse = F2(
	function (level, formula) {
		return {ft: formula, kV: level};
	});
var $author$project$Info$formuladecoder = A3(
	$elm$json$Json$Decode$map2,
	$author$project$Info$FormulaResponse,
	A2($elm$json$Json$Decode$field, 'level', $elm$json$Json$Decode$int),
	A2($elm$json$Json$Decode$field, 'formula', $elm$json$Json$Decode$string));
var $elm$core$Bitwise$and = _Bitwise_and;
var $elm$core$Bitwise$shiftRightZfBy = _Bitwise_shiftRightZfBy;
var $elm$core$Array$bitMask = 4294967295 >>> (32 - $elm$core$Array$shiftStep);
var $elm$core$Basics$ge = _Utils_ge;
var $elm$core$Elm$JsArray$unsafeGet = _JsArray_unsafeGet;
var $elm$core$Array$getHelp = F3(
	function (shift, index, tree) {
		getHelp:
		while (true) {
			var pos = $elm$core$Array$bitMask & (index >>> shift);
			var _v0 = A2($elm$core$Elm$JsArray$unsafeGet, pos, tree);
			if (!_v0.$) {
				var subTree = _v0.a;
				var $temp$shift = shift - $elm$core$Array$shiftStep,
					$temp$index = index,
					$temp$tree = subTree;
				shift = $temp$shift;
				index = $temp$index;
				tree = $temp$tree;
				continue getHelp;
			} else {
				var values = _v0.a;
				return A2($elm$core$Elm$JsArray$unsafeGet, $elm$core$Array$bitMask & index, values);
			}
		}
	});
var $elm$core$Bitwise$shiftLeftBy = _Bitwise_shiftLeftBy;
var $elm$core$Array$tailIndex = function (len) {
	return (len >>> 5) << 5;
};
var $elm$core$Array$get = F2(
	function (index, _v0) {
		var len = _v0.a;
		var startShift = _v0.b;
		var tree = _v0.c;
		var tail = _v0.d;
		return ((index < 0) || (_Utils_cmp(index, len) > -1)) ? $elm$core$Maybe$Nothing : ((_Utils_cmp(
			index,
			$elm$core$Array$tailIndex(len)) > -1) ? $elm$core$Maybe$Just(
			A2($elm$core$Elm$JsArray$unsafeGet, $elm$core$Array$bitMask & index, tail)) : $elm$core$Maybe$Just(
			A3($elm$core$Array$getHelp, startShift, index, tree)));
	});
var $author$project$Tsinfo$GotVersion = F2(
	function (a, b) {
		return {$: 45, a: a, b: b};
	});
var $author$project$Util$bool2int = function (b) {
	return b ? 1 : 0;
};
var $author$project$Horizon$getFromToDates = function (model) {
	var _v0 = model.bW;
	if (!_v0.$) {
		var _v1 = _v0.a;
		var min = _v1.a;
		var max = _v1.b;
		return $elm$core$Maybe$Just(
			_Utils_Tuple2(min, max));
	} else {
		var _v2 = model.aD;
		if (!_v2.$) {
			var _v3 = _v2.a;
			var min = _v3.a;
			var max = _v3.b;
			return $elm$core$Maybe$Just(
				_Utils_Tuple2(min, max));
		} else {
			var _v4 = model.bh;
			if (!_v4.$) {
				var _v5 = _v4.a;
				var min = _v5.a;
				var max = _v5.b;
				return $elm$core$Maybe$Just(
					_Utils_Tuple2(min, max));
			} else {
				return $elm$core$Maybe$Nothing;
			}
		}
	}
};
var $elm$url$Url$Builder$int = F2(
	function (key, value) {
		return A2(
			$elm$url$Url$Builder$QueryParameter,
			$elm$url$Url$percentEncode(key),
			$elm$core$String$fromInt(value));
	});
var $author$project$Tsinfo$getVersions = F2(
	function (model, idates) {
		var bounds = $author$project$Horizon$getFromToDates(model.A);
		var boundQuery = function () {
			if (bounds.$ === 1) {
				return _List_Nil;
			} else {
				var _v1 = bounds.a;
				var min = _v1.a;
				var max = _v1.b;
				return _List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'from_value_date', min),
						A2($elm$url$Url$Builder$string, 'to_value_date', max)
					]);
			}
		}();
		var baseQuery = function (idate) {
			return _List_fromArray(
				[
					A2($elm$url$Url$Builder$string, 'name', model.ao),
					A2($elm$url$Url$Builder$string, 'insertion_date', idate),
					A2(
					$elm$url$Url$Builder$int,
					'inferred_freq',
					$author$project$Util$bool2int(model.A.Y)),
					A2($elm$url$Url$Builder$string, 'tzone', model.A.ab),
					A2(
					$elm$url$Url$Builder$int,
					'nocache',
					$author$project$Util$bool2int(model.A.d1))
				]);
		};
		var getVersion = function (idate) {
			return $elm$http$Http$get(
				{
					fp: $elm$http$Http$expectString(
						$author$project$Tsinfo$GotVersion(idate)),
					g2: A3(
						$elm$url$Url$Builder$crossOrigin,
						model.bv,
						_List_fromArray(
							['api', 'series', 'state']),
						_Utils_ap(
							baseQuery(idate),
							boundQuery))
				});
		};
		return $elm$core$Platform$Cmd$batch(
			A2($elm$core$List$map, getVersion, idates));
	});
var $author$project$Tsinfo$GotDepth = function (a) {
	return {$: 12, a: a};
};
var $author$project$Tsinfo$getdepth = function (model) {
	return $elm$http$Http$get(
		{
			fp: $elm$http$Http$expectString($author$project$Tsinfo$GotDepth),
			g2: A3(
				$elm$url$Url$Builder$crossOrigin,
				model.bv,
				_List_fromArray(
					['api', 'series', 'formula_depth']),
				_List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao)
					]))
		});
};
var $author$project$Info$getformula = F5(
	function (model, name, depth, dtype, callback) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(callback),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.bv,
					_List_fromArray(
						['api', dtype, 'formula']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name),
							A2($elm$url$Url$Builder$int, 'display', 1),
							A2($elm$url$Url$Builder$int, 'level', depth)
						]))
			});
	});
var $author$project$Tsinfo$HasCache = function (a) {
	return {$: 14, a: a};
};
var $author$project$Tsinfo$gethascache = function (model) {
	return $elm$http$Http$get(
		{
			fp: $elm$http$Http$expectString($author$project$Tsinfo$HasCache),
			g2: A3(
				$elm$url$Url$Builder$crossOrigin,
				model.bv,
				_List_fromArray(
					['api', 'cache', 'series-has-cache']),
				_List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao)
					]))
		});
};
var $author$project$Info$getidates = F4(
	function (model, dtype, callback, viewnocache) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(callback),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.bv,
					_List_fromArray(
						['api', dtype, 'insertion_dates']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', model.ao),
							A2(
							$elm$url$Url$Builder$int,
							'nocache',
							$author$project$Util$bool2int(viewnocache))
						]))
			});
	});
var $elm$core$Maybe$withDefault = F2(
	function (_default, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return value;
		} else {
			return _default;
		}
	});
var $author$project$Info$getlog = F5(
	function (urlprefix, name, logLimit, dtype, callback) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(callback),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					urlprefix,
					_List_fromArray(
						['api', dtype, 'log']),
					_List_fromArray(
						[
							A2($elm$url$Url$Builder$string, 'name', name),
							A2(
							$elm$url$Url$Builder$int,
							'limit',
							A2($elm$core$Maybe$withDefault, 10, logLimit))
						]))
			});
	});
var $author$project$Tsinfo$GotPlotData = function (a) {
	return {$: 6, a: a};
};
var $author$project$Horizon$getFetchBounds = function (model) {
	var _v0 = model.aD;
	if (!_v0.$) {
		var _v1 = _v0.a;
		var from = _v1.a;
		var to = _v1.b;
		return _Utils_Tuple2(from, to);
	} else {
		var _v2 = model.bh;
		if (!_v2.$) {
			var _v3 = _v2.a;
			var from = _v3.a;
			var to = _v3.b;
			return _Utils_Tuple2(from, to);
		} else {
			return _Utils_Tuple2('', '');
		}
	}
};
var $elm$core$String$trim = _String_trim;
var $elm_community$maybe_extra$Maybe$Extra$unwrap = F3(
	function (_default, f, m) {
		if (m.$ === 1) {
			return _default;
		} else {
			var a = m.a;
			return f(a);
		}
	});
var $elm_community$maybe_extra$Maybe$Extra$cons = F2(
	function (item, list) {
		if (!item.$) {
			var v = item.a;
			return A2($elm$core$List$cons, v, list);
		} else {
			return list;
		}
	});
var $elm_community$maybe_extra$Maybe$Extra$values = A2($elm$core$List$foldr, $elm_community$maybe_extra$Maybe$Extra$cons, _List_Nil);
var $author$project$Plotter$getdata = function (query) {
	var stringToMaybe = F2(
		function (name, value) {
			return (value === '') ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
				A2($elm$url$Url$Builder$string, name, value));
		});
	var fullquery = $elm_community$maybe_extra$Maybe$Extra$values(
		_Utils_ap(
			_List_fromArray(
				[
					A2(stringToMaybe, 'name', query.ao),
					A2(
					$elm$core$Maybe$andThen,
					stringToMaybe('insertion_date'),
					query.h0),
					$elm$core$Maybe$Just(
					A2($elm$url$Url$Builder$int, 'nocache', query.iC)),
					A2(
					stringToMaybe,
					'_keep_nans',
					query.id ? 'true' : 'false'),
					A2(
					stringToMaybe,
					'inferred_freq',
					query.Y ? 'true' : 'false'),
					A2(stringToMaybe, 'tzone', query.jC)
				]),
			A3(
				$elm_community$maybe_extra$Maybe$Extra$unwrap,
				_List_fromArray(
					[
						A2(stringToMaybe, 'from_value_date', query.hU),
						A2(stringToMaybe, 'to_value_date', query.jw)
					]),
				function (horizonstr) {
					return _List_fromArray(
						[
							A2(
							stringToMaybe,
							'horizon',
							$elm$core$String$trim(horizonstr))
						]);
				},
				query.A)));
	return $elm$http$Http$get(
		{
			fp: $elm$http$Http$expectString(query.hu),
			g2: A3(
				$elm$url$Url$Builder$crossOrigin,
				query.bv,
				_List_fromArray(
					['api', 'series', query.hk]),
				fullquery)
		});
};
var $author$project$Tsinfo$getplot = function (model) {
	var idate = A2($elm$core$Array$get, model.ki, model.kN);
	var _v0 = $author$project$Horizon$getFetchBounds(model.A);
	var start = _v0.a;
	var end = _v0.b;
	return $author$project$Plotter$getdata(
		{
			hk: 'state',
			bv: model.bv,
			hu: $author$project$Tsinfo$GotPlotData,
			hU: start,
			A: $elm$core$Maybe$Nothing,
			h0: idate,
			Y: model.A.Y,
			id: false,
			ao: model.ao,
			iC: $author$project$Util$bool2int(model.A.d1),
			jw: end,
			jC: model.A.ab
		});
};
var $author$project$Tsinfo$HistoryIdates = function (a) {
	return {$: 44, a: a};
};
var $author$project$Tsinfo$getsomeidates = function (model) {
	var bounds = $author$project$Horizon$getFromToDates(model.A);
	var boundQuery = function () {
		if (bounds.$ === 1) {
			return _List_Nil;
		} else {
			var _v1 = bounds.a;
			var min = _v1.a;
			var max = _v1.b;
			return _List_fromArray(
				[
					A2($elm$url$Url$Builder$string, 'from_value_date', min),
					A2($elm$url$Url$Builder$string, 'to_value_date', max)
				]);
		}
	}();
	var baseQuery = _List_fromArray(
		[
			A2($elm$url$Url$Builder$string, 'name', model.ao),
			A2(
			$elm$url$Url$Builder$int,
			'nocache',
			$author$project$Util$bool2int(model.A.d1))
		]);
	return $elm$http$Http$get(
		{
			fp: $elm$http$Http$expectString($author$project$Tsinfo$HistoryIdates),
			g2: A3(
				$elm$url$Url$Builder$crossOrigin,
				model.bv,
				_List_fromArray(
					['api', 'series', 'insertion_dates']),
				_Utils_ap(baseQuery, boundQuery))
		});
};
var $author$project$Info$idatesdecoder = A2(
	$elm$json$Json$Decode$field,
	'insertion_dates',
	$elm$json$Json$Decode$list($elm$json$Json$Decode$string));
var $elm$core$List$takeReverse = F3(
	function (n, list, kept) {
		takeReverse:
		while (true) {
			if (n <= 0) {
				return kept;
			} else {
				if (!list.b) {
					return kept;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs,
						$temp$kept = A2($elm$core$List$cons, x, kept);
					n = $temp$n;
					list = $temp$list;
					kept = $temp$kept;
					continue takeReverse;
				}
			}
		}
	});
var $elm$core$List$takeTailRec = F2(
	function (n, list) {
		return $elm$core$List$reverse(
			A3($elm$core$List$takeReverse, n, list, _List_Nil));
	});
var $elm$core$List$takeFast = F3(
	function (ctr, n, list) {
		if (n <= 0) {
			return _List_Nil;
		} else {
			var _v0 = _Utils_Tuple2(n, list);
			_v0$1:
			while (true) {
				_v0$5:
				while (true) {
					if (!_v0.b.b) {
						return list;
					} else {
						if (_v0.b.b.b) {
							switch (_v0.a) {
								case 1:
									break _v0$1;
								case 2:
									var _v2 = _v0.b;
									var x = _v2.a;
									var _v3 = _v2.b;
									var y = _v3.a;
									return _List_fromArray(
										[x, y]);
								case 3:
									if (_v0.b.b.b.b) {
										var _v4 = _v0.b;
										var x = _v4.a;
										var _v5 = _v4.b;
										var y = _v5.a;
										var _v6 = _v5.b;
										var z = _v6.a;
										return _List_fromArray(
											[x, y, z]);
									} else {
										break _v0$5;
									}
								default:
									if (_v0.b.b.b.b && _v0.b.b.b.b.b) {
										var _v7 = _v0.b;
										var x = _v7.a;
										var _v8 = _v7.b;
										var y = _v8.a;
										var _v9 = _v8.b;
										var z = _v9.a;
										var _v10 = _v9.b;
										var w = _v10.a;
										var tl = _v10.b;
										return (ctr > 1000) ? A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A2($elm$core$List$takeTailRec, n - 4, tl))))) : A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A3($elm$core$List$takeFast, ctr + 1, n - 4, tl)))));
									} else {
										break _v0$5;
									}
							}
						} else {
							if (_v0.a === 1) {
								break _v0$1;
							} else {
								break _v0$5;
							}
						}
					}
				}
				return list;
			}
			var _v1 = _v0.b;
			var x = _v1.a;
			return _List_fromArray(
				[x]);
		}
	});
var $elm$core$List$take = F2(
	function (n, list) {
		return A3($elm$core$List$takeFast, 0, n, list);
	});
var $author$project$Tsinfo$lastDates = F2(
	function (dates, max) {
		return (_Utils_cmp(
			$elm$core$List$length(dates),
			max) > 0) ? $elm$core$List$reverse(
			A2(
				$elm$core$List$take,
				max,
				$elm$core$List$reverse(dates))) : dates;
	});
var $elm$core$Array$length = function (_v0) {
	var len = _v0.a;
	return len;
};
var $elm$browser$Browser$Navigation$load = _Browser_load;
var $author$project$Info$Logentry = F4(
	function (rev, author, date, meta) {
		return {hm: author, ea: date, cN: meta, i5: rev};
	});
var $elm$json$Json$Decode$map4 = _Json_map4;
var $author$project$Info$logentrydecoder = A5(
	$elm$json$Json$Decode$map4,
	$author$project$Info$Logentry,
	A2($elm$json$Json$Decode$field, 'rev', $elm$json$Json$Decode$int),
	A2($elm$json$Json$Decode$field, 'author', $elm$json$Json$Decode$string),
	A2($elm$json$Json$Decode$field, 'date', $elm$json$Json$Decode$string),
	A2(
		$elm$json$Json$Decode$field,
		'meta',
		$elm$json$Json$Decode$dict($author$project$Metadata$decodemetaval)));
var $author$project$Info$logdecoder = $elm$json$Json$Decode$list($author$project$Info$logentrydecoder);
var $elm$core$Elm$JsArray$map = _JsArray_map;
var $elm$core$Array$map = F2(
	function (func, _v0) {
		var len = _v0.a;
		var startShift = _v0.b;
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = function (node) {
			if (!node.$) {
				var subTree = node.a;
				return $elm$core$Array$SubTree(
					A2($elm$core$Elm$JsArray$map, helper, subTree));
			} else {
				var values = node.a;
				return $elm$core$Array$Leaf(
					A2($elm$core$Elm$JsArray$map, func, values));
			}
		};
		return A4(
			$elm$core$Array$Array_elm_builtin,
			len,
			startShift,
			A2($elm$core$Elm$JsArray$map, helper, tree),
			A2($elm$core$Elm$JsArray$map, func, tail));
	});
var $elm$core$Dict$map = F2(
	function (func, dict) {
		if (dict.$ === -2) {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		} else {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				key,
				A2(func, key, value),
				A2($elm$core$Dict$map, func, left),
				A2($elm$core$Dict$map, func, right));
		}
	});
var $elm$core$Dict$member = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$get, key, dict);
		if (!_v0.$) {
			return true;
		} else {
			return false;
		}
	});
var $elm$core$String$fromFloat = _String_fromNumber;
var $author$project$Metadata$showbool = function (b) {
	return b ? 'true' : 'false';
};
var $author$project$Metadata$metavaltostring = function (mv) {
	switch (mv.$) {
		case 0:
			var s = mv.a;
			return s;
		case 1:
			var i = mv.a;
			return $elm$core$String$fromInt(i);
		case 2:
			var f = mv.a;
			return $elm$core$String$fromFloat(f);
		case 3:
			var b = mv.a;
			return $author$project$Metadata$showbool(b);
		case 4:
			var l = mv.a;
			return A2(
				$elm$core$String$join,
				', ',
				A2($elm$core$List$map, $author$project$Metadata$metavaltostring, l));
		default:
			var s = mv.a;
			return '';
	}
};
var $elm$core$Basics$min = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) < 0) ? x : y;
	});
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $author$project$Util$nocmd = function (model) {
	return _Utils_Tuple2(model, $elm$core$Platform$Cmd$none);
};
var $elm$core$Basics$neq = _Utils_notEqual;
var $author$project$Tsinfo$removerepeated = F2(
	function (data, previous) {
		if (!data.b) {
			return _List_Nil;
		} else {
			var x = data.a;
			var xs = data.b;
			if (previous.$ === 1) {
				return _Utils_ap(
					_List_fromArray(
						[x]),
					A2(
						$author$project$Tsinfo$removerepeated,
						xs,
						$elm$core$Maybe$Just(x.me)));
			} else {
				var prev = previous.a;
				return (!_Utils_eq(prev, x.me)) ? _Utils_ap(
					_List_fromArray(
						[x]),
					A2(
						$author$project$Tsinfo$removerepeated,
						xs,
						$elm$core$Maybe$Just(x.me))) : A2(
					$author$project$Tsinfo$removerepeated,
					xs,
					$elm$core$Maybe$Just(x.me));
			}
		}
	});
var $author$project$Tsinfo$removeRedondants = function (dataHover) {
	return {
		kh: A2($author$project$Tsinfo$removerepeated, dataHover.kh, $elm$core$Maybe$Nothing),
		ao: dataHover.ao
	};
};
var $author$project$Info$rename = F4(
	function (model, newname, dtype, event) {
		return $elm$http$Http$request(
			{
				e6: $elm$http$Http$jsonBody(
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'name',
								$elm$json$Json$Encode$string(model.ao)),
								_Utils_Tuple2(
								'newname',
								$elm$json$Json$Encode$string(newname))
							]))),
				fp: $elm$http$Http$expectString(event),
				fA: _List_Nil,
				f_: 'put',
				gV: $elm$core$Maybe$Nothing,
				g_: $elm$core$Maybe$Nothing,
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.bv,
					_List_fromArray(
						['api', dtype, 'state']),
					_List_Nil)
			});
	});
var $elm$core$Dict$foldl = F3(
	function (func, acc, dict) {
		foldl:
		while (true) {
			if (dict.$ === -2) {
				return acc;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldl, func, acc, left)),
					$temp$dict = right;
				func = $temp$func;
				acc = $temp$acc;
				dict = $temp$dict;
				continue foldl;
			}
		}
	});
var $elm$json$Json$Encode$dict = F3(
	function (toKey, toValue, dictionary) {
		return _Json_wrap(
			A3(
				$elm$core$Dict$foldl,
				F3(
					function (key, value, obj) {
						return A3(
							_Json_addField,
							toKey(key),
							toValue(value),
							obj);
					}),
				_Json_emptyObject(0),
				dictionary));
	});
var $elm$json$Json$Encode$bool = _Json_wrap;
var $elm$json$Json$Encode$float = _Json_wrap;
var $elm$json$Json$Encode$int = _Json_wrap;
var $elm$json$Json$Encode$null = _Json_encodeNull;
var $author$project$Metadata$metavalencoder = function (val) {
	switch (val.$) {
		case 0:
			var s = val.a;
			return $elm$json$Json$Encode$string(s);
		case 1:
			var i = val.a;
			return $elm$json$Json$Encode$int(i);
		case 2:
			var f = val.a;
			return $elm$json$Json$Encode$float(f);
		case 3:
			var b = val.a;
			return $elm$json$Json$Encode$bool(b);
		default:
			return $elm$json$Json$Encode$null;
	}
};
var $author$project$Metadata$metaencoder = A2($elm$json$Json$Encode$dict, $elm$core$Basics$identity, $author$project$Metadata$metavalencoder);
var $author$project$Metadata$encodemeta = function (meta) {
	return A2(
		$elm$json$Json$Encode$encode,
		0,
		$author$project$Metadata$metaencoder(meta));
};
var $author$project$Info$savemeta = F3(
	function (model, dtype, callback) {
		return $elm$http$Http$request(
			{
				e6: $elm$http$Http$jsonBody(
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'name',
								$elm$json$Json$Encode$string(model.ao)),
								_Utils_Tuple2(
								'metadata',
								$elm$json$Json$Encode$string(
									$author$project$Metadata$encodemeta(model.g3)))
							]))),
				fp: $elm$http$Http$expectString(callback),
				fA: _List_Nil,
				f_: 'PUT',
				gV: $elm$core$Maybe$Nothing,
				g_: $elm$core$Maybe$Nothing,
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.bv,
					_List_fromArray(
						['api', dtype, 'metadata']),
					_List_Nil)
			});
	});
var $elm$json$Json$Decode$maybe = function (decoder) {
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, decoder),
				$elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing)
			]));
};
var $author$project$Plotter$seriesdecoder = $elm$json$Json$Decode$dict(
	$elm$json$Json$Decode$maybe($elm$json$Json$Decode$float));
var $author$project$Horizon$setStatusPlot = F2(
	function (model, status) {
		return _Utils_update(
			model,
			{T: status});
	});
var $elm$core$Process$sleep = _Process_sleep;
var $author$project$Util$snd = $elm$core$Tuple$second;
var $author$project$Metadata$dget = F2(
	function (name, metadict) {
		var _v0 = A2($elm$core$Dict$get, name, metadict);
		if (_v0.$ === 1) {
			return '';
		} else {
			var something = _v0.a;
			return $author$project$Metadata$metavaltostring(something);
		}
	});
var $author$project$NavTabs$strseries = function (meta) {
	var _v0 = A2($author$project$Metadata$dget, 'value_type', meta);
	if (_v0 === 'object') {
		return true;
	} else {
		return false;
	}
};
var $author$project$Util$unwraperror = function (resp) {
	switch (resp.$) {
		case 0:
			var x = resp.a;
			return 'bad url: ' + x;
		case 1:
			return 'the query timed out';
		case 2:
			return 'there was a network error';
		case 3:
			var val = resp.a;
			return 'we got a bad status answer: ' + $elm$core$String$fromInt(val);
		default:
			var body = resp.a;
			return 'we got a bad body: ' + body;
	}
};
var $elm$core$Maybe$map = F2(
	function (f, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return $elm$core$Maybe$Just(
				f(value));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$core$Platform$Cmd$map = _Platform_map;
var $elm$core$Tuple$mapSecond = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			x,
			func(y));
	});
var $Gizra$elm_debouncer$Debouncer$Internal$Check = function (a) {
	return {$: 4, a: a};
};
var $Gizra$elm_debouncer$Debouncer$Internal$InputProvidedAt = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $Gizra$elm_debouncer$Debouncer$Internal$ManualEmitAt = function (a) {
	return {$: 3, a: a};
};
var $Gizra$elm_debouncer$Debouncer$Basic$MsgInternal = function (a) {
	return {$: 2, a: a};
};
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm$time$Time$Name = function (a) {
	return {$: 0, a: a};
};
var $elm$time$Time$Offset = function (a) {
	return {$: 1, a: a};
};
var $elm$time$Time$Zone = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$time$Time$customZone = $elm$time$Time$Zone;
var $elm$time$Time$Posix = $elm$core$Basics$identity;
var $elm$time$Time$millisToPosix = $elm$core$Basics$identity;
var $elm$time$Time$now = _Time_now($elm$time$Time$millisToPosix);
var $elm$time$Time$posixToMillis = function (_v0) {
	var millis = _v0;
	return millis;
};
var $Gizra$elm_debouncer$Debouncer$Internal$Unsettled = function (a) {
	return {$: 1, a: a};
};
var $Gizra$elm_debouncer$Debouncer$Internal$cancel = function (_v0) {
	var config = _v0.a;
	var state = _v0.b;
	return A2($Gizra$elm_debouncer$Debouncer$Internal$Debouncer, config, $Gizra$elm_debouncer$Debouncer$Internal$Settled);
};
var $elm$core$List$isEmpty = function (xs) {
	if (!xs.b) {
		return true;
	} else {
		return false;
	}
};
var $elm$core$Tuple$mapFirst = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			func(x),
			y);
	});
var $elm$core$Basics$not = _Basics_not;
var $elm$core$List$partition = F2(
	function (pred, list) {
		var step = F2(
			function (x, _v0) {
				var trues = _v0.a;
				var falses = _v0.b;
				return pred(x) ? _Utils_Tuple2(
					A2($elm$core$List$cons, x, trues),
					falses) : _Utils_Tuple2(
					trues,
					A2($elm$core$List$cons, x, falses));
			});
		return A3(
			$elm$core$List$foldr,
			step,
			_Utils_Tuple2(_List_Nil, _List_Nil),
			list);
	});
var $elm$core$List$any = F2(
	function (isOkay, list) {
		any:
		while (true) {
			if (!list.b) {
				return false;
			} else {
				var x = list.a;
				var xs = list.b;
				if (isOkay(x)) {
					return true;
				} else {
					var $temp$isOkay = isOkay,
						$temp$list = xs;
					isOkay = $temp$isOkay;
					list = $temp$list;
					continue any;
				}
			}
		}
	});
var $elm$core$List$member = F2(
	function (x, xs) {
		return A2(
			$elm$core$List$any,
			function (a) {
				return _Utils_eq(a, x);
			},
			xs);
	});
var $elm_community$list_extra$List$Extra$uniqueHelp = F4(
	function (f, existing, remaining, accumulator) {
		uniqueHelp:
		while (true) {
			if (!remaining.b) {
				return $elm$core$List$reverse(accumulator);
			} else {
				var first = remaining.a;
				var rest = remaining.b;
				var computedFirst = f(first);
				if (A2($elm$core$List$member, computedFirst, existing)) {
					var $temp$f = f,
						$temp$existing = existing,
						$temp$remaining = rest,
						$temp$accumulator = accumulator;
					f = $temp$f;
					existing = $temp$existing;
					remaining = $temp$remaining;
					accumulator = $temp$accumulator;
					continue uniqueHelp;
				} else {
					var $temp$f = f,
						$temp$existing = A2($elm$core$List$cons, computedFirst, existing),
						$temp$remaining = rest,
						$temp$accumulator = A2($elm$core$List$cons, first, accumulator);
					f = $temp$f;
					existing = $temp$existing;
					remaining = $temp$remaining;
					accumulator = $temp$accumulator;
					continue uniqueHelp;
				}
			}
		}
	});
var $elm_community$list_extra$List$Extra$unique = function (list) {
	return A4($elm_community$list_extra$List$Extra$uniqueHelp, $elm$core$Basics$identity, _List_Nil, list, _List_Nil);
};
var $Gizra$elm_debouncer$Debouncer$Internal$update = F2(
	function (msg, debouncer) {
		var wrappedConfig = debouncer.a;
		var config = wrappedConfig;
		var state = debouncer.b;
		switch (msg.$) {
			case 0:
				var input = msg.a;
				var time = msg.b;
				var newState = function () {
					if (!state.$) {
						return $Gizra$elm_debouncer$Debouncer$Internal$Unsettled(
							{
								cI: $elm$core$Maybe$Nothing,
								en: time,
								aO: A2(config.bY, input, $elm$core$Maybe$Nothing),
								eX: time
							});
					} else {
						var unsettled = state.a;
						return $Gizra$elm_debouncer$Debouncer$Internal$Unsettled(
							_Utils_update(
								unsettled,
								{
									en: time,
									aO: A2(config.bY, input, unsettled.aO)
								}));
					}
				}();
				var newDebouncer = A2($Gizra$elm_debouncer$Debouncer$Internal$Debouncer, wrappedConfig, newState);
				var checks = function () {
					if (!state.$) {
						return $elm_community$list_extra$List$Extra$unique(
							A2(
								$elm$core$List$filterMap,
								$elm$core$Basics$identity,
								_List_fromArray(
									[config.aU, config.aV, config.a1])));
					} else {
						return A2(
							$elm$core$List$filterMap,
							$elm$core$Basics$identity,
							_List_fromArray(
								[config.a1]));
					}
				}();
				var _v1 = A2(
					$elm$core$Tuple$mapFirst,
					A2($elm$core$Basics$composeL, $elm$core$Basics$not, $elm$core$List$isEmpty),
					A2(
						$elm$core$List$partition,
						function (interval) {
							return interval <= 0;
						},
						checks));
				var checkNow = _v1.a;
				var checkLater = _v1.b;
				var _v2 = checkNow ? A2(
					$Gizra$elm_debouncer$Debouncer$Internal$update,
					$Gizra$elm_debouncer$Debouncer$Internal$Check(time),
					newDebouncer) : _Utils_Tuple3(newDebouncer, _List_Nil, $elm$core$Maybe$Nothing);
				var checkedDebouncer = _v2.a;
				var checkedIntervals = _v2.b;
				var emit = _v2.c;
				return _Utils_Tuple3(
					checkedDebouncer,
					_Utils_ap(checkedIntervals, checkLater),
					emit);
			case 1:
				return _Utils_Tuple3(
					$Gizra$elm_debouncer$Debouncer$Internal$cancel(debouncer),
					_List_Nil,
					$elm$core$Maybe$Nothing);
			case 2:
				var emit = function () {
					if (!state.$) {
						return $elm$core$Maybe$Nothing;
					} else {
						var unsettled = state.a;
						return unsettled.aO;
					}
				}();
				return _Utils_Tuple3(
					$Gizra$elm_debouncer$Debouncer$Internal$cancel(debouncer),
					_List_Nil,
					emit);
			case 3:
				var time = msg.a;
				if (!state.$) {
					return _Utils_Tuple3(debouncer, _List_Nil, $elm$core$Maybe$Nothing);
				} else {
					var unsettled = state.a;
					var _v7 = unsettled.aO;
					if (!_v7.$) {
						var newState = $Gizra$elm_debouncer$Debouncer$Internal$Unsettled(
							_Utils_update(
								unsettled,
								{
									cI: $elm$core$Maybe$Just(time),
									aO: $elm$core$Maybe$Nothing
								}));
						var intervals = function () {
							var _v8 = config.aU;
							if (!_v8.$) {
								var emit = _v8.a;
								return _List_fromArray(
									[emit]);
							} else {
								return _List_Nil;
							}
						}();
						return _Utils_Tuple3(
							A2($Gizra$elm_debouncer$Debouncer$Internal$Debouncer, wrappedConfig, newState),
							intervals,
							unsettled.aO);
					} else {
						return _Utils_Tuple3(debouncer, _List_Nil, $elm$core$Maybe$Nothing);
					}
				}
			default:
				var time = msg.a;
				if (!state.$) {
					return _Utils_Tuple3(debouncer, _List_Nil, $elm$core$Maybe$Nothing);
				} else {
					var unsettled = state.a;
					var shouldSettle = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (interval) {
								return _Utils_cmp(unsettled.en + interval, time) < 1;
							},
							config.a1));
					var becauseEmitWhileUnsettled = function () {
						var _v13 = config.aV;
						if (!_v13.$) {
							var interval = _v13.a;
							var _v14 = unsettled.cI;
							if (!_v14.$) {
								var lastEmittedAt = _v14.a;
								return _Utils_cmp(lastEmittedAt + interval, time) < 1;
							} else {
								return _Utils_cmp(unsettled.eX + interval, time) < 1;
							}
						} else {
							return false;
						}
					}();
					var becauseEmitWhenUnsettled = function () {
						var _v11 = config.aU;
						if (!_v11.$) {
							var interval = _v11.a;
							var _v12 = unsettled.cI;
							if (!_v12.$) {
								return false;
							} else {
								return _Utils_cmp(unsettled.eX + interval, time) < 1;
							}
						} else {
							return false;
						}
					}();
					var shouldEmit = (!_Utils_eq(unsettled.aO, $elm$core$Maybe$Nothing)) && (shouldSettle || (becauseEmitWhenUnsettled || becauseEmitWhileUnsettled));
					var emit = shouldEmit ? unsettled.aO : $elm$core$Maybe$Nothing;
					var intervals = function () {
						if (shouldEmit && (!shouldSettle)) {
							var _v10 = config.aV;
							if (!_v10.$) {
								var interval = _v10.a;
								return _List_fromArray(
									[interval]);
							} else {
								return _List_Nil;
							}
						} else {
							return _List_Nil;
						}
					}();
					var newState = shouldSettle ? $Gizra$elm_debouncer$Debouncer$Internal$Settled : (shouldEmit ? $Gizra$elm_debouncer$Debouncer$Internal$Unsettled(
						_Utils_update(
							unsettled,
							{
								cI: $elm$core$Maybe$Just(time),
								aO: $elm$core$Maybe$Nothing
							})) : state);
					return _Utils_Tuple3(
						A2($Gizra$elm_debouncer$Debouncer$Internal$Debouncer, wrappedConfig, newState),
						intervals,
						emit);
				}
		}
	});
var $Gizra$elm_debouncer$Debouncer$Basic$update = F2(
	function (msg, debouncer) {
		switch (msg.$) {
			case 0:
				var input = msg.a;
				return _Utils_Tuple3(
					debouncer,
					A2(
						$elm$core$Task$perform,
						A2(
							$elm$core$Basics$composeL,
							A2(
								$elm$core$Basics$composeL,
								$Gizra$elm_debouncer$Debouncer$Basic$MsgInternal,
								$Gizra$elm_debouncer$Debouncer$Internal$InputProvidedAt(input)),
							$elm$time$Time$posixToMillis),
						$elm$time$Time$now),
					$elm$core$Maybe$Nothing);
			case 1:
				return _Utils_Tuple3(
					debouncer,
					A2(
						$elm$core$Task$perform,
						A2(
							$elm$core$Basics$composeL,
							A2($elm$core$Basics$composeL, $Gizra$elm_debouncer$Debouncer$Basic$MsgInternal, $Gizra$elm_debouncer$Debouncer$Internal$ManualEmitAt),
							$elm$time$Time$posixToMillis),
						$elm$time$Time$now),
					$elm$core$Maybe$Nothing);
			default:
				var subMsg = msg.a;
				var _v1 = A2($Gizra$elm_debouncer$Debouncer$Internal$update, subMsg, debouncer);
				var updatedDebouncer = _v1.a;
				var intervals = _v1.b;
				var output = _v1.c;
				var cmds = $elm$core$Platform$Cmd$batch(
					A2(
						$elm$core$List$map,
						function (interval) {
							return A2(
								$elm$core$Task$perform,
								A2(
									$elm$core$Basics$composeL,
									A2($elm$core$Basics$composeL, $Gizra$elm_debouncer$Debouncer$Basic$MsgInternal, $Gizra$elm_debouncer$Debouncer$Internal$Check),
									$elm$time$Time$posixToMillis),
								A2(
									$elm$core$Task$andThen,
									$elm$core$Basics$always($elm$time$Time$now),
									$elm$core$Process$sleep(interval)));
						},
						intervals));
				return _Utils_Tuple3(updatedDebouncer, cmds, output);
		}
	});
var $Gizra$elm_debouncer$Debouncer$Messages$update = F4(
	function (parentUpdate, config, msg, model) {
		var _v0 = A2(
			$Gizra$elm_debouncer$Debouncer$Basic$update,
			msg,
			config.hV(model));
		var updatedDebouncer = _v0.a;
		var cmd = _v0.b;
		var output = _v0.c;
		var mappedCmd = A2($elm$core$Platform$Cmd$map, config.$9, cmd);
		var newModel = A2(config.je, updatedDebouncer, model);
		return A2(
			$elm$core$Maybe$withDefault,
			_Utils_Tuple2(newModel, mappedCmd),
			A2(
				$elm$core$Maybe$map,
				function (emittedMsg) {
					return A2(
						$elm$core$Tuple$mapSecond,
						function (recursiveCmd) {
							return $elm$core$Platform$Cmd$batch(
								_List_fromArray(
									[mappedCmd, recursiveCmd]));
						},
						A2(parentUpdate, emittedMsg, newModel));
				},
				output));
	});
var $author$project$Horizon$DateNow = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Horizon$Disabled = {$: 1};
var $author$project$Horizon$EnrichFromStorage = F3(
	function (horizon, timeZone, inferredFreq) {
		return {A: horizon, Y: inferredFreq, ab: timeZone};
	});
var $author$project$Horizon$Fetch = function (a) {
	return {$: 2, a: a};
};
var $author$project$Horizon$GetDirectData = function (a) {
	return {$: 1, a: a};
};
var $author$project$Horizon$Internal = function (a) {
	return {$: 3, a: a};
};
var $author$project$Horizon$LocalStorageData = F3(
	function (horizon, timeZone, inferredFreq) {
		return {A: horizon, Y: inferredFreq, ab: timeZone};
	});
var $author$project$Horizon$Reset = 1;
var $author$project$Horizon$Start = 0;
var $author$project$Horizon$Bounds = F3(
	function (from, to, dateRef) {
		return {bc: dateRef, aA: from, aF: to};
	});
var $elm$json$Json$Decode$map3 = _Json_map3;
var $author$project$Horizon$decodeBounds = A4(
	$elm$json$Json$Decode$map3,
	$author$project$Horizon$Bounds,
	A2($elm$json$Json$Decode$field, 'fromdate', $elm$json$Json$Decode$string),
	A2($elm$json$Json$Decode$field, 'todate', $elm$json$Json$Decode$string),
	A2($elm$json$Json$Decode$field, 'ref-date', $elm$json$Json$Decode$string));
var $author$project$Horizon$decodeChoices = $elm$json$Json$Decode$list($elm$json$Json$Decode$string);
var $author$project$Horizon$GotBounds = function (a) {
	return {$: 0, a: a};
};
var $author$project$Horizon$getBounds = F3(
	function (model, convertMsg, step) {
		var _v0 = model.A;
		switch (_v0.$) {
			case 1:
				return $elm$core$Platform$Cmd$none;
			case 0:
				return A2(
					$elm$core$Task$perform,
					$elm$core$Basics$identity,
					$elm$core$Task$succeed(
						convertMsg(
							$author$project$Horizon$Fetch(
								$author$project$Horizon$GetDirectData($elm$core$Maybe$Nothing)))));
			default:
				var horizon = _v0.a;
				return $elm$http$Http$get(
					{
						fp: $elm$http$Http$expectString(
							function (s) {
								return convertMsg(
									$author$project$Horizon$Fetch(
										$author$project$Horizon$GotBounds(s)));
							}),
						g2: A3(
							$elm$url$Url$Builder$crossOrigin,
							model.dl,
							_List_fromArray(
								[
									'new-dates',
									horizon,
									model.bc,
									$elm$core$String$fromInt(step)
								]),
							_List_Nil)
					});
		}
	});
var $author$project$Horizon$GotChoices = function (a) {
	return {$: 3, a: a};
};
var $author$project$Horizon$getChoices = F2(
	function (model, convertMsg) {
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(
					function (s) {
						return convertMsg(
							$author$project$Horizon$Internal(
								$author$project$Horizon$GotChoices(s)));
					}),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.dl,
					_List_fromArray(
						['horizon-choices']),
					_List_Nil)
			});
	});
var $elm$json$Json$Decode$nullable = function (decoder) {
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				$elm$json$Json$Decode$null($elm$core$Maybe$Nothing),
				A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, decoder)
			]));
};
var $author$project$Horizon$localstoragedecoder = A4(
	$elm$json$Json$Decode$map3,
	$author$project$Horizon$LocalStorageData,
	A2(
		$elm$json$Json$Decode$field,
		'horizon',
		$elm$json$Json$Decode$nullable($elm$json$Json$Decode$string)),
	A2($elm$json$Json$Decode$field, 'timeZone', $elm$json$Json$Decode$string),
	A2($elm$json$Json$Decode$field, 'inferredFreq', $elm$json$Json$Decode$bool));
var $elm$core$Maybe$destruct = F3(
	function (_default, func, maybe) {
		if (!maybe.$) {
			var a = maybe.a;
			return func(a);
		} else {
			return _default;
		}
	});
var $author$project$Horizon$saveToLocalStorage = _Platform_outgoingPort(
	'saveToLocalStorage',
	function ($) {
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'horizon',
					function ($) {
						return A3($elm$core$Maybe$destruct, $elm$json$Json$Encode$null, $elm$json$Json$Encode$string, $);
					}($.A)),
					_Utils_Tuple2(
					'inferredFreq',
					$elm$json$Json$Encode$bool($.Y)),
					_Utils_Tuple2(
					'timeZone',
					$elm$json$Json$Encode$string($.ab))
				]));
	});
var $author$project$Horizon$slideBounds = F3(
	function (model, convertMsg, step) {
		var _v0 = $author$project$Horizon$getFetchBounds(model);
		var from = _v0.a;
		var to = _v0.b;
		return $elm$http$Http$get(
			{
				fp: $elm$http$Http$expectString(
					function (s) {
						return convertMsg(
							$author$project$Horizon$Fetch(
								$author$project$Horizon$GotBounds(s)));
					}),
				g2: A3(
					$elm$url$Url$Builder$crossOrigin,
					model.dl,
					_List_fromArray(
						[
							'translate-dates',
							from,
							to,
							model.bc,
							$elm$core$String$fromInt(step)
						]),
					_List_Nil)
			});
	});
var $author$project$Horizon$Label = function (a) {
	return {$: 2, a: a};
};
var $author$project$Horizon$toHorizonType = function (fromStorage) {
	return {
		A: function () {
			var _v0 = fromStorage.A;
			if (_v0.$ === 1) {
				return $author$project$Horizon$All;
			} else {
				var horizon = _v0.a;
				return $author$project$Horizon$Label(horizon);
			}
		}(),
		Y: fromStorage.Y,
		ab: fromStorage.ab
	};
};
var $elm$time$Time$Jan = 0;
var $justinmimbs$date$Date$RD = $elm$core$Basics$identity;
var $elm$core$Basics$modBy = _Basics_modBy;
var $justinmimbs$date$Date$isLeapYear = function (y) {
	return ((!A2($elm$core$Basics$modBy, 4, y)) && (!(!A2($elm$core$Basics$modBy, 100, y)))) || (!A2($elm$core$Basics$modBy, 400, y));
};
var $justinmimbs$date$Date$daysInMonth = F2(
	function (y, m) {
		switch (m) {
			case 0:
				return 31;
			case 1:
				return $justinmimbs$date$Date$isLeapYear(y) ? 29 : 28;
			case 2:
				return 31;
			case 3:
				return 30;
			case 4:
				return 31;
			case 5:
				return 30;
			case 6:
				return 31;
			case 7:
				return 31;
			case 8:
				return 30;
			case 9:
				return 31;
			case 10:
				return 30;
			default:
				return 31;
		}
	});
var $justinmimbs$date$Date$monthToNumber = function (m) {
	switch (m) {
		case 0:
			return 1;
		case 1:
			return 2;
		case 2:
			return 3;
		case 3:
			return 4;
		case 4:
			return 5;
		case 5:
			return 6;
		case 6:
			return 7;
		case 7:
			return 8;
		case 8:
			return 9;
		case 9:
			return 10;
		case 10:
			return 11;
		default:
			return 12;
	}
};
var $elm$time$Time$Apr = 3;
var $elm$time$Time$Aug = 7;
var $elm$time$Time$Dec = 11;
var $elm$time$Time$Feb = 1;
var $elm$time$Time$Jul = 6;
var $elm$time$Time$Jun = 5;
var $elm$time$Time$Mar = 2;
var $elm$time$Time$May = 4;
var $elm$time$Time$Nov = 10;
var $elm$time$Time$Oct = 9;
var $elm$time$Time$Sep = 8;
var $justinmimbs$date$Date$numberToMonth = function (mn) {
	var _v0 = A2($elm$core$Basics$max, 1, mn);
	switch (_v0) {
		case 1:
			return 0;
		case 2:
			return 1;
		case 3:
			return 2;
		case 4:
			return 3;
		case 5:
			return 4;
		case 6:
			return 5;
		case 7:
			return 6;
		case 8:
			return 7;
		case 9:
			return 8;
		case 10:
			return 9;
		case 11:
			return 10;
		default:
			return 11;
	}
};
var $justinmimbs$date$Date$toCalendarDateHelp = F3(
	function (y, m, d) {
		toCalendarDateHelp:
		while (true) {
			var monthDays = A2($justinmimbs$date$Date$daysInMonth, y, m);
			var mn = $justinmimbs$date$Date$monthToNumber(m);
			if ((mn < 12) && (_Utils_cmp(d, monthDays) > 0)) {
				var $temp$y = y,
					$temp$m = $justinmimbs$date$Date$numberToMonth(mn + 1),
					$temp$d = d - monthDays;
				y = $temp$y;
				m = $temp$m;
				d = $temp$d;
				continue toCalendarDateHelp;
			} else {
				return {hA: d, it: m, jK: y};
			}
		}
	});
var $justinmimbs$date$Date$floorDiv = F2(
	function (a, b) {
		return $elm$core$Basics$floor(a / b);
	});
var $justinmimbs$date$Date$daysBeforeYear = function (y1) {
	var y = y1 - 1;
	var leapYears = (A2($justinmimbs$date$Date$floorDiv, y, 4) - A2($justinmimbs$date$Date$floorDiv, y, 100)) + A2($justinmimbs$date$Date$floorDiv, y, 400);
	return (365 * y) + leapYears;
};
var $justinmimbs$date$Date$divWithRemainder = F2(
	function (a, b) {
		return _Utils_Tuple2(
			A2($justinmimbs$date$Date$floorDiv, a, b),
			A2($elm$core$Basics$modBy, b, a));
	});
var $justinmimbs$date$Date$year = function (_v0) {
	var rd = _v0;
	var _v1 = A2($justinmimbs$date$Date$divWithRemainder, rd, 146097);
	var n400 = _v1.a;
	var r400 = _v1.b;
	var _v2 = A2($justinmimbs$date$Date$divWithRemainder, r400, 36524);
	var n100 = _v2.a;
	var r100 = _v2.b;
	var _v3 = A2($justinmimbs$date$Date$divWithRemainder, r100, 1461);
	var n4 = _v3.a;
	var r4 = _v3.b;
	var _v4 = A2($justinmimbs$date$Date$divWithRemainder, r4, 365);
	var n1 = _v4.a;
	var r1 = _v4.b;
	var n = (!r1) ? 0 : 1;
	return ((((n400 * 400) + (n100 * 100)) + (n4 * 4)) + n1) + n;
};
var $justinmimbs$date$Date$toOrdinalDate = function (_v0) {
	var rd = _v0;
	var y = $justinmimbs$date$Date$year(rd);
	return {
		ga: rd - $justinmimbs$date$Date$daysBeforeYear(y),
		jK: y
	};
};
var $justinmimbs$date$Date$toCalendarDate = function (_v0) {
	var rd = _v0;
	var date = $justinmimbs$date$Date$toOrdinalDate(rd);
	return A3($justinmimbs$date$Date$toCalendarDateHelp, date.jK, 0, date.ga);
};
var $justinmimbs$date$Date$day = A2(
	$elm$core$Basics$composeR,
	$justinmimbs$date$Date$toCalendarDate,
	function ($) {
		return $.hA;
	});
var $justinmimbs$date$Date$month = A2(
	$elm$core$Basics$composeR,
	$justinmimbs$date$Date$toCalendarDate,
	function ($) {
		return $.it;
	});
var $justinmimbs$date$Date$monthNumber = A2($elm$core$Basics$composeR, $justinmimbs$date$Date$month, $justinmimbs$date$Date$monthToNumber);
var $justinmimbs$date$Date$ordinalDay = A2(
	$elm$core$Basics$composeR,
	$justinmimbs$date$Date$toOrdinalDate,
	function ($) {
		return $.ga;
	});
var $elm$core$String$cons = _String_cons;
var $elm$core$String$fromChar = function (_char) {
	return A2($elm$core$String$cons, _char, '');
};
var $elm$core$Bitwise$shiftRightBy = _Bitwise_shiftRightBy;
var $elm$core$String$repeatHelp = F3(
	function (n, chunk, result) {
		return (n <= 0) ? result : A3(
			$elm$core$String$repeatHelp,
			n >> 1,
			_Utils_ap(chunk, chunk),
			(!(n & 1)) ? result : _Utils_ap(result, chunk));
	});
var $elm$core$String$repeat = F2(
	function (n, chunk) {
		return A3($elm$core$String$repeatHelp, n, chunk, '');
	});
var $elm$core$String$padLeft = F3(
	function (n, _char, string) {
		return _Utils_ap(
			A2(
				$elm$core$String$repeat,
				n - $elm$core$String$length(string),
				$elm$core$String$fromChar(_char)),
			string);
	});
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $elm$core$Basics$abs = function (n) {
	return (n < 0) ? (-n) : n;
};
var $justinmimbs$date$Date$padSignedInt = F2(
	function (length, _int) {
		return _Utils_ap(
			(_int < 0) ? '-' : '',
			A3(
				$elm$core$String$padLeft,
				length,
				'0',
				$elm$core$String$fromInt(
					$elm$core$Basics$abs(_int))));
	});
var $justinmimbs$date$Date$monthToQuarter = function (m) {
	return (($justinmimbs$date$Date$monthToNumber(m) + 2) / 3) | 0;
};
var $justinmimbs$date$Date$quarter = A2($elm$core$Basics$composeR, $justinmimbs$date$Date$month, $justinmimbs$date$Date$monthToQuarter);
var $elm$core$String$right = F2(
	function (n, string) {
		return (n < 1) ? '' : A3(
			$elm$core$String$slice,
			-n,
			$elm$core$String$length(string),
			string);
	});
var $justinmimbs$date$Date$weekdayNumber = function (_v0) {
	var rd = _v0;
	var _v1 = A2($elm$core$Basics$modBy, 7, rd);
	if (!_v1) {
		return 7;
	} else {
		var n = _v1;
		return n;
	}
};
var $justinmimbs$date$Date$daysBeforeWeekYear = function (y) {
	var jan4 = $justinmimbs$date$Date$daysBeforeYear(y) + 4;
	return jan4 - $justinmimbs$date$Date$weekdayNumber(jan4);
};
var $elm$time$Time$Fri = 4;
var $elm$time$Time$Mon = 0;
var $elm$time$Time$Sat = 5;
var $elm$time$Time$Sun = 6;
var $elm$time$Time$Thu = 3;
var $elm$time$Time$Tue = 1;
var $elm$time$Time$Wed = 2;
var $justinmimbs$date$Date$numberToWeekday = function (wdn) {
	var _v0 = A2($elm$core$Basics$max, 1, wdn);
	switch (_v0) {
		case 1:
			return 0;
		case 2:
			return 1;
		case 3:
			return 2;
		case 4:
			return 3;
		case 5:
			return 4;
		case 6:
			return 5;
		default:
			return 6;
	}
};
var $justinmimbs$date$Date$toWeekDate = function (_v0) {
	var rd = _v0;
	var wdn = $justinmimbs$date$Date$weekdayNumber(rd);
	var wy = $justinmimbs$date$Date$year(rd + (4 - wdn));
	var week1Day1 = $justinmimbs$date$Date$daysBeforeWeekYear(wy) + 1;
	return {
		jF: 1 + (((rd - week1Day1) / 7) | 0),
		jG: wy,
		mh: $justinmimbs$date$Date$numberToWeekday(wdn)
	};
};
var $justinmimbs$date$Date$weekNumber = A2(
	$elm$core$Basics$composeR,
	$justinmimbs$date$Date$toWeekDate,
	function ($) {
		return $.jF;
	});
var $justinmimbs$date$Date$weekYear = A2(
	$elm$core$Basics$composeR,
	$justinmimbs$date$Date$toWeekDate,
	function ($) {
		return $.jG;
	});
var $justinmimbs$date$Date$weekday = A2($elm$core$Basics$composeR, $justinmimbs$date$Date$weekdayNumber, $justinmimbs$date$Date$numberToWeekday);
var $justinmimbs$date$Date$ordinalSuffix = function (n) {
	var nn = A2($elm$core$Basics$modBy, 100, n);
	var _v0 = A2(
		$elm$core$Basics$min,
		(nn < 20) ? nn : A2($elm$core$Basics$modBy, 10, nn),
		4);
	switch (_v0) {
		case 1:
			return 'st';
		case 2:
			return 'nd';
		case 3:
			return 'rd';
		default:
			return 'th';
	}
};
var $justinmimbs$date$Date$withOrdinalSuffix = function (n) {
	return _Utils_ap(
		$elm$core$String$fromInt(n),
		$justinmimbs$date$Date$ordinalSuffix(n));
};
var $justinmimbs$date$Date$formatField = F4(
	function (language, _char, length, date) {
		switch (_char) {
			case 'y':
				if (length === 2) {
					return A2(
						$elm$core$String$right,
						2,
						A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$year(date))));
				} else {
					return A2(
						$justinmimbs$date$Date$padSignedInt,
						length,
						$justinmimbs$date$Date$year(date));
				}
			case 'Y':
				if (length === 2) {
					return A2(
						$elm$core$String$right,
						2,
						A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$weekYear(date))));
				} else {
					return A2(
						$justinmimbs$date$Date$padSignedInt,
						length,
						$justinmimbs$date$Date$weekYear(date));
				}
			case 'Q':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$quarter(date));
					case 2:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$quarter(date));
					case 3:
						return 'Q' + $elm$core$String$fromInt(
							$justinmimbs$date$Date$quarter(date));
					case 4:
						return $justinmimbs$date$Date$withOrdinalSuffix(
							$justinmimbs$date$Date$quarter(date));
					case 5:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$quarter(date));
					default:
						return '';
				}
			case 'M':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$monthNumber(date));
					case 2:
						return A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$monthNumber(date)));
					case 3:
						return language.ey(
							$justinmimbs$date$Date$month(date));
					case 4:
						return language.f4(
							$justinmimbs$date$Date$month(date));
					case 5:
						return A2(
							$elm$core$String$left,
							1,
							language.ey(
								$justinmimbs$date$Date$month(date)));
					default:
						return '';
				}
			case 'w':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$weekNumber(date));
					case 2:
						return A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$weekNumber(date)));
					default:
						return '';
				}
			case 'd':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$day(date));
					case 2:
						return A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$day(date)));
					case 3:
						return language.fe(
							$justinmimbs$date$Date$day(date));
					default:
						return '';
				}
			case 'D':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$ordinalDay(date));
					case 2:
						return A3(
							$elm$core$String$padLeft,
							2,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$ordinalDay(date)));
					case 3:
						return A3(
							$elm$core$String$padLeft,
							3,
							'0',
							$elm$core$String$fromInt(
								$justinmimbs$date$Date$ordinalDay(date)));
					default:
						return '';
				}
			case 'E':
				switch (length) {
					case 1:
						return language.ck(
							$justinmimbs$date$Date$weekday(date));
					case 2:
						return language.ck(
							$justinmimbs$date$Date$weekday(date));
					case 3:
						return language.ck(
							$justinmimbs$date$Date$weekday(date));
					case 4:
						return language.g5(
							$justinmimbs$date$Date$weekday(date));
					case 5:
						return A2(
							$elm$core$String$left,
							1,
							language.ck(
								$justinmimbs$date$Date$weekday(date)));
					case 6:
						return A2(
							$elm$core$String$left,
							2,
							language.ck(
								$justinmimbs$date$Date$weekday(date)));
					default:
						return '';
				}
			case 'e':
				switch (length) {
					case 1:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$weekdayNumber(date));
					case 2:
						return $elm$core$String$fromInt(
							$justinmimbs$date$Date$weekdayNumber(date));
					default:
						return A4($justinmimbs$date$Date$formatField, language, 'E', length, date);
				}
			default:
				return '';
		}
	});
var $justinmimbs$date$Date$formatWithTokens = F3(
	function (language, tokens, date) {
		return A3(
			$elm$core$List$foldl,
			F2(
				function (token, formatted) {
					if (!token.$) {
						var _char = token.a;
						var length = token.b;
						return _Utils_ap(
							A4($justinmimbs$date$Date$formatField, language, _char, length, date),
							formatted);
					} else {
						var str = token.a;
						return _Utils_ap(str, formatted);
					}
				}),
			'',
			tokens);
	});
var $justinmimbs$date$Pattern$Literal = function (a) {
	return {$: 1, a: a};
};
var $elm$parser$Parser$Advanced$Bad = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $elm$parser$Parser$Advanced$Good = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $elm$parser$Parser$Advanced$Parser = $elm$core$Basics$identity;
var $elm$parser$Parser$Advanced$andThen = F2(
	function (callback, _v0) {
		var parseA = _v0;
		return function (s0) {
			var _v1 = parseA(s0);
			if (_v1.$ === 1) {
				var p = _v1.a;
				var x = _v1.b;
				return A2($elm$parser$Parser$Advanced$Bad, p, x);
			} else {
				var p1 = _v1.a;
				var a = _v1.b;
				var s1 = _v1.c;
				var _v2 = callback(a);
				var parseB = _v2;
				var _v3 = parseB(s1);
				if (_v3.$ === 1) {
					var p2 = _v3.a;
					var x = _v3.b;
					return A2($elm$parser$Parser$Advanced$Bad, p1 || p2, x);
				} else {
					var p2 = _v3.a;
					var b = _v3.b;
					var s2 = _v3.c;
					return A3($elm$parser$Parser$Advanced$Good, p1 || p2, b, s2);
				}
			}
		};
	});
var $elm$parser$Parser$andThen = $elm$parser$Parser$Advanced$andThen;
var $elm$parser$Parser$Advanced$map2 = F3(
	function (func, _v0, _v1) {
		var parseA = _v0;
		var parseB = _v1;
		return function (s0) {
			var _v2 = parseA(s0);
			if (_v2.$ === 1) {
				var p = _v2.a;
				var x = _v2.b;
				return A2($elm$parser$Parser$Advanced$Bad, p, x);
			} else {
				var p1 = _v2.a;
				var a = _v2.b;
				var s1 = _v2.c;
				var _v3 = parseB(s1);
				if (_v3.$ === 1) {
					var p2 = _v3.a;
					var x = _v3.b;
					return A2($elm$parser$Parser$Advanced$Bad, p1 || p2, x);
				} else {
					var p2 = _v3.a;
					var b = _v3.b;
					var s2 = _v3.c;
					return A3(
						$elm$parser$Parser$Advanced$Good,
						p1 || p2,
						A2(func, a, b),
						s2);
				}
			}
		};
	});
var $elm$parser$Parser$Advanced$ignorer = F2(
	function (keepParser, ignoreParser) {
		return A3($elm$parser$Parser$Advanced$map2, $elm$core$Basics$always, keepParser, ignoreParser);
	});
var $elm$parser$Parser$ignorer = $elm$parser$Parser$Advanced$ignorer;
var $elm$parser$Parser$Advanced$succeed = function (a) {
	return function (s) {
		return A3($elm$parser$Parser$Advanced$Good, false, a, s);
	};
};
var $elm$parser$Parser$succeed = $elm$parser$Parser$Advanced$succeed;
var $elm$parser$Parser$Expecting = function (a) {
	return {$: 0, a: a};
};
var $elm$parser$Parser$Advanced$Token = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$parser$Parser$toToken = function (str) {
	return A2(
		$elm$parser$Parser$Advanced$Token,
		str,
		$elm$parser$Parser$Expecting(str));
};
var $elm$parser$Parser$Advanced$AddRight = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $elm$parser$Parser$Advanced$DeadEnd = F4(
	function (row, col, problem, contextStack) {
		return {j9: col, kf: contextStack, ly: problem, lK: row};
	});
var $elm$parser$Parser$Advanced$Empty = {$: 0};
var $elm$parser$Parser$Advanced$fromState = F2(
	function (s, x) {
		return A2(
			$elm$parser$Parser$Advanced$AddRight,
			$elm$parser$Parser$Advanced$Empty,
			A4($elm$parser$Parser$Advanced$DeadEnd, s.lK, s.j9, x, s.k));
	});
var $elm$parser$Parser$Advanced$isSubString = _Parser_isSubString;
var $elm$parser$Parser$Advanced$token = function (_v0) {
	var str = _v0.a;
	var expecting = _v0.b;
	var progress = !$elm$core$String$isEmpty(str);
	return function (s) {
		var _v1 = A5($elm$parser$Parser$Advanced$isSubString, str, s.e, s.lK, s.j9, s.d);
		var newOffset = _v1.a;
		var newRow = _v1.b;
		var newCol = _v1.c;
		return _Utils_eq(newOffset, -1) ? A2(
			$elm$parser$Parser$Advanced$Bad,
			false,
			A2($elm$parser$Parser$Advanced$fromState, s, expecting)) : A3(
			$elm$parser$Parser$Advanced$Good,
			progress,
			0,
			{j9: newCol, k: s.k, o: s.o, e: newOffset, lK: newRow, d: s.d});
	};
};
var $elm$parser$Parser$token = function (str) {
	return $elm$parser$Parser$Advanced$token(
		$elm$parser$Parser$toToken(str));
};
var $justinmimbs$date$Pattern$escapedQuote = A2(
	$elm$parser$Parser$ignorer,
	$elm$parser$Parser$succeed(
		$justinmimbs$date$Pattern$Literal('\'')),
	$elm$parser$Parser$token('\'\''));
var $elm$parser$Parser$UnexpectedChar = {$: 11};
var $elm$parser$Parser$Advanced$isSubChar = _Parser_isSubChar;
var $elm$parser$Parser$Advanced$chompIf = F2(
	function (isGood, expecting) {
		return function (s) {
			var newOffset = A3($elm$parser$Parser$Advanced$isSubChar, isGood, s.e, s.d);
			return _Utils_eq(newOffset, -1) ? A2(
				$elm$parser$Parser$Advanced$Bad,
				false,
				A2($elm$parser$Parser$Advanced$fromState, s, expecting)) : (_Utils_eq(newOffset, -2) ? A3(
				$elm$parser$Parser$Advanced$Good,
				true,
				0,
				{j9: 1, k: s.k, o: s.o, e: s.e + 1, lK: s.lK + 1, d: s.d}) : A3(
				$elm$parser$Parser$Advanced$Good,
				true,
				0,
				{j9: s.j9 + 1, k: s.k, o: s.o, e: newOffset, lK: s.lK, d: s.d}));
		};
	});
var $elm$parser$Parser$chompIf = function (isGood) {
	return A2($elm$parser$Parser$Advanced$chompIf, isGood, $elm$parser$Parser$UnexpectedChar);
};
var $justinmimbs$date$Pattern$Field = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$parser$Parser$Advanced$chompWhileHelp = F5(
	function (isGood, offset, row, col, s0) {
		chompWhileHelp:
		while (true) {
			var newOffset = A3($elm$parser$Parser$Advanced$isSubChar, isGood, offset, s0.d);
			if (_Utils_eq(newOffset, -1)) {
				return A3(
					$elm$parser$Parser$Advanced$Good,
					_Utils_cmp(s0.e, offset) < 0,
					0,
					{j9: col, k: s0.k, o: s0.o, e: offset, lK: row, d: s0.d});
			} else {
				if (_Utils_eq(newOffset, -2)) {
					var $temp$isGood = isGood,
						$temp$offset = offset + 1,
						$temp$row = row + 1,
						$temp$col = 1,
						$temp$s0 = s0;
					isGood = $temp$isGood;
					offset = $temp$offset;
					row = $temp$row;
					col = $temp$col;
					s0 = $temp$s0;
					continue chompWhileHelp;
				} else {
					var $temp$isGood = isGood,
						$temp$offset = newOffset,
						$temp$row = row,
						$temp$col = col + 1,
						$temp$s0 = s0;
					isGood = $temp$isGood;
					offset = $temp$offset;
					row = $temp$row;
					col = $temp$col;
					s0 = $temp$s0;
					continue chompWhileHelp;
				}
			}
		}
	});
var $elm$parser$Parser$Advanced$chompWhile = function (isGood) {
	return function (s) {
		return A5($elm$parser$Parser$Advanced$chompWhileHelp, isGood, s.e, s.lK, s.j9, s);
	};
};
var $elm$parser$Parser$chompWhile = $elm$parser$Parser$Advanced$chompWhile;
var $elm$parser$Parser$Advanced$getOffset = function (s) {
	return A3($elm$parser$Parser$Advanced$Good, false, s.e, s);
};
var $elm$parser$Parser$getOffset = $elm$parser$Parser$Advanced$getOffset;
var $elm$parser$Parser$Advanced$keeper = F2(
	function (parseFunc, parseArg) {
		return A3($elm$parser$Parser$Advanced$map2, $elm$core$Basics$apL, parseFunc, parseArg);
	});
var $elm$parser$Parser$keeper = $elm$parser$Parser$Advanced$keeper;
var $elm$parser$Parser$Problem = function (a) {
	return {$: 12, a: a};
};
var $elm$parser$Parser$Advanced$problem = function (x) {
	return function (s) {
		return A2(
			$elm$parser$Parser$Advanced$Bad,
			false,
			A2($elm$parser$Parser$Advanced$fromState, s, x));
	};
};
var $elm$parser$Parser$problem = function (msg) {
	return $elm$parser$Parser$Advanced$problem(
		$elm$parser$Parser$Problem(msg));
};
var $elm$core$String$foldr = _String_foldr;
var $elm$core$String$toList = function (string) {
	return A3($elm$core$String$foldr, $elm$core$List$cons, _List_Nil, string);
};
var $justinmimbs$date$Pattern$fieldRepeats = function (str) {
	var _v0 = $elm$core$String$toList(str);
	if (_v0.b && (!_v0.b.b)) {
		var _char = _v0.a;
		return A2(
			$elm$parser$Parser$keeper,
			A2(
				$elm$parser$Parser$keeper,
				$elm$parser$Parser$succeed(
					F2(
						function (x, y) {
							return A2($justinmimbs$date$Pattern$Field, _char, 1 + (y - x));
						})),
				A2(
					$elm$parser$Parser$ignorer,
					$elm$parser$Parser$getOffset,
					$elm$parser$Parser$chompWhile(
						$elm$core$Basics$eq(_char)))),
			$elm$parser$Parser$getOffset);
	} else {
		return $elm$parser$Parser$problem('expected exactly one char');
	}
};
var $elm$parser$Parser$Advanced$mapChompedString = F2(
	function (func, _v0) {
		var parse = _v0;
		return function (s0) {
			var _v1 = parse(s0);
			if (_v1.$ === 1) {
				var p = _v1.a;
				var x = _v1.b;
				return A2($elm$parser$Parser$Advanced$Bad, p, x);
			} else {
				var p = _v1.a;
				var a = _v1.b;
				var s1 = _v1.c;
				return A3(
					$elm$parser$Parser$Advanced$Good,
					p,
					A2(
						func,
						A3($elm$core$String$slice, s0.e, s1.e, s0.d),
						a),
					s1);
			}
		};
	});
var $elm$parser$Parser$Advanced$getChompedString = function (parser) {
	return A2($elm$parser$Parser$Advanced$mapChompedString, $elm$core$Basics$always, parser);
};
var $elm$parser$Parser$getChompedString = $elm$parser$Parser$Advanced$getChompedString;
var $justinmimbs$date$Pattern$field = A2(
	$elm$parser$Parser$andThen,
	$justinmimbs$date$Pattern$fieldRepeats,
	$elm$parser$Parser$getChompedString(
		$elm$parser$Parser$chompIf($elm$core$Char$isAlpha)));
var $justinmimbs$date$Pattern$finalize = A2(
	$elm$core$List$foldl,
	F2(
		function (token, tokens) {
			var _v0 = _Utils_Tuple2(token, tokens);
			if (((_v0.a.$ === 1) && _v0.b.b) && (_v0.b.a.$ === 1)) {
				var x = _v0.a.a;
				var _v1 = _v0.b;
				var y = _v1.a.a;
				var rest = _v1.b;
				return A2(
					$elm$core$List$cons,
					$justinmimbs$date$Pattern$Literal(
						_Utils_ap(x, y)),
					rest);
			} else {
				return A2($elm$core$List$cons, token, tokens);
			}
		}),
	_List_Nil);
var $elm$parser$Parser$Advanced$lazy = function (thunk) {
	return function (s) {
		var _v0 = thunk(0);
		var parse = _v0;
		return parse(s);
	};
};
var $elm$parser$Parser$lazy = $elm$parser$Parser$Advanced$lazy;
var $justinmimbs$date$Pattern$isLiteralChar = function (_char) {
	return (_char !== '\'') && (!$elm$core$Char$isAlpha(_char));
};
var $elm$parser$Parser$Advanced$map = F2(
	function (func, _v0) {
		var parse = _v0;
		return function (s0) {
			var _v1 = parse(s0);
			if (!_v1.$) {
				var p = _v1.a;
				var a = _v1.b;
				var s1 = _v1.c;
				return A3(
					$elm$parser$Parser$Advanced$Good,
					p,
					func(a),
					s1);
			} else {
				var p = _v1.a;
				var x = _v1.b;
				return A2($elm$parser$Parser$Advanced$Bad, p, x);
			}
		};
	});
var $elm$parser$Parser$map = $elm$parser$Parser$Advanced$map;
var $justinmimbs$date$Pattern$literal = A2(
	$elm$parser$Parser$map,
	$justinmimbs$date$Pattern$Literal,
	$elm$parser$Parser$getChompedString(
		A2(
			$elm$parser$Parser$ignorer,
			A2(
				$elm$parser$Parser$ignorer,
				$elm$parser$Parser$succeed(0),
				$elm$parser$Parser$chompIf($justinmimbs$date$Pattern$isLiteralChar)),
			$elm$parser$Parser$chompWhile($justinmimbs$date$Pattern$isLiteralChar))));
var $elm$parser$Parser$Advanced$Append = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $elm$parser$Parser$Advanced$oneOfHelp = F3(
	function (s0, bag, parsers) {
		oneOfHelp:
		while (true) {
			if (!parsers.b) {
				return A2($elm$parser$Parser$Advanced$Bad, false, bag);
			} else {
				var parse = parsers.a;
				var remainingParsers = parsers.b;
				var _v1 = parse(s0);
				if (!_v1.$) {
					var step = _v1;
					return step;
				} else {
					var step = _v1;
					var p = step.a;
					var x = step.b;
					if (p) {
						return step;
					} else {
						var $temp$s0 = s0,
							$temp$bag = A2($elm$parser$Parser$Advanced$Append, bag, x),
							$temp$parsers = remainingParsers;
						s0 = $temp$s0;
						bag = $temp$bag;
						parsers = $temp$parsers;
						continue oneOfHelp;
					}
				}
			}
		}
	});
var $elm$parser$Parser$Advanced$oneOf = function (parsers) {
	return function (s) {
		return A3($elm$parser$Parser$Advanced$oneOfHelp, s, $elm$parser$Parser$Advanced$Empty, parsers);
	};
};
var $elm$parser$Parser$oneOf = $elm$parser$Parser$Advanced$oneOf;
var $elm$parser$Parser$ExpectingEnd = {$: 10};
var $elm$parser$Parser$Advanced$end = function (x) {
	return function (s) {
		return _Utils_eq(
			$elm$core$String$length(s.d),
			s.e) ? A3($elm$parser$Parser$Advanced$Good, false, 0, s) : A2(
			$elm$parser$Parser$Advanced$Bad,
			false,
			A2($elm$parser$Parser$Advanced$fromState, s, x));
	};
};
var $elm$parser$Parser$end = $elm$parser$Parser$Advanced$end($elm$parser$Parser$ExpectingEnd);
var $justinmimbs$date$Pattern$quotedHelp = function (result) {
	return $elm$parser$Parser$oneOf(
		_List_fromArray(
			[
				A2(
				$elm$parser$Parser$andThen,
				function (str) {
					return $justinmimbs$date$Pattern$quotedHelp(
						_Utils_ap(result, str));
				},
				$elm$parser$Parser$getChompedString(
					A2(
						$elm$parser$Parser$ignorer,
						A2(
							$elm$parser$Parser$ignorer,
							$elm$parser$Parser$succeed(0),
							$elm$parser$Parser$chompIf(
								$elm$core$Basics$neq('\''))),
						$elm$parser$Parser$chompWhile(
							$elm$core$Basics$neq('\''))))),
				A2(
				$elm$parser$Parser$andThen,
				function (_v0) {
					return $justinmimbs$date$Pattern$quotedHelp(result + '\'');
				},
				$elm$parser$Parser$token('\'\'')),
				$elm$parser$Parser$succeed(result)
			]));
};
var $justinmimbs$date$Pattern$quoted = A2(
	$elm$parser$Parser$keeper,
	A2(
		$elm$parser$Parser$ignorer,
		$elm$parser$Parser$succeed($justinmimbs$date$Pattern$Literal),
		$elm$parser$Parser$chompIf(
			$elm$core$Basics$eq('\''))),
	A2(
		$elm$parser$Parser$ignorer,
		$justinmimbs$date$Pattern$quotedHelp(''),
		$elm$parser$Parser$oneOf(
			_List_fromArray(
				[
					$elm$parser$Parser$chompIf(
					$elm$core$Basics$eq('\'')),
					$elm$parser$Parser$end
				]))));
var $justinmimbs$date$Pattern$patternHelp = function (tokens) {
	return $elm$parser$Parser$oneOf(
		_List_fromArray(
			[
				A2(
				$elm$parser$Parser$andThen,
				function (token) {
					return $justinmimbs$date$Pattern$patternHelp(
						A2($elm$core$List$cons, token, tokens));
				},
				$elm$parser$Parser$oneOf(
					_List_fromArray(
						[$justinmimbs$date$Pattern$field, $justinmimbs$date$Pattern$literal, $justinmimbs$date$Pattern$escapedQuote, $justinmimbs$date$Pattern$quoted]))),
				$elm$parser$Parser$lazy(
				function (_v0) {
					return $elm$parser$Parser$succeed(
						$justinmimbs$date$Pattern$finalize(tokens));
				})
			]));
};
var $elm$parser$Parser$DeadEnd = F3(
	function (row, col, problem) {
		return {j9: col, ly: problem, lK: row};
	});
var $elm$parser$Parser$problemToDeadEnd = function (p) {
	return A3($elm$parser$Parser$DeadEnd, p.lK, p.j9, p.ly);
};
var $elm$parser$Parser$Advanced$bagToList = F2(
	function (bag, list) {
		bagToList:
		while (true) {
			switch (bag.$) {
				case 0:
					return list;
				case 1:
					var bag1 = bag.a;
					var x = bag.b;
					var $temp$bag = bag1,
						$temp$list = A2($elm$core$List$cons, x, list);
					bag = $temp$bag;
					list = $temp$list;
					continue bagToList;
				default:
					var bag1 = bag.a;
					var bag2 = bag.b;
					var $temp$bag = bag1,
						$temp$list = A2($elm$parser$Parser$Advanced$bagToList, bag2, list);
					bag = $temp$bag;
					list = $temp$list;
					continue bagToList;
			}
		}
	});
var $elm$parser$Parser$Advanced$run = F2(
	function (_v0, src) {
		var parse = _v0;
		var _v1 = parse(
			{j9: 1, k: _List_Nil, o: 1, e: 0, lK: 1, d: src});
		if (!_v1.$) {
			var value = _v1.b;
			return $elm$core$Result$Ok(value);
		} else {
			var bag = _v1.b;
			return $elm$core$Result$Err(
				A2($elm$parser$Parser$Advanced$bagToList, bag, _List_Nil));
		}
	});
var $elm$parser$Parser$run = F2(
	function (parser, source) {
		var _v0 = A2($elm$parser$Parser$Advanced$run, parser, source);
		if (!_v0.$) {
			var a = _v0.a;
			return $elm$core$Result$Ok(a);
		} else {
			var problems = _v0.a;
			return $elm$core$Result$Err(
				A2($elm$core$List$map, $elm$parser$Parser$problemToDeadEnd, problems));
		}
	});
var $elm$core$Result$withDefault = F2(
	function (def, result) {
		if (!result.$) {
			var a = result.a;
			return a;
		} else {
			return def;
		}
	});
var $justinmimbs$date$Pattern$fromString = function (str) {
	return A2(
		$elm$core$Result$withDefault,
		_List_fromArray(
			[
				$justinmimbs$date$Pattern$Literal(str)
			]),
		A2(
			$elm$parser$Parser$run,
			$justinmimbs$date$Pattern$patternHelp(_List_Nil),
			str));
};
var $justinmimbs$date$Date$formatWithLanguage = F2(
	function (language, pattern) {
		var tokens = $elm$core$List$reverse(
			$justinmimbs$date$Pattern$fromString(pattern));
		return A2($justinmimbs$date$Date$formatWithTokens, language, tokens);
	});
var $justinmimbs$date$Date$monthToName = function (m) {
	switch (m) {
		case 0:
			return 'January';
		case 1:
			return 'February';
		case 2:
			return 'March';
		case 3:
			return 'April';
		case 4:
			return 'May';
		case 5:
			return 'June';
		case 6:
			return 'July';
		case 7:
			return 'August';
		case 8:
			return 'September';
		case 9:
			return 'October';
		case 10:
			return 'November';
		default:
			return 'December';
	}
};
var $justinmimbs$date$Date$weekdayToName = function (wd) {
	switch (wd) {
		case 0:
			return 'Monday';
		case 1:
			return 'Tuesday';
		case 2:
			return 'Wednesday';
		case 3:
			return 'Thursday';
		case 4:
			return 'Friday';
		case 5:
			return 'Saturday';
		default:
			return 'Sunday';
	}
};
var $justinmimbs$date$Date$language_en = {
	fe: $justinmimbs$date$Date$withOrdinalSuffix,
	f4: $justinmimbs$date$Date$monthToName,
	ey: A2(
		$elm$core$Basics$composeR,
		$justinmimbs$date$Date$monthToName,
		$elm$core$String$left(3)),
	g5: $justinmimbs$date$Date$weekdayToName,
	ck: A2(
		$elm$core$Basics$composeR,
		$justinmimbs$date$Date$weekdayToName,
		$elm$core$String$left(3))
};
var $justinmimbs$date$Date$format = function (pattern) {
	return A2($justinmimbs$date$Date$formatWithLanguage, $justinmimbs$date$Date$language_en, pattern);
};
var $justinmimbs$date$Date$toIsoString = $justinmimbs$date$Date$format('yyyy-MM-dd');
var $author$project$Horizon$toLocalFormat = function (toStorage) {
	return {
		A: function () {
			var _v0 = toStorage.A;
			switch (_v0.$) {
				case 0:
					return $elm$core$Maybe$Nothing;
				case 1:
					return $elm$core$Maybe$Nothing;
				default:
					var horizon = _v0.a;
					return $elm$core$Maybe$Just(horizon);
			}
		}(),
		Y: toStorage.Y,
		ab: toStorage.ab
	};
};
var $elm$core$Basics$clamp = F3(
	function (low, high, number) {
		return (_Utils_cmp(number, low) < 0) ? low : ((_Utils_cmp(number, high) > 0) ? high : number);
	});
var $justinmimbs$date$Date$daysBeforeMonth = F2(
	function (y, m) {
		var leapDays = $justinmimbs$date$Date$isLeapYear(y) ? 1 : 0;
		switch (m) {
			case 0:
				return 0;
			case 1:
				return 31;
			case 2:
				return 59 + leapDays;
			case 3:
				return 90 + leapDays;
			case 4:
				return 120 + leapDays;
			case 5:
				return 151 + leapDays;
			case 6:
				return 181 + leapDays;
			case 7:
				return 212 + leapDays;
			case 8:
				return 243 + leapDays;
			case 9:
				return 273 + leapDays;
			case 10:
				return 304 + leapDays;
			default:
				return 334 + leapDays;
		}
	});
var $justinmimbs$date$Date$fromCalendarDate = F3(
	function (y, m, d) {
		return ($justinmimbs$date$Date$daysBeforeYear(y) + A2($justinmimbs$date$Date$daysBeforeMonth, y, m)) + A3(
			$elm$core$Basics$clamp,
			1,
			A2($justinmimbs$date$Date$daysInMonth, y, m),
			d);
	});
var $elm$time$Time$flooredDiv = F2(
	function (numerator, denominator) {
		return $elm$core$Basics$floor(numerator / denominator);
	});
var $elm$time$Time$toAdjustedMinutesHelp = F3(
	function (defaultOffset, posixMinutes, eras) {
		toAdjustedMinutesHelp:
		while (true) {
			if (!eras.b) {
				return posixMinutes + defaultOffset;
			} else {
				var era = eras.a;
				var olderEras = eras.b;
				if (_Utils_cmp(era.jl, posixMinutes) < 0) {
					return posixMinutes + era.e;
				} else {
					var $temp$defaultOffset = defaultOffset,
						$temp$posixMinutes = posixMinutes,
						$temp$eras = olderEras;
					defaultOffset = $temp$defaultOffset;
					posixMinutes = $temp$posixMinutes;
					eras = $temp$eras;
					continue toAdjustedMinutesHelp;
				}
			}
		}
	});
var $elm$time$Time$toAdjustedMinutes = F2(
	function (_v0, time) {
		var defaultOffset = _v0.a;
		var eras = _v0.b;
		return A3(
			$elm$time$Time$toAdjustedMinutesHelp,
			defaultOffset,
			A2(
				$elm$time$Time$flooredDiv,
				$elm$time$Time$posixToMillis(time),
				60000),
			eras);
	});
var $elm$time$Time$toCivil = function (minutes) {
	var rawDay = A2($elm$time$Time$flooredDiv, minutes, 60 * 24) + 719468;
	var era = (((rawDay >= 0) ? rawDay : (rawDay - 146096)) / 146097) | 0;
	var dayOfEra = rawDay - (era * 146097);
	var yearOfEra = ((((dayOfEra - ((dayOfEra / 1460) | 0)) + ((dayOfEra / 36524) | 0)) - ((dayOfEra / 146096) | 0)) / 365) | 0;
	var dayOfYear = dayOfEra - (((365 * yearOfEra) + ((yearOfEra / 4) | 0)) - ((yearOfEra / 100) | 0));
	var mp = (((5 * dayOfYear) + 2) / 153) | 0;
	var month = mp + ((mp < 10) ? 3 : (-9));
	var year = yearOfEra + (era * 400);
	return {
		hA: (dayOfYear - ((((153 * mp) + 2) / 5) | 0)) + 1,
		it: month,
		jK: year + ((month <= 2) ? 1 : 0)
	};
};
var $elm$time$Time$toDay = F2(
	function (zone, time) {
		return $elm$time$Time$toCivil(
			A2($elm$time$Time$toAdjustedMinutes, zone, time)).hA;
	});
var $elm$time$Time$toMonth = F2(
	function (zone, time) {
		var _v0 = $elm$time$Time$toCivil(
			A2($elm$time$Time$toAdjustedMinutes, zone, time)).it;
		switch (_v0) {
			case 1:
				return 0;
			case 2:
				return 1;
			case 3:
				return 2;
			case 4:
				return 3;
			case 5:
				return 4;
			case 6:
				return 5;
			case 7:
				return 6;
			case 8:
				return 7;
			case 9:
				return 8;
			case 10:
				return 9;
			case 11:
				return 10;
			default:
				return 11;
		}
	});
var $elm$time$Time$toYear = F2(
	function (zone, time) {
		return $elm$time$Time$toCivil(
			A2($elm$time$Time$toAdjustedMinutes, zone, time)).jK;
	});
var $justinmimbs$date$Date$fromPosix = F2(
	function (zone, posix) {
		return A3(
			$justinmimbs$date$Date$fromCalendarDate,
			A2($elm$time$Time$toYear, zone, posix),
			A2($elm$time$Time$toMonth, zone, posix),
			A2($elm$time$Time$toDay, zone, posix));
	});
var $elm$time$Time$here = _Time_here(0);
var $justinmimbs$date$Date$today = A3($elm$core$Task$map2, $justinmimbs$date$Date$fromPosix, $elm$time$Time$here, $elm$time$Time$now);
var $author$project$Horizon$updateInternalHorizon = F2(
	function (horizon, model) {
		return _Utils_update(
			model,
			{
				A: function () {
					if (horizon.$ === 1) {
						return $author$project$Horizon$All;
					} else {
						var hor = horizon.a;
						return $author$project$Horizon$Label(hor);
					}
				}()
			});
	});
var $author$project$Horizon$updatefromlocalstorage = F2(
	function (data, model) {
		return _Utils_update(
			model,
			{A: data.A, Y: data.Y, ab: data.ab});
	});
var $author$project$Horizon$cropDate = function (date) {
	return A2($elm$core$String$left, 10, date);
};
var $author$project$Util$dateof = function (strdate) {
	var _v0 = A2($elm$core$String$split, 'T', strdate);
	if (_v0.b) {
		var head = _v0.a;
		return head;
	} else {
		return '';
	}
};
var $author$project$Horizon$viewdateT = function (model) {
	var bounds = function () {
		var _v2 = model.bW;
		if (!_v2.$) {
			var _v3 = _v2.a;
			var min = _v3.a;
			var max = _v3.b;
			return $elm$core$Maybe$Just(
				_Utils_Tuple3(min, max, true));
		} else {
			var _v4 = model.aD;
			if (!_v4.$) {
				var _v5 = _v4.a;
				var min = _v5.a;
				var max = _v5.b;
				return $elm$core$Maybe$Just(
					_Utils_Tuple3(min, max, true));
			} else {
				var _v6 = model.bh;
				if (!_v6.$) {
					var _v7 = _v6.a;
					var min = _v7.a;
					var max = _v7.b;
					return $elm$core$Maybe$Just(
						_Utils_Tuple3(min, max, false));
				} else {
					var _v8 = model.b0;
					if (!_v8.$) {
						var _v9 = _v8.a;
						var min = _v9.a;
						var max = _v9.b;
						return $elm$core$Maybe$Just(
							_Utils_Tuple3(min, max, false));
					} else {
						return $elm$core$Maybe$Nothing;
					}
				}
			}
		}
	}();
	if (bounds.$ === 1) {
		return $elm$core$Maybe$Nothing;
	} else {
		var _v1 = bounds.a;
		var min = _v1.a;
		var max = _v1.b;
		var fromZoom = _v1.c;
		return $elm$core$Maybe$Just(
			_Utils_Tuple3(
				$author$project$Util$dateof(min),
				$author$project$Util$dateof(max),
				fromZoom));
	}
};
var $author$project$Horizon$viewdate = function (model) {
	var result = $author$project$Horizon$viewdateT(model);
	if (result.$ === 1) {
		return _Utils_Tuple3('yyyy-mm-dd', 'yyyy-mm-dd', false);
	} else {
		var _v1 = result.a;
		var from = _v1.a;
		var to = _v1.b;
		var fromZoom = _v1.c;
		return _Utils_Tuple3(
			$author$project$Horizon$cropDate(from),
			$author$project$Horizon$cropDate(to),
			fromZoom);
	}
};
var $author$project$Horizon$updateHorizon = F3(
	function (msg, convertMsg, model) {
		switch (msg.$) {
			case 0:
				var rawdata = msg.a;
				var _v1 = A2($elm$json$Json$Decode$decodeString, $author$project$Horizon$localstoragedecoder, rawdata);
				if (!_v1.$) {
					var datadict = _v1.a;
					var enrichdatadict = $author$project$Horizon$toHorizonType(datadict);
					var newdatadict = function () {
						var _v3 = model.aD;
						if (_v3.$ === 1) {
							return enrichdatadict;
						} else {
							return _Utils_update(
								enrichdatadict,
								{A: $author$project$Horizon$Disabled});
						}
					}();
					var newmodel = A2($author$project$Horizon$updatefromlocalstorage, newdatadict, model);
					return _Utils_Tuple2(
						newmodel,
						function () {
							var _v2 = newmodel.aD;
							if (_v2.$ === 1) {
								return A2(
									$elm$core$Task$perform,
									function (t) {
										return convertMsg(
											$author$project$Horizon$Internal(
												A2($author$project$Horizon$DateNow, t, 0)));
									},
									$justinmimbs$date$Date$today);
							} else {
								var bounds = _v2.a;
								return $elm$core$Platform$Cmd$batch(
									_List_fromArray(
										[
											A2($author$project$Horizon$getChoices, model, convertMsg),
											A2(
											$elm$core$Task$perform,
											function (t) {
												return convertMsg(
													$author$project$Horizon$Internal(
														A2($author$project$Horizon$DateNow, t, 1)));
											},
											$justinmimbs$date$Date$today),
											A2(
											$elm$core$Task$perform,
											$elm$core$Basics$identity,
											$elm$core$Task$succeed(
												convertMsg(
													$author$project$Horizon$Fetch(
														$author$project$Horizon$GetDirectData(
															$elm$core$Maybe$Just(bounds))))))
										]));
							}
						}());
				} else {
					return _Utils_Tuple2(model, $elm$core$Platform$Cmd$none);
				}
			case 1:
				var op = msg.a;
				var frameModel = _Utils_update(
					model,
					{bh: $elm$core$Maybe$Nothing, T: 1, aD: $elm$core$Maybe$Nothing, bW: $elm$core$Maybe$Nothing});
				switch (op.$) {
					case 0:
						var horizon = op.a;
						var userprefs = A3($author$project$Horizon$LocalStorageData, horizon, frameModel.ab, frameModel.Y);
						var updatedModel = A2($author$project$Horizon$updateInternalHorizon, horizon, frameModel);
						return _Utils_Tuple2(
							updatedModel,
							$elm$core$Platform$Cmd$batch(
								_List_fromArray(
									[
										$author$project$Horizon$saveToLocalStorage(userprefs),
										A3($author$project$Horizon$getBounds, updatedModel, convertMsg, 0)
									])));
					case 1:
						var i = op.a;
						return _Utils_Tuple2(
							frameModel,
							A3($author$project$Horizon$slideBounds, model, convertMsg, i));
					default:
						var newmodel = _Utils_update(
							frameModel,
							{
								b1: false,
								ax: {aA: $elm$core$Maybe$Nothing, aF: $elm$core$Maybe$Nothing},
								A: $author$project$Horizon$Disabled,
								aD: $author$project$Horizon$completeDates(
									$elm$core$Maybe$Just(
										_Utils_Tuple2(
											A2($elm$core$Maybe$withDefault, '', model.ax.aA),
											A2($elm$core$Maybe$withDefault, '', model.ax.aF))))
							});
						return _Utils_Tuple2(
							newmodel,
							A2(
								$elm$core$Task$perform,
								$elm$core$Basics$identity,
								$elm$core$Task$succeed(
									convertMsg(
										$author$project$Horizon$Fetch(
											$author$project$Horizon$GetDirectData(newmodel.aD))))));
				}
			case 3:
				var op = msg.a;
				switch (op.$) {
					case 0:
						var newmodel = _Utils_update(
							model,
							{b1: !model.b1});
						if (newmodel.b1) {
							var _v6 = $author$project$Horizon$viewdate(model);
							var from = _v6.a;
							var to = _v6.b;
							return _Utils_Tuple2(
								_Utils_update(
									newmodel,
									{
										ax: {
											aA: $elm$core$Maybe$Just(from),
											aF: $elm$core$Maybe$Just(to)
										}
									}),
								$elm$core$Platform$Cmd$none);
						} else {
							return _Utils_Tuple2(
								_Utils_update(
									newmodel,
									{
										ax: {aA: $elm$core$Maybe$Nothing, aF: $elm$core$Maybe$Nothing}
									}),
								$elm$core$Platform$Cmd$none);
						}
					case 1:
						var fromOrTo = op.a;
						var value = op.b;
						var previous = model.ax;
						var newEdited = function () {
							if (!fromOrTo) {
								return {
									aA: $elm$core$Maybe$Just(value),
									aF: previous.aF
								};
							} else {
								return {
									aA: previous.aA,
									aF: $elm$core$Maybe$Just(value)
								};
							}
						}();
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{ax: newEdited}),
							$elm$core$Platform$Cmd$none);
					case 3:
						if (!op.a.$) {
							var raw = op.a.a;
							var _v8 = A2($elm$json$Json$Decode$decodeString, $author$project$Horizon$decodeChoices, raw);
							if (_v8.$ === 1) {
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{T: 3}),
									$elm$core$Platform$Cmd$none);
							} else {
								var choices = _v8.a;
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{dB: choices}),
									$elm$core$Platform$Cmd$none);
							}
						} else {
							var emsg = op.a.a;
							return _Utils_Tuple2(
								_Utils_update(
									model,
									{T: 3}),
								$elm$core$Platform$Cmd$none);
						}
					default:
						var date = op.a;
						var when = op.b;
						var newmodel = _Utils_update(
							model,
							{
								bc: $justinmimbs$date$Date$toIsoString(date)
							});
						return _Utils_Tuple2(
							newmodel,
							function () {
								if (!when) {
									return $elm$core$Platform$Cmd$batch(
										_List_fromArray(
											[
												A3($author$project$Horizon$getBounds, newmodel, convertMsg, 0),
												A2($author$project$Horizon$getChoices, newmodel, convertMsg)
											]));
								} else {
									return $elm$core$Platform$Cmd$none;
								}
							}());
				}
			default:
				var fetch = msg.a;
				switch (fetch.$) {
					case 0:
						if (!fetch.a.$) {
							var raw = fetch.a.a;
							var _v11 = A2($elm$json$Json$Decode$decodeString, $author$project$Horizon$decodeBounds, raw);
							if (_v11.$ === 1) {
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{T: 3}),
									$elm$core$Platform$Cmd$none);
							} else {
								var bounds = _v11.a;
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{
											bc: bounds.bc,
											bh: $elm$core$Maybe$Just(
												_Utils_Tuple2(bounds.aA, bounds.aF))
										}),
									$elm$core$Platform$Cmd$none);
							}
						} else {
							var emsg = fetch.a.a;
							return _Utils_Tuple2(
								_Utils_update(
									model,
									{T: 3}),
								$elm$core$Platform$Cmd$none);
						}
					case 1:
						var queryBounds = fetch.a;
						var allModel = _Utils_update(
							model,
							{bh: $elm$core$Maybe$Nothing, T: 1, aD: queryBounds, bW: $elm$core$Maybe$Nothing});
						return _Utils_Tuple2(
							allModel,
							A2(
								$elm$core$Task$perform,
								function (t) {
									return convertMsg(
										$author$project$Horizon$Internal(
											A2($author$project$Horizon$DateNow, t, 1)));
								},
								$justinmimbs$date$Date$today));
					default:
						var op = fetch.a;
						var dataModel = _Utils_update(
							model,
							{T: 1});
						switch (op.$) {
							case 0:
								var timeZone = op.a;
								var userprefs = A3($author$project$Horizon$EnrichFromStorage, dataModel.A, timeZone, dataModel.Y);
								var newmodel = _Utils_update(
									dataModel,
									{ab: timeZone});
								return _Utils_Tuple2(
									newmodel,
									$author$project$Horizon$saveToLocalStorage(
										$author$project$Horizon$toLocalFormat(userprefs)));
							case 1:
								var isChecked = op.a;
								var userprefs = A3($author$project$Horizon$EnrichFromStorage, model.A, model.ab, isChecked);
								var newmodel = _Utils_update(
									dataModel,
									{Y: isChecked});
								return _Utils_Tuple2(
									newmodel,
									$author$project$Horizon$saveToLocalStorage(
										$author$project$Horizon$toLocalFormat(userprefs)));
							default:
								var newmodel = _Utils_update(
									dataModel,
									{d1: !model.d1});
								return _Utils_Tuple2(newmodel, $elm$core$Platform$Cmd$none);
						}
				}
		}
	});
var $author$project$Horizon$Success = 2;
var $elm$core$List$maximum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$max, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Horizon$formatBoundDates = function (val) {
	var dates = $elm$core$Dict$keys(val);
	var maxappdate = $author$project$Util$cleanupdate(
		A2(
			$elm$core$Maybe$withDefault,
			'',
			$elm$core$List$maximum(dates)));
	var minappdate = function () {
		if (dates.b) {
			var head = dates.a;
			return $author$project$Util$cleanupdate(head);
		} else {
			return '';
		}
	}();
	return _Utils_Tuple2(
		$author$project$Util$dateof(minappdate),
		$author$project$Util$dateof(maxappdate));
};
var $author$project$Horizon$updateHorizonFromData = F2(
	function (model, val) {
		var _v0 = $author$project$Horizon$formatBoundDates(val);
		var min = _v0.a;
		var max = _v0.b;
		return _Utils_update(
			model,
			{
				b0: (min !== '') ? $elm$core$Maybe$Just(
					_Utils_Tuple2(min, max)) : $elm$core$Maybe$Nothing,
				T: 2
			});
	});
var $author$project$Horizon$updateZoom = F2(
	function (model, newZoom) {
		var _v0 = newZoom.de;
		if (_v0.$ === 1) {
			var _v1 = newZoom.cl;
			if (_v1.$ === 1) {
				return {de: $elm$core$Maybe$Nothing, cl: $elm$core$Maybe$Nothing};
			} else {
				var zoomY = _v1.a;
				return {
					de: model.bW,
					cl: $elm$core$Maybe$Just(zoomY)
				};
			}
		} else {
			var zoomX = _v0.a;
			var _v2 = newZoom.cl;
			if (_v2.$ === 1) {
				return {
					de: $elm$core$Maybe$Just(zoomX),
					cl: model.e_
				};
			} else {
				var zoomY = _v2.a;
				return {
					de: $elm$core$Maybe$Just(zoomX),
					cl: $elm$core$Maybe$Just(zoomY)
				};
			}
		}
	});
var $author$project$Tsinfo$DebounceChangedHistoryIdate = function (a) {
	return {$: 46, a: a};
};
var $author$project$Tsinfo$updatedChangedHistoryIdateDebouncer = {
	hV: function ($) {
		return $.ei;
	},
	$9: $author$project$Tsinfo$DebounceChangedHistoryIdate,
	je: F2(
		function (deb, model) {
			return _Utils_update(
				model,
				{ei: deb});
		})
};
var $author$project$Tsinfo$DebounceChangedIdate = function (a) {
	return {$: 8, a: a};
};
var $author$project$Tsinfo$updatedchangedidatebouncer = {
	hV: function ($) {
		return $.eb;
	},
	$9: $author$project$Tsinfo$DebounceChangedIdate,
	je: F2(
		function (deb, model) {
			return _Utils_update(
				model,
				{eb: deb});
		})
};
var $author$project$Tsinfo$update = F2(
	function (msg, model) {
		var doerr = F2(
			function (tag, error) {
				return $author$project$Util$nocmd(
					A2($author$project$Util$adderror, model, tag + (' -> ' + error)));
			});
		switch (msg.$) {
			case 3:
				var tab = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{df: tab}));
			case 0:
				if (!msg.a.$) {
					var result = msg.a.a;
					var _v1 = A2($elm$json$Json$Decode$decodeString, $author$project$Metadata$decodemeta, result);
					if (!_v1.$) {
						var allmeta = _v1.a;
						var model_horizon = model.A;
						var isformula = A2($elm$core$Dict$member, 'formula', allmeta);
						var newmodel = _Utils_update(
							model,
							{
								A: _Utils_update(
									model_horizon,
									{fz: isformula}),
								aM: isformula ? $elm$core$Maybe$Just($author$project$Tsinfo$defaultRevMaxFormula) : $elm$core$Maybe$Just($author$project$Tsinfo$defaultRevMaxPrimary),
								cN: allmeta,
								dL: isformula ? $author$project$Tsinfo$defaultRevMaxFormula : $author$project$Tsinfo$defaultRevMaxPrimary,
								jd: isformula ? 1 : 0
							});
						var cmd = $elm$core$Platform$Cmd$batch(
							_Utils_ap(
								_List_fromArray(
									[
										A4($author$project$Info$getidates, model, 'series', $author$project$Tsinfo$InsertionDates, model.A.d1)
									]),
								isformula ? _List_fromArray(
									[
										A5($author$project$Info$getformula, model, model.ao, model.hR, 'series', $author$project$Tsinfo$GotFormula),
										$author$project$Tsinfo$getdepth(model),
										$author$project$Tsinfo$gethascache(model)
									]) : _List_fromArray(
									[
										A5($author$project$Info$getlog, model.bv, model.ao, model.kX, 'series', $author$project$Tsinfo$GotLog)
									])));
						return _Utils_Tuple2(newmodel, cmd);
					} else {
						var err = _v1.a;
						return A2(
							doerr,
							'gotmeta decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var err = msg.a.a;
					var newmodel = _Utils_update(
						model,
						{
							hL: A2(
								$elm$core$List$append,
								model.hL,
								_List_fromArray(
									[
										'gotsysmeta http' + (' -> ' + $author$project$Util$unwraperror(err))
									]))
						});
					return $author$project$Util$nocmd(newmodel);
				}
			case 1:
				if (!msg.a.$) {
					var result = msg.a.a;
					var _v2 = A2($elm$json$Json$Decode$decodeString, $author$project$Metadata$decodemeta, result);
					if (!_v2.$) {
						var allmeta = _v2.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{g3: allmeta}));
					} else {
						var err = _v2.a;
						return A2(
							doerr,
							'gotmeta decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'gotusermeta http',
						$author$project$Util$unwraperror(err));
				}
			case 12:
				if (!msg.a.$) {
					var rawdepth = msg.a.a;
					var depth = function () {
						var _v3 = A2($elm$json$Json$Decode$decodeString, $elm$json$Json$Decode$int, rawdepth);
						if (!_v3.$) {
							var depth_ = _v3.a;
							return depth_;
						} else {
							return 0;
						}
					}();
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{hS: depth}),
						$elm$core$Platform$Cmd$batch(
							A2(
								$elm$core$List$map,
								function (d) {
									return A5($author$project$Info$getformula, model, model.ao, d, 'series', $author$project$Tsinfo$GotFormula);
								},
								A2($elm$core$List$range, 0, depth))));
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'gotdepth http',
						$author$project$Util$unwraperror(err));
				}
			case 2:
				if (!msg.a.$) {
					var rawsource = msg.a.a;
					var _v4 = A2($elm$json$Json$Decode$decodeString, $elm$json$Json$Decode$string, rawsource);
					if (!_v4.$) {
						var source = _v4.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{gO: source}));
					} else {
						var err = _v4.a;
						return A2(
							doerr,
							'gotsource decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'gotsource http',
						$author$project$Util$unwraperror(err));
				}
			case 4:
				if (!msg.a.$) {
					var rawperm = msg.a.a;
					var _v5 = A2($elm$json$Json$Decode$decodeString, $elm$json$Json$Decode$bool, rawperm);
					if (!_v5.$) {
						var perms = _v5.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{j2: perms}));
					} else {
						var err = _v5.a;
						return A2(
							doerr,
							'getpermissions decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'getpermissions http',
						$author$project$Util$unwraperror(err));
				}
			case 6:
				if (!msg.a.$) {
					var rawdata = msg.a.a;
					var _v6 = A2($elm$json$Json$Decode$decodeString, $author$project$Plotter$seriesdecoder, rawdata);
					if (!_v6.$) {
						var val = _v6.a;
						var newmodel = _Utils_update(
							model,
							{
								A: A2($author$project$Horizon$updateHorizonFromData, model.A, val),
								eT: val
							});
						return $author$project$Util$nocmd(newmodel);
					} else {
						var err = _v6.a;
						return $author$project$NavTabs$strseries(model.cN) ? $author$project$Util$nocmd(model) : $author$project$Util$nocmd(
							A3(
								$author$project$Tsinfo$addError,
								_Utils_update(
									model,
									{
										A: A2($author$project$Horizon$setStatusPlot, model.A, 3)
									}),
								'gotplotdata decode',
								$elm$json$Json$Decode$errorToString(err)));
					}
				} else {
					var err = msg.a.a;
					if (err.$ === 3) {
						var code = err.a;
						return (code === 404) ? $author$project$Util$nocmd(
							_Utils_update(
								model,
								{
									ed: true,
									A: A2($author$project$Horizon$setStatusPlot, model.A, 3)
								})) : $author$project$Util$nocmd(
							A3(
								$author$project$Tsinfo$addError,
								_Utils_update(
									model,
									{
										A: A2($author$project$Horizon$setStatusPlot, model.A, 3)
									}),
								'gotplotdata decode',
								$author$project$Util$unwraperror(err)));
					} else {
						return $author$project$Util$nocmd(
							A3(
								$author$project$Tsinfo$addError,
								_Utils_update(
									model,
									{
										A: A2($author$project$Horizon$setStatusPlot, model.A, 3)
									}),
								'gotplotdata decode',
								$author$project$Util$unwraperror(err)));
					}
				}
			case 10:
				if (!msg.a.$) {
					var rawformula = msg.a.a;
					var _v8 = A2($elm$json$Json$Decode$decodeString, $author$project$Info$formuladecoder, rawformula);
					if (!_v8.$) {
						var resp = _v8.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{
									ft: A3($elm$core$Dict$insert, resp.kV, resp.ft, model.ft)
								}));
					} else {
						var e = _v8.a;
						return $author$project$Util$nocmd(model);
					}
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'gotformula http',
						$author$project$Util$unwraperror(error));
				}
			case 13:
				var level = msg.a;
				var depth = A2(
					$elm$core$Maybe$withDefault,
					0,
					$elm$core$String$toInt(level));
				var newmodel = _Utils_update(
					model,
					{hR: depth});
				return $author$project$Util$nocmd(newmodel);
			case 14:
				if (!msg.a.$) {
					var rawhascache = msg.a.a;
					var model_horizon = model.A;
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{
								A: _Utils_update(
									model_horizon,
									{
										fz: A2($elm$core$String$startsWith, 'true', rawhascache)
									})
							}));
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'hascache http',
						$author$project$Util$unwraperror(error));
				}
			case 15:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{cu: true}));
			case 17:
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{cu: false}),
					$author$project$Tsinfo$deletecache(model));
			case 16:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{cu: false}));
			case 18:
				if (!msg.a.$) {
					var model_horizon = model.A;
					var newmodel = _Utils_update(
						model,
						{
							A: _Utils_update(
								model_horizon,
								{d1: false})
						});
					return _Utils_Tuple2(
						newmodel,
						$elm$core$Platform$Cmd$batch(
							_List_fromArray(
								[
									$author$project$Tsinfo$gethascache(newmodel),
									$author$project$Tsinfo$getplot(newmodel),
									A4($author$project$Info$getidates, newmodel, 'series', $author$project$Tsinfo$InsertionDates, model.A.d1),
									A5($author$project$Info$getlog, model.bv, model.ao, model.kX, 'series', $author$project$Tsinfo$GotLog)
								])));
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'cachedeleted http',
						$author$project$Util$unwraperror(error));
				}
			case 19:
				if (!msg.a.$) {
					var rawpol = msg.a.a;
					if (rawpol === 'null\n') {
						return $author$project$Util$nocmd(model);
					} else {
						var _v10 = A2($elm$json$Json$Decode$decodeString, $author$project$Metadata$decodemeta, rawpol);
						if (!_v10.$) {
							var policy = _v10.a;
							return $author$project$Util$nocmd(
								_Utils_update(
									model,
									{dK: policy}));
						} else {
							var err = _v10.a;
							return A2(
								doerr,
								'gotcachepolicy decode',
								$elm$json$Json$Decode$errorToString(err));
						}
					}
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'gotcachepolicy http',
						$author$project$Util$unwraperror(error));
				}
			case 5:
				if (!msg.a.$) {
					var rawlog = msg.a.a;
					var _v11 = A2($elm$json$Json$Decode$decodeString, $author$project$Info$logdecoder, rawlog);
					if (!_v11.$) {
						var log = _v11.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{im: log}));
					} else {
						var err = _v11.a;
						return A2(
							doerr,
							'gotlog decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'gotlog http',
						$author$project$Util$unwraperror(error));
				}
			case 11:
				if (!msg.a.$) {
					var rawdates = msg.a.a;
					var _v12 = A2($elm$json$Json$Decode$decodeString, $author$project$Info$idatesdecoder, rawdates);
					if (!_v12.$) {
						var dates = _v12.a;
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{
									ki: $elm$core$List$length(dates) - 1,
									kN: $elm$core$Array$fromList(dates)
								}));
					} else {
						var err = _v12.a;
						return A2(
							doerr,
							'idates decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'idates http',
						$author$project$Util$unwraperror(error));
				}
			case 8:
				var val = msg.a;
				return A4($Gizra$elm_debouncer$Debouncer$Messages$update, $author$project$Tsinfo$update, $author$project$Tsinfo$updatedchangedidatebouncer, val, model);
			case 7:
				var strindex = msg.a;
				var index = A2(
					$elm$core$Maybe$withDefault,
					model.ki,
					$elm$core$String$toInt(strindex));
				var newmodel = _Utils_update(
					model,
					{ki: index});
				var _v13 = A2($elm$core$Array$get, index, model.kN);
				if (_v13.$ === 1) {
					return $author$project$Util$nocmd(model);
				} else {
					var date = _v13.a;
					return _Utils_Tuple2(
						newmodel,
						$author$project$Tsinfo$getplot(newmodel));
				}
			case 48:
				var direction = msg.a;
				if (!direction) {
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{kG: model.kG - 1}));
				} else {
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{kG: model.kG + 1}));
				}
			case 9:
				var value = msg.a;
				var comparedates = F2(
					function (d1, d2) {
						return _Utils_cmp(d1, d2) > 0;
					});
				var newarray = A2(
					$elm$core$Array$filter,
					comparedates(value),
					A2($elm$core$Array$map, $author$project$Util$cleanupdate, model.kN));
				var newindex = A2(
					$elm$core$Basics$max,
					0,
					$elm$core$Array$length(newarray) - 1);
				var newmodel = _Utils_update(
					model,
					{ki: newindex});
				return _Utils_Tuple2(
					newmodel,
					$author$project$Tsinfo$getplot(newmodel));
			case 20:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							ku: A2(
								$elm$core$Dict$map,
								F2(
									function (k, v) {
										return $author$project$Metadata$metavaltostring(v);
									}),
								model.g3),
							hI: true
						}));
			case 21:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							ku: $elm$core$Dict$empty,
							hI: false,
							iq: _Utils_Tuple2('', '')
						}));
			case 22:
				var key = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							ku: A2($elm$core$Dict$remove, key, model.ku)
						}));
			case 23:
				var key = msg.a;
				var value = msg.b;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							ku: A3($elm$core$Dict$insert, key, value, model.ku)
						}));
			case 25:
				var key = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							iq: _Utils_Tuple2(key, model.iq.b)
						}));
			case 24:
				var val = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							iq: _Utils_Tuple2(
								$author$project$Util$first(model.iq),
								val)
						}));
			case 26:
				if (($author$project$Util$first(model.iq) === '') || ($author$project$Util$snd(model.iq) === '')) {
					return $author$project$Util$nocmd(model);
				} else {
					var edited = A3(
						$elm$core$Dict$insert,
						$author$project$Util$first(model.iq),
						$author$project$Util$snd(model.iq),
						model.ku);
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{
								ku: edited,
								iq: _Utils_Tuple2('', '')
							}));
				}
			case 27:
				var decode = function (rawitem) {
					var _v15 = A2($elm$json$Json$Decode$decodeString, $author$project$Metadata$decodemetaval, rawitem);
					if (!_v15.$) {
						var item = _v15.a;
						return item;
					} else {
						var err = _v15.a;
						return $author$project$Metadata$MString(rawitem);
					}
				};
				var newmodel = _Utils_update(
					model,
					{
						g3: A2(
							$elm$core$Dict$map,
							F2(
								function (k, v) {
									return decode(v);
								}),
							model.ku)
					});
				return _Utils_Tuple2(
					newmodel,
					A3($author$project$Info$savemeta, newmodel, 'series', $author$project$Tsinfo$MetaSaved));
			case 28:
				if (!msg.a.$) {
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{
								ku: $elm$core$Dict$empty,
								hI: false,
								iq: _Utils_Tuple2('', '')
							}));
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'metasaved http',
						$author$project$Util$unwraperror(err));
				}
			case 29:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{kn: true}));
			case 30:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{kn: false}));
			case 31:
				return _Utils_Tuple2(
					model,
					A3($author$project$Info$delete, model, 'series', $author$project$Tsinfo$Deleted));
			case 32:
				if (!msg.a.$) {
					return _Utils_Tuple2(
						model,
						$elm$browser$Browser$Navigation$load(
							A3(
								$elm$url$Url$Builder$crossOrigin,
								model.bv,
								_List_fromArray(
									['tssearch']),
								_List_Nil)));
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'deletion failed',
						$author$project$Util$unwraperror(err));
				}
			case 33:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{lE: true}));
			case 36:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{iA: $elm$core$Maybe$Nothing, lE: false}));
			case 34:
				var name = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							iA: $elm$core$Maybe$Just(name)
						}));
			case 35:
				var cmd = function () {
					var _v16 = model.iA;
					if (_v16.$ === 1) {
						return $elm$core$Platform$Cmd$none;
					} else {
						var newname = _v16.a;
						return A4($author$project$Info$rename, model, newname, 'series', $author$project$Tsinfo$Renamed);
					}
				}();
				return _Utils_Tuple2(model, cmd);
			case 37:
				if (!msg.a.$) {
					var name = function () {
						var _v17 = model.iA;
						if (!_v17.$) {
							var newname = _v17.a;
							return newname;
						} else {
							return model.ao;
						}
					}();
					return _Utils_Tuple2(
						model,
						$elm$browser$Browser$Navigation$load(
							A3(
								$elm$url$Url$Builder$crossOrigin,
								model.bv,
								_List_fromArray(
									['tsinfo']),
								_List_fromArray(
									[
										A2($elm$url$Url$Builder$string, 'name', name)
									]))));
				} else {
					var err = msg.a.a;
					return A2(
						doerr,
						'renaming failed',
						$author$project$Util$unwraperror(err));
				}
			case 38:
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{$7: 'bi bi-check2'}),
					$elm$core$Platform$Cmd$batch(
						_List_fromArray(
							[
								$author$project$Tsinfo$copyToClipboard(model.ao),
								A2(
								$elm$core$Task$perform,
								$elm$core$Basics$always($author$project$Tsinfo$ResetClipboardClass),
								$elm$core$Process$sleep(1000))
							])));
			case 39:
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{$7: 'bi bi-clipboard'}));
			case 40:
				var hmsg = msg.a;
				var _v18 = A3($author$project$Horizon$updateHorizon, hmsg, $author$project$Tsinfo$convertMsg, model.A);
				var newhorizonmodel = _v18.a;
				var commands = _v18.b;
				var newmodel = _Utils_update(
					model,
					{A: newhorizonmodel});
				var _default = _Utils_Tuple2(newmodel, commands);
				var resetmodel = _Utils_update(
					newmodel,
					{aI: $elm$core$Maybe$Nothing, kH: $elm$core$Dict$empty, ih: $elm$core$Array$empty, bH: 0});
				var launchHistory = _List_fromArray(
					[
						A2(
						$elm$core$Task$perform,
						$elm$core$Basics$identity,
						$elm$core$Task$succeed(
							$author$project$Tsinfo$HistoryMode(model.b5)))
					]);
				switch (hmsg.$) {
					case 2:
						var fetch = hmsg.a;
						switch (fetch.$) {
							case 0:
								return _Utils_Tuple2(
									newmodel,
									$elm$core$Platform$Cmd$batch(
										_List_fromArray(
											[
												commands,
												$author$project$Tsinfo$getplot(newmodel)
											])));
							case 1:
								return _Utils_Tuple2(
									resetmodel,
									$elm$core$Platform$Cmd$batch(
										_List_fromArray(
											[
												commands,
												$author$project$Tsinfo$getplot(newmodel)
											])));
							default:
								var op = fetch.a;
								switch (op.$) {
									case 2:
										return _Utils_Tuple2(
											_Utils_update(
												resetmodel,
												{kN: $elm$core$Array$empty}),
											$elm$core$Platform$Cmd$batch(
												_Utils_ap(
													_List_fromArray(
														[
															commands,
															$author$project$Tsinfo$getplot(newmodel),
															A4($author$project$Info$getidates, newmodel, 'series', $author$project$Tsinfo$InsertionDates, model.A.d1)
														]),
													launchHistory)));
									case 1:
										return _Utils_Tuple2(
											resetmodel,
											$elm$core$Platform$Cmd$batch(
												_Utils_ap(
													_List_fromArray(
														[
															commands,
															$author$project$Tsinfo$getplot(newmodel)
														]),
													launchHistory)));
									default:
										return _Utils_Tuple2(
											resetmodel,
											$elm$core$Platform$Cmd$batch(
												_Utils_ap(
													_List_fromArray(
														[
															commands,
															$author$project$Tsinfo$getplot(newmodel)
														]),
													launchHistory)));
								}
						}
					case 1:
						return _Utils_Tuple2(resetmodel, commands);
					case 0:
						return _default;
					default:
						return _default;
				}
			case 41:
				var isChecked = msg.a;
				var newmodel = _Utils_update(
					model,
					{aI: $elm$core$Maybe$Nothing, b5: isChecked, kH: $elm$core$Dict$empty, ih: $elm$core$Array$empty, bH: 0});
				if (isChecked) {
					var _v22 = model.A.bW;
					if (_v22.$ === 1) {
						return $author$project$Util$nocmd(newmodel);
					} else {
						return _Utils_Tuple2(
							newmodel,
							$author$project$Tsinfo$getsomeidates(newmodel));
					}
				} else {
					return $author$project$Util$nocmd(newmodel);
				}
			case 42:
				var zoom = msg.a;
				var newZoom = A2(
					$author$project$Horizon$updateZoom,
					model.A,
					$author$project$Horizon$extractZoomDates(zoom));
				var rangeX = newZoom.de;
				var horizonmodel = model.A;
				if (model.b5) {
					if (rangeX.$ === 1) {
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{
									aI: $elm$core$Maybe$Nothing,
									kH: $elm$core$Dict$empty,
									A: _Utils_update(
										horizonmodel,
										{bW: $elm$core$Maybe$Nothing}),
									ih: $elm$core$Array$empty,
									bH: 0
								}));
					} else {
						var _v24 = rangeX.a;
						var minDate = _v24.a;
						var maxDate = _v24.b;
						var newmodel = _Utils_update(
							model,
							{
								aI: $elm$core$Maybe$Nothing,
								kH: $elm$core$Dict$empty,
								A: _Utils_update(
									horizonmodel,
									{
										bW: $elm$core$Maybe$Just(
											_Utils_Tuple2(minDate, maxDate))
									}),
								ih: $elm$core$Array$empty
							});
						return _Utils_Tuple2(
							newmodel,
							$author$project$Tsinfo$getsomeidates(newmodel));
					}
				} else {
					return $author$project$Util$nocmd(
						_Utils_update(
							model,
							{
								A: _Utils_update(
									horizonmodel,
									{bW: newZoom.de, e_: newZoom.cl})
							}));
				}
			case 43:
				var panIsActive = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{eD: panIsActive}));
			case 44:
				if (!msg.a.$) {
					var rawdates = msg.a.a;
					var _v25 = A2($elm$json$Json$Decode$decodeString, $author$project$Info$idatesdecoder, rawdates);
					if (!_v25.$) {
						var dates = _v25.a;
						var nbRevisions = $elm$core$List$length(dates);
						var lasts = A2(
							$author$project$Tsinfo$lastDates,
							dates,
							A2($elm$core$Maybe$withDefault, 0, model.aM));
						var newmodel = _Utils_update(
							model,
							{
								kG: $elm$core$List$length(lasts) - 1,
								ej: $elm$core$Array$fromList(dates),
								ih: $elm$core$Array$fromList(lasts),
								bH: nbRevisions
							});
						return _Utils_Tuple2(
							newmodel,
							A2($author$project$Tsinfo$getVersions, model, lasts));
					} else {
						var err = _v25.a;
						return A2(
							doerr,
							'idates decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var error = msg.a.a;
					return A2(
						doerr,
						'idates http',
						$author$project$Util$unwraperror(error));
				}
			case 45:
				if (!msg.b.$) {
					var idate = msg.a;
					var rawdata = msg.b.a;
					var _v26 = A2($elm$json$Json$Decode$decodeString, $author$project$Plotter$seriesdecoder, rawdata);
					if (!_v26.$) {
						var val = _v26.a;
						var newHistoryPlots = A3($elm$core$Dict$insert, idate, val, model.kH);
						return $author$project$Util$nocmd(
							_Utils_update(
								model,
								{kH: newHistoryPlots}));
					} else {
						var err = _v26.a;
						return $author$project$NavTabs$strseries(model.cN) ? $author$project$Util$nocmd(model) : A2(
							doerr,
							'gotplotdata decode',
							$elm$json$Json$Decode$errorToString(err));
					}
				} else {
					var err = msg.b.a;
					return A2(
						doerr,
						'gotplotdata error',
						$author$project$Util$unwraperror(err));
				}
			case 46:
				var val = msg.a;
				return A4($Gizra$elm_debouncer$Debouncer$Messages$update, $author$project$Tsinfo$update, $author$project$Tsinfo$updatedChangedHistoryIdateDebouncer, val, model);
			case 47:
				var strindex = msg.a;
				var index = A2(
					$elm$core$Maybe$withDefault,
					model.kG,
					$elm$core$String$toInt(strindex));
				var newmodel = _Utils_eq(
					A2($elm$core$Array$get, index, model.ih),
					$elm$core$Maybe$Nothing) ? model : _Utils_update(
					model,
					{aI: $elm$core$Maybe$Nothing, kG: index});
				return $author$project$Util$nocmd(newmodel);
			case 49:
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{kH: $elm$core$Dict$empty, ih: $elm$core$Array$empty}),
					$author$project$Tsinfo$getsomeidates(model));
			case 50:
				var newMax = msg.a;
				var _v27 = $elm$core$String$toInt(newMax);
				if (_v27.$ === 1) {
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{aM: $elm$core$Maybe$Nothing}),
						$elm$core$Platform$Cmd$none);
				} else {
					var max = _v27.a;
					var newmodel = _Utils_update(
						model,
						{
							aM: $elm$core$Maybe$Just(max)
						});
					return _Utils_Tuple2(newmodel, $elm$core$Platform$Cmd$none);
				}
			case 51:
				var _v28 = model.aM;
				if (_v28.$ === 1) {
					return _Utils_Tuple2(model, $elm$core$Platform$Cmd$none);
				} else {
					var max = _v28.a;
					var lasts = A2(
						$author$project$Tsinfo$lastDates,
						$elm$core$Array$toList(model.ej),
						A2($elm$core$Maybe$withDefault, 0, model.aM));
					var newmodel = _Utils_update(
						model,
						{
							aI: $elm$core$Maybe$Nothing,
							kG: A2(
								$elm$core$Basics$min,
								max - 1,
								$elm$core$List$length(lasts) - 1),
							kH: $elm$core$Dict$empty,
							ih: $elm$core$Array$fromList(lasts),
							dL: max
						});
					return _Utils_Tuple2(
						newmodel,
						A2($author$project$Tsinfo$getVersions, model, lasts));
				}
			case 52:
				var data = msg.a;
				var _v29 = A2($elm$json$Json$Decode$decodeString, $author$project$Tsinfo$dataFromHoverDecoder, data);
				if (!_v29.$) {
					var datadict = _v29.a;
					var newmodel = _Utils_update(
						model,
						{
							aI: $elm$core$Maybe$Just(
								$author$project$Tsinfo$removeRedondants(datadict))
						});
					return $author$project$Util$nocmd(newmodel);
				} else {
					return $author$project$Util$nocmd(model);
				}
			case 53:
				var logcount = msg.a;
				return $author$project$Util$nocmd(
					_Utils_update(
						model,
						{
							kX: $elm$core$String$toInt(logcount)
						}));
			default:
				return _Utils_Tuple2(
					model,
					A5($author$project$Info$getlog, model.bv, model.ao, model.kX, 'series', $author$project$Tsinfo$GotLog));
		}
	});
var $author$project$Tsinfo$AddMetaItem = {$: 26};
var $author$project$Tsinfo$AskDeletion = {$: 29};
var $author$project$Tsinfo$AskRename = {$: 33};
var $author$project$Tsinfo$CancelDeletion = {$: 30};
var $author$project$Tsinfo$CancelRename = {$: 36};
var $author$project$Tsinfo$ConfirmDeletion = {$: 31};
var $author$project$Tsinfo$ConfirmRename = {$: 35};
var $author$project$Tsinfo$CopyNameToClipboard = {$: 38};
var $author$project$NavTabs$DeleteEvents = F3(
	function (confirmdeletion, canceldeletion, askdeletion) {
		return {jT: askdeletion, j0: canceldeletion, kd: confirmdeletion};
	});
var $author$project$Tsinfo$EditNewName = function (a) {
	return {$: 34, a: a};
};
var $author$project$Tsinfo$EditedValue = F2(
	function (a, b) {
		return {$: 23, a: a, b: b};
	});
var $author$project$NavTabs$FormulaCache = 3;
var $author$project$NavTabs$Logs = 1;
var $author$project$Tsinfo$LogsNumber = function (a) {
	return {$: 53, a: a};
};
var $author$project$Tsinfo$MetaEditAsked = {$: 20};
var $author$project$Tsinfo$MetaEditCancel = {$: 21};
var $author$project$NavTabs$MetaEvents = F8(
	function (metaeditasked, metaeditcancel, editedvalue, metaitemtodelete, newkey, newvalue, savemeta, addmetaitem) {
		return {jN: addmetaitem, kv: editedvalue, k2: metaeditasked, k3: metaeditcancel, k4: metaitemtodelete, le: newkey, lf: newvalue, lL: savemeta};
	});
var $author$project$Tsinfo$MetaItemToDelete = function (a) {
	return {$: 22, a: a};
};
var $author$project$Tsinfo$NewKey = function (a) {
	return {$: 25, a: a};
};
var $author$project$Tsinfo$NewValue = function (a) {
	return {$: 24, a: a};
};
var $author$project$Tsinfo$RenameEvents = F4(
	function (confirmrename, editnewname, cancelrename, askrename) {
		return {jU: askrename, j1: cancelrename, ke: confirmrename, kw: editnewname};
	});
var $author$project$Tsinfo$SaveMeta = {$: 27};
var $author$project$Tsinfo$SeeLogs = {$: 54};
var $author$project$Tsinfo$SwitchLevel = function (a) {
	return {$: 13, a: a};
};
var $author$project$Tsinfo$Tab = function (a) {
	return {$: 3, a: a};
};
var $author$project$NavTabs$UserMetadata = 2;
var $elm$html$Html$Attributes$stringProperty = F2(
	function (key, string) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$string(string));
	});
var $elm$html$Html$Attributes$class = $elm$html$Html$Attributes$stringProperty('className');
var $elm$html$Html$div = _VirtualDom_node('div');
var $NoRedInk$list_selection$List$Selection$Selection = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $NoRedInk$list_selection$List$Selection$fromList = function (items) {
	return A2($NoRedInk$list_selection$List$Selection$Selection, $elm$core$Maybe$Nothing, items);
};
var $elm$virtual_dom$VirtualDom$attribute = F2(
	function (key, value) {
		return A2(
			_VirtualDom_attribute,
			_VirtualDom_noOnOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlUri(value));
	});
var $elm$html$Html$Attributes$attribute = $elm$virtual_dom$VirtualDom$attribute;
var $elm$html$Html$Attributes$id = $elm$html$Html$Attributes$stringProperty('id');
var $elm$html$Html$a = _VirtualDom_node('a');
var $elm$html$Html$li = _VirtualDom_node('li');
var $elm$virtual_dom$VirtualDom$Normal = function (a) {
	return {$: 0, a: a};
};
var $elm$virtual_dom$VirtualDom$on = _VirtualDom_on;
var $elm$html$Html$Events$on = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$Normal(decoder));
	});
var $elm$html$Html$Events$onClick = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'click',
		$elm$json$Json$Decode$succeed(msg));
};
var $author$project$NavTabs$strtab = function (tablelayout) {
	switch (tablelayout) {
		case 0:
			return 'Plot';
		case 2:
			return 'Metadata';
		case 1:
			return 'Logs';
		default:
			return 'Cache';
	}
};
var $elm$virtual_dom$VirtualDom$text = _VirtualDom_text;
var $elm$html$Html$text = $elm$virtual_dom$VirtualDom$text;
var $author$project$NavTabs$maketab = F3(
	function (active, msg, tab) {
		var tabname = $author$project$NavTabs$strtab(tab);
		return A2(
			$elm$html$Html$li,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('nav-item')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$a,
					_Utils_ap(
						_List_fromArray(
							[
								$elm$html$Html$Events$onClick(
								msg(tab)),
								$elm$html$Html$Attributes$class('nav-link'),
								A2($elm$html$Html$Attributes$attribute, 'data-toggle', 'tab'),
								A2($elm$html$Html$Attributes$attribute, 'role', 'tab'),
								A2(
								$elm$html$Html$Attributes$attribute,
								'aria-selected',
								active ? 'true' : 'false'),
								$elm$html$Html$Attributes$id(tabname)
							]),
						active ? _List_fromArray(
							[
								$elm$html$Html$Attributes$class('active')
							]) : _List_Nil),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$div,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text(tabname + ' ')
								]))
						]))
				]));
	});
var $NoRedInk$list_selection$List$Selection$mapSelected = F2(
	function (mappers, _v0) {
		var selectedItem = _v0.a;
		var items = _v0.b;
		return A2(
			$NoRedInk$list_selection$List$Selection$Selection,
			A2($elm$core$Maybe$map, mappers.lR, selectedItem),
			A2(
				$elm$core$List$map,
				function (item) {
					return _Utils_eq(
						$elm$core$Maybe$Just(item),
						selectedItem) ? mappers.lR(item) : mappers.lG(item);
				},
				items));
	});
var $NoRedInk$list_selection$List$Selection$toList = function (_v0) {
	var items = _v0.b;
	return items;
};
var $elm$html$Html$ul = _VirtualDom_node('ul');
var $author$project$NavTabs$header = F2(
	function (msg, tabs) {
		return A2(
			$elm$html$Html$ul,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$id('tabs'),
					$elm$html$Html$Attributes$class('nav nav-tabs'),
					A2($elm$html$Html$Attributes$attribute, 'role', 'tablist')
				]),
			$NoRedInk$list_selection$List$Selection$toList(
				A2(
					$NoRedInk$list_selection$List$Selection$mapSelected,
					{
						lG: A2($author$project$NavTabs$maketab, false, msg),
						lR: A2($author$project$NavTabs$maketab, true, msg)
					},
					tabs)));
	});
var $author$project$Info$msgdoesnotexist = function (dtype) {
	return A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				$elm$html$Html$text(dtype + ' does not exists. Check your url.')
			]));
};
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $elm$core$List$head = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(x);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $NoRedInk$list_selection$List$Selection$selectBy = F2(
	function (query, _v0) {
		var original = _v0.a;
		var items = _v0.b;
		return A2(
			$NoRedInk$list_selection$List$Selection$Selection,
			A2(
				$elm$core$Maybe$withDefault,
				original,
				A2(
					$elm$core$Maybe$map,
					$elm$core$Maybe$Just,
					$elm$core$List$head(
						A2($elm$core$List$filter, query, items)))),
			items);
	});
var $NoRedInk$list_selection$List$Selection$select = F2(
	function (el, selection) {
		return A2(
			$NoRedInk$list_selection$List$Selection$selectBy,
			$elm$core$Basics$eq(el),
			selection);
	});
var $elm$html$Html$span = _VirtualDom_node('span');
var $elm$virtual_dom$VirtualDom$style = _VirtualDom_style;
var $elm$html$Html$Attributes$style = $elm$virtual_dom$VirtualDom$style;
var $author$project$NavTabs$tabcontents = function (items) {
	return A2(
		$elm$html$Html$span,
		_List_fromArray(
			[
				A2($elm$html$Html$Attributes$style, 'margin', '.1rem')
			]),
		items);
};
var $author$project$Horizon$Edit = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $author$project$Horizon$EditDateValidate = {$: 2};
var $author$project$Horizon$Frame = function (a) {
	return {$: 1, a: a};
};
var $author$project$Horizon$From = 0;
var $author$project$Horizon$To = 1;
var $author$project$Horizon$ToggleEdit = {$: 0};
var $elm$html$Html$button = _VirtualDom_node('button');
var $author$project$Horizon$Slide = function (a) {
	return {$: 1, a: a};
};
var $elm$html$Html$Attributes$boolProperty = F2(
	function (key, bool) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$bool(bool));
	});
var $elm$html$Html$Attributes$disabled = $elm$html$Html$Attributes$boolProperty('disabled');
var $elm$html$Html$i = _VirtualDom_node('i');
var $author$project$Horizon$buttonArrow = F4(
	function (convertmsg, disabled, step, className) {
		var direction = (step <= 0) ? 'left' : 'right';
		return A2(
			$elm$html$Html$button,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class(className),
					$elm$html$Html$Attributes$disabled(disabled),
					$elm$html$Html$Events$onClick(
					convertmsg(
						$author$project$Horizon$Frame(
							$author$project$Horizon$Slide(step))))
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$i,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A3($elm$core$String$replace, '{arrow}', direction, 'bi bi-arrow-{arrow}'))
						]),
					_List_Nil)
				]));
	});
var $author$project$Horizon$Option = function (a) {
	return {$: 2, a: a};
};
var $author$project$Horizon$ViewNoCache = {$: 2};
var $elm$html$Html$Attributes$checked = $elm$html$Html$Attributes$boolProperty('checked');
var $elm$html$Html$Attributes$for = $elm$html$Html$Attributes$stringProperty('htmlFor');
var $elm$html$Html$input = _VirtualDom_node('input');
var $elm$html$Html$label = _VirtualDom_node('label');
var $author$project$Horizon$cacheswitch = F2(
	function (model, convertmsg) {
		return model.fz ? A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('custom-control custom-switch')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$input,
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$attribute, 'type', 'checkbox'),
							$elm$html$Html$Attributes$class('custom-control-input'),
							$elm$html$Html$Attributes$id('cacheSwitch'),
							$elm$html$Html$Attributes$checked(!model.d1),
							$elm$html$Html$Attributes$disabled(model.T === 1),
							$elm$html$Html$Events$onClick(
							convertmsg(
								$author$project$Horizon$Fetch(
									$author$project$Horizon$Option($author$project$Horizon$ViewNoCache))))
						]),
					_List_Nil),
					A2(
					$elm$html$Html$label,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('custom-control-label'),
							$elm$html$Html$Attributes$for('cacheSwitch')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('cache')
						]))
				])) : A2($elm$html$Html$div, _List_Nil, _List_Nil);
	});
var $author$project$Horizon$showBounds = F2(
	function (bounds, label) {
		if (bounds.$ === 1) {
			return label + 'nothing';
		} else {
			var _v1 = bounds.a;
			var a = _v1.a;
			var b = _v1.b;
			return label + (a + (' - ' + b));
		}
	});
var $author$project$Horizon$showEdited = F2(
	function (edited, label) {
		return label + (A2($elm$core$Maybe$withDefault, 'nothing', edited.aA) + (' - ' + A2($elm$core$Maybe$withDefault, 'nothing', edited.aF)));
	});
var $author$project$Horizon$showFloats = F2(
	function (bounds, label) {
		if (bounds.$ === 1) {
			return label + 'nothing';
		} else {
			var _v1 = bounds.a;
			var a = _v1.a;
			var b = _v1.b;
			return label + ($elm$core$String$fromFloat(a) + (' - ' + $elm$core$String$fromFloat(b)));
		}
	});
var $author$project$Horizon$debugInfo = function (model) {
	return model.ff ? A2(
		$elm$html$Html$ul,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Date-Ref : ' + model.bc)
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showBounds, model.bh, 'horizon : '))
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showBounds, model.b0, 'data : '))
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showBounds, model.aD, 'query : '))
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showBounds, model.bW, 'zoomX : '))
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showFloats, model.e_, 'zoomY : '))
					])),
				A2(
				$elm$html$Html$li,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						A2($author$project$Horizon$showEdited, model.ax, 'edited : '))
					]))
			])) : A2($elm$html$Html$div, _List_Nil, _List_Nil);
};
var $author$project$Horizon$InferredFreq = function (a) {
	return {$: 1, a: a};
};
var $elm$json$Json$Decode$at = F2(
	function (fields, decoder) {
		return A3($elm$core$List$foldr, $elm$json$Json$Decode$field, decoder, fields);
	});
var $elm$html$Html$Events$targetChecked = A2(
	$elm$json$Json$Decode$at,
	_List_fromArray(
		['target', 'checked']),
	$elm$json$Json$Decode$bool);
var $elm$html$Html$Events$onCheck = function (tagger) {
	return A2(
		$elm$html$Html$Events$on,
		'change',
		A2($elm$json$Json$Decode$map, tagger, $elm$html$Html$Events$targetChecked));
};
var $author$project$Horizon$inferredfreqswitch = F2(
	function (model, convertmsg) {
		return A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('custom-control custom-switch')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$input,
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$attribute, 'type', 'checkbox'),
							$elm$html$Html$Attributes$class('custom-control-input'),
							$elm$html$Html$Attributes$id('flexSwitchCheckDefault'),
							$elm$html$Html$Attributes$checked(model.Y),
							$elm$html$Html$Attributes$disabled(model.T === 1),
							$elm$html$Html$Events$onCheck(
							function (b) {
								return convertmsg(
									$author$project$Horizon$Fetch(
										$author$project$Horizon$Option(
											$author$project$Horizon$InferredFreq(b))));
							})
						]),
					_List_Nil),
					A2(
					$elm$html$Html$label,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('custom-control-label'),
							$elm$html$Html$Attributes$for('flexSwitchCheckDefault')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('inferred freq')
						]))
				]));
	});
var $author$project$Horizon$loadingStatus = function (model) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class(
				function () {
					var _v0 = model.T;
					switch (_v0) {
						case 0:
							return 'none';
						case 1:
							return 'loading';
						case 2:
							return 'success';
						default:
							return 'failure';
					}
				}())
			]),
		_List_fromArray(
			[
				$elm$html$Html$text('•')
			]));
};
var $elm$html$Html$Events$alwaysStop = function (x) {
	return _Utils_Tuple2(x, true);
};
var $elm$virtual_dom$VirtualDom$MayStopPropagation = function (a) {
	return {$: 1, a: a};
};
var $elm$html$Html$Events$stopPropagationOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayStopPropagation(decoder));
	});
var $elm$html$Html$Events$targetValue = A2(
	$elm$json$Json$Decode$at,
	_List_fromArray(
		['target', 'value']),
	$elm$json$Json$Decode$string);
var $elm$html$Html$Events$onInput = function (tagger) {
	return A2(
		$elm$html$Html$Events$stopPropagationOn,
		'input',
		A2(
			$elm$json$Json$Decode$map,
			$elm$html$Html$Events$alwaysStop,
			A2($elm$json$Json$Decode$map, tagger, $elm$html$Html$Events$targetValue)));
};
var $elm$html$Html$Attributes$placeholder = $elm$html$Html$Attributes$stringProperty('placeholder');
var $author$project$Horizon$HorizonSelected = function (a) {
	return {$: 0, a: a};
};
var $author$project$Horizon$readHorizon = F2(
	function (model, key) {
		return $elm$json$Json$Decode$succeed(
			A2($elm$core$List$member, key, model.dB) ? $elm$core$Maybe$Just(key) : $elm$core$Maybe$Nothing);
	});
var $elm$html$Html$option = _VirtualDom_node('option');
var $elm$html$Html$Attributes$selected = $elm$html$Html$Attributes$boolProperty('selected');
var $elm$html$Html$Attributes$value = $elm$html$Html$Attributes$stringProperty('value');
var $author$project$Horizon$renderhorizon = F2(
	function (selectedhorizon, horizon) {
		return A2(
			$elm$html$Html$option,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$value(horizon),
					function () {
					switch (selectedhorizon.$) {
						case 0:
							return $elm$html$Html$Attributes$selected(horizon === 'All');
						case 1:
							return $elm$html$Html$Attributes$selected(horizon === '');
						default:
							var lab = selectedhorizon.a;
							return $elm$html$Html$Attributes$selected(
								_Utils_eq(horizon, lab));
					}
				}()
				]),
			_List_fromArray(
				[
					$elm$html$Html$text(horizon)
				]));
	});
var $elm$html$Html$select = _VirtualDom_node('select');
var $author$project$Horizon$selectHorizon = F2(
	function (model, convertmsg) {
		return A2(
			$elm$html$Html$select,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$Events$on,
					'change',
					A2(
						$elm$json$Json$Decode$map,
						function (mb) {
							return convertmsg(
								$author$project$Horizon$Frame(
									$author$project$Horizon$HorizonSelected(mb)));
						},
						A2(
							$elm$json$Json$Decode$andThen,
							$author$project$Horizon$readHorizon(model),
							$elm$html$Html$Events$targetValue)))
				]),
			A2(
				$elm$core$List$map,
				$author$project$Horizon$renderhorizon(model.A),
				_Utils_ap(
					_List_fromArray(
						['All']),
					_Utils_ap(
						model.dB,
						function () {
							var _v0 = model.A;
							if (_v0.$ === 1) {
								return _List_fromArray(
									['']);
							} else {
								return _List_Nil;
							}
						}()))));
	});
var $elm$html$Html$Attributes$type_ = $elm$html$Html$Attributes$stringProperty('type');
var $author$project$Horizon$TimeZoneSelected = function (a) {
	return {$: 0, a: a};
};
var $author$project$Horizon$renderTimeZone = F2(
	function (selectedhorizon, timeZone) {
		return A2(
			$elm$html$Html$option,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$value(timeZone),
					$elm$html$Html$Attributes$selected(
					_Utils_eq(selectedhorizon, timeZone))
				]),
			_List_fromArray(
				[
					$elm$html$Html$text(timeZone)
				]));
	});
var $author$project$Horizon$tzonedropdown = F2(
	function (model, convertmsg) {
		var decodeTimeZone = function (timeZone) {
			return $elm$json$Json$Decode$succeed(
				convertmsg(
					$author$project$Horizon$Fetch(
						$author$project$Horizon$Option(
							$author$project$Horizon$TimeZoneSelected(timeZone)))));
		};
		return A2(
			$elm$html$Html$select,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$Events$on,
					'change',
					A2($elm$json$Json$Decode$andThen, decodeTimeZone, $elm$html$Html$Events$targetValue)),
					$elm$html$Html$Attributes$disabled(model.T === 1)
				]),
			A2(
				$elm$core$List$map,
				$author$project$Horizon$renderTimeZone(model.ab),
				model.gW));
	});
var $author$project$Horizon$horizonview = F4(
	function (model, convertmsg, klass, tzaware) {
		var _v0 = $author$project$Horizon$viewdate(model);
		var min = _v0.a;
		var max = _v0.b;
		var fromZoom = _v0.c;
		var classZoom = fromZoom ? ' from-zoom' : '';
		return A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class(klass)
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('widget-loading-status')
						]),
					_List_fromArray(
						[
							$author$project$Horizon$loadingStatus(model)
						])),
					tzaware ? A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A2($author$project$Horizon$tzonedropdown, model, convertmsg)
						])) : A2($elm$html$Html$span, _List_Nil, _List_Nil),
					A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A4(
							$author$project$Horizon$buttonArrow,
							convertmsg,
							_Utils_eq(model.A, $author$project$Horizon$All),
							-1,
							'btn btn-outline-dark btn-sm')
						])),
					(!model.b1) ? A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('horizon-trinity read')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('widget-date' + classZoom),
									$elm$html$Html$Events$onClick(
									convertmsg(
										$author$project$Horizon$Internal($author$project$Horizon$ToggleEdit)))
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(min)
								])),
							A2(
							$elm$html$Html$div,
							_List_Nil,
							_List_fromArray(
								[
									A2($author$project$Horizon$selectHorizon, model, convertmsg)
								])),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('widget-date' + classZoom),
									$elm$html$Html$Events$onClick(
									convertmsg(
										$author$project$Horizon$Internal($author$project$Horizon$ToggleEdit)))
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(max)
								]))
						])) : A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('horizon-trinity write')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$input,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('widget-date' + classZoom),
									$elm$html$Html$Attributes$placeholder('yyyy-mm-dd'),
									$elm$html$Html$Attributes$type_('date'),
									$elm$html$Html$Attributes$value(
									A2($elm$core$Maybe$withDefault, '', model.ax.aA)),
									$elm$html$Html$Events$onInput(
									function (s) {
										return convertmsg(
											$author$project$Horizon$Internal(
												A2($author$project$Horizon$Edit, 0, s)));
									})
								]),
							_List_Nil),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('edit-buttons')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$button,
									_List_fromArray(
										[
											$elm$html$Html$Events$onClick(
											convertmsg(
												$author$project$Horizon$Frame($author$project$Horizon$EditDateValidate))),
											$elm$html$Html$Attributes$class('yes')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('✓')
										])),
									A2(
									$elm$html$Html$button,
									_List_fromArray(
										[
											$elm$html$Html$Events$onClick(
											convertmsg(
												$author$project$Horizon$Internal($author$project$Horizon$ToggleEdit))),
											$elm$html$Html$Attributes$class('no')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('x')
										]))
								])),
							A2(
							$elm$html$Html$input,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('widget-date' + classZoom),
									$elm$html$Html$Attributes$placeholder('yyyy-mm-dd'),
									$elm$html$Html$Attributes$type_('date'),
									$elm$html$Html$Attributes$value(
									A2($elm$core$Maybe$withDefault, '', model.ax.aF)),
									$elm$html$Html$Events$onInput(
									function (s) {
										return convertmsg(
											$author$project$Horizon$Internal(
												A2($author$project$Horizon$Edit, 1, s)));
									})
								]),
							_List_Nil)
						])),
					A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A4(
							$author$project$Horizon$buttonArrow,
							convertmsg,
							_Utils_eq(model.A, $author$project$Horizon$All),
							1,
							'btn btn-outline-dark btn-sm')
						])),
					A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A2($author$project$Horizon$inferredfreqswitch, model, convertmsg)
						])),
					A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A2($author$project$Horizon$cacheswitch, model, convertmsg)
						])),
					$author$project$Horizon$debugInfo(model)
				]));
	});
var $elm$html$Html$Attributes$href = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'href',
		_VirtualDom_noJavaScriptUri(url));
};
var $author$project$Info$tzawareseries = function (model) {
	return A2($author$project$Metadata$dget, 'tzaware', model.cN) === 'true';
};
var $author$project$Info$viewactionwidgets = F6(
	function (model, convertmsg, permalink, editor, pagetitle, bounds) {
		var queryParameters = function () {
			if (bounds.$ === 1) {
				return _List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao)
					]);
			} else {
				var _v4 = bounds.a;
				var min = _v4.a;
				var max = _v4.b;
				return editor ? _List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao),
						A2($elm$url$Url$Builder$string, 'startdate', min),
						A2($elm$url$Url$Builder$string, 'enddate', max)
					]) : _List_fromArray(
					[
						A2($elm$url$Url$Builder$string, 'name', model.ao)
					]);
			}
		}();
		var editorlabel = function () {
			var _v2 = model.jd;
			if (!_v2) {
				return editor ? 'edit values' : 'view values';
			} else {
				return 'show values';
			}
		}();
		return _List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('page-title')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(pagetitle)
					])),
				A4(
				$author$project$Horizon$horizonview,
				model.A,
				convertmsg,
				'action-center',
				$author$project$Info$tzawareseries(model)),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('action-right')
					]),
				function () {
					if (permalink.$ === 1) {
						return _List_Nil;
					} else {
						var link = permalink.a;
						return _List_fromArray(
							[link]);
					}
				}()),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('action-right')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$a,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$href(
								A3(
									$elm$url$Url$Builder$crossOrigin,
									model.bv,
									_List_fromArray(
										[
											editor ? 'tseditor' : 'tsinfo'
										]),
									queryParameters))
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(
								editor ? editorlabel : 'series info')
							])),
						function () {
						var _v1 = model.jd;
						if (_v1 === 1) {
							return A2(
								$elm$html$Html$a,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$href(
										A3(
											$elm$url$Url$Builder$crossOrigin,
											model.bv,
											_List_fromArray(
												['tsformula']),
											_List_fromArray(
												[
													A2($elm$url$Url$Builder$string, 'name', model.ao)
												])))
									]),
								_List_fromArray(
									[
										$elm$html$Html$text('edit formula')
									]));
						} else {
							return A2($elm$html$Html$span, _List_Nil, _List_Nil);
						}
					}()
					]))
			]);
	});
var $author$project$Tsinfo$CacheCancelDeletion = {$: 16};
var $author$project$Tsinfo$CacheConfirmDeletion = {$: 17};
var $author$project$Tsinfo$DeleteCache = {$: 15};
var $elm$html$Html$h2 = _VirtualDom_node('h2');
var $elm$core$Dict$isEmpty = function (dict) {
	if (dict.$ === -2) {
		return true;
	} else {
		return false;
	}
};
var $elm$html$Html$Attributes$title = $elm$html$Html$Attributes$stringProperty('title');
var $author$project$Tsinfo$viewcachepolicy = function (model) {
	var elt = function (name) {
		return A2(
			$elm$html$Html$li,
			_List_Nil,
			_List_fromArray(
				[
					$elm$html$Html$text(
					name + (' → ' + A2($author$project$Metadata$dget, name, model.dK)))
				]));
	};
	return A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$h2,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Policy')
					])),
				A2(
				$elm$html$Html$ul,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('highlight')
					]),
				A2(
					$elm$core$List$map,
					elt,
					_List_fromArray(
						['name', 'initial_revdate', 'look_before', 'look_after', 'revdate_rule', 'schedule_rule'])))
			]));
};
var $author$project$Info$logsNumberInput = F3(
	function (model, msgLogNumber, msgSeeLogs) {
		var logNumber = function () {
			var _v0 = model.kX;
			if (!_v0.$) {
				var number = _v0.a;
				return $elm$core$String$fromInt(number);
			} else {
				return '';
			}
		}();
		return A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					$elm$html$Html$text('Logs displayed : '),
					A2(
					$elm$html$Html$input,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('form-control-sm'),
							$elm$html$Html$Attributes$placeholder('Enter a valid number'),
							A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
							$elm$html$Html$Attributes$value(logNumber),
							$elm$html$Html$Events$onInput(msgLogNumber)
						]),
					_List_Nil),
					A2(
					$elm$html$Html$span,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text(' ')
						])),
					A2(
					$elm$html$Html$button,
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
							$elm$html$Html$Attributes$class('btn btn-primary btn-sm'),
							$elm$html$Html$Events$onClick(msgSeeLogs)
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('See more logs')
						]))
				]));
	});
var $elm$html$Html$Attributes$scope = $elm$html$Html$Attributes$stringProperty('scope');
var $elm$html$Html$table = _VirtualDom_node('table');
var $elm$html$Html$tbody = _VirtualDom_node('tbody');
var $elm$html$Html$td = _VirtualDom_node('td');
var $elm$html$Html$thead = _VirtualDom_node('thead');
var $author$project$Info$cleanMs = function (strDate) {
	return A3(
		$elm$core$String$replace,
		'T',
		' ',
		A2($elm$core$String$left, 19, strDate)) + (' ' + A2($elm$core$String$right, 6, strDate));
};
var $author$project$Info$metadicttostring = function (d) {
	var builditem = function (ab) {
		return $author$project$Util$first(ab) + (' → ' + $author$project$Metadata$metavaltostring(
			$author$project$Util$snd(ab)));
	};
	return A2(
		$elm$core$String$join,
		',',
		A2(
			$elm$core$List$map,
			builditem,
			$elm$core$Dict$toList(d)));
};
var $elm$html$Html$th = _VirtualDom_node('th');
var $elm$html$Html$tr = _VirtualDom_node('tr');
var $author$project$Info$viewlogentry = function (entry) {
	return A2(
		$elm$html$Html$tr,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$th,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$scope('row')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(
						$elm$core$String$fromInt(entry.i5))
					])),
				A2(
				$elm$html$Html$td,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(entry.hm)
					])),
				A2(
				$elm$html$Html$td,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						$author$project$Info$cleanMs(entry.ea))
					])),
				A2(
				$elm$html$Html$td,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(
						$author$project$Info$metadicttostring(entry.cN))
					]))
			]));
};
var $author$project$Info$viewlog = F4(
	function (model, showtitle, msgLogNumber, msgSeeLogs) {
		return ($elm$core$List$length(model.im) > 0) ? A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					showtitle ? A2(
					$elm$html$Html$h2,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('History Log')
						])) : A2($elm$html$Html$span, _List_Nil, _List_Nil),
					A3($author$project$Info$logsNumberInput, model, msgLogNumber, msgSeeLogs),
					A2(
					$elm$html$Html$table,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('table table-striped table-hover table-sm')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$thead,
							_List_Nil,
							_List_fromArray(
								[
									A2(
									$elm$html$Html$td,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$scope('col')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('#')
										])),
									A2(
									$elm$html$Html$td,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$scope('col')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('author')
										])),
									A2(
									$elm$html$Html$td,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$scope('col')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('date')
										])),
									A2(
									$elm$html$Html$td,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$scope('col')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('meta')
										]))
								])),
							A2(
							$elm$html$Html$tbody,
							_List_Nil,
							A2(
								$elm$core$List$map,
								$author$project$Info$viewlogentry,
								$elm$core$List$reverse(model.im)))
						]))
				])) : A2($elm$html$Html$div, _List_Nil, _List_Nil);
	});
var $author$project$Tsinfo$viewcache = function (model) {
	var deleteaction = model.A.fz ? (model.cu ? A2(
		$elm$html$Html$span,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$button,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('btn btn-warning'),
						A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
						$elm$html$Html$Events$onClick($author$project$Tsinfo$CacheCancelDeletion)
					]),
				_List_fromArray(
					[
						$elm$html$Html$text('cancel')
					])),
				A2(
				$elm$html$Html$span,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(' ')
					])),
				A2(
				$elm$html$Html$button,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('btn btn-danger'),
						A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
						$elm$html$Html$Events$onClick($author$project$Tsinfo$CacheConfirmDeletion)
					]),
				_List_fromArray(
					[
						$elm$html$Html$text('confirm')
					]))
			])) : A2(
		$elm$html$Html$button,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('btn btn-danger'),
				A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
				$elm$html$Html$Attributes$title('This is an irreversible operation.'),
				$elm$html$Html$Events$onClick($author$project$Tsinfo$DeleteCache)
			]),
		_List_fromArray(
			[
				$elm$html$Html$text('delete')
			]))) : A2($elm$html$Html$span, _List_Nil, _List_Nil);
	var cachecontrol = A2(
		$elm$html$Html$span,
		_List_Nil,
		_List_fromArray(
			[
				($elm$core$List$length(model.im) > 0) ? A4($author$project$Info$viewlog, model, false, $author$project$Tsinfo$LogsNumber, $author$project$Tsinfo$SeeLogs) : A2($elm$html$Html$span, _List_Nil, _List_Nil),
				$elm$core$Dict$isEmpty(model.dK) ? A2($elm$html$Html$span, _List_Nil, _List_Nil) : $author$project$Tsinfo$viewcachepolicy(model)
			]));
	var _v0 = model.jd;
	if (_v0 === 1) {
		return A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$h2,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('Cache'),
							A2(
							$elm$html$Html$span,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text(' ')
								])),
							deleteaction
						])),
					model.A.fz ? A2($elm$html$Html$span, _List_Nil, _List_Nil) : A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('There is no cache yet.')
						])),
					cachecontrol
				]));
	} else {
		return A2($elm$html$Html$div, _List_Nil, _List_Nil);
	}
};
var $author$project$Info$viewdeletion = F2(
	function (model, events) {
		return (model.gO !== 'local') ? A2($elm$html$Html$span, _List_Nil, _List_Nil) : (model.kn ? A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$button,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$type_('button'),
							$elm$html$Html$Attributes$class('btn btn-warning'),
							$elm$html$Html$Events$onClick(events.kd)
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('confirm')
						])),
					A2(
					$elm$html$Html$button,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$type_('button'),
							$elm$html$Html$Attributes$class('btn btn-success'),
							$elm$html$Html$Events$onClick(events.j0)
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('cancel')
						]))
				])) : A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$button,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$type_('button'),
							$elm$html$Html$Attributes$class('btn btn-danger'),
							$elm$html$Html$Events$onClick(events.jT)
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('delete')
						]))
				])));
	});
var $elm$html$Html$p = _VirtualDom_node('p');
var $author$project$Info$viewerrors = function (model) {
	return ($elm$core$List$length(model.hL) > 0) ? A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$h2,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Errors')
					])),
				A2(
				$elm$html$Html$div,
				_List_Nil,
				A2(
					$elm$core$List$map,
					function (x) {
						return A2(
							$elm$html$Html$p,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text(x)
								]));
					},
					model.hL))
			])) : A2($elm$html$Html$span, _List_Nil, _List_Nil);
};
var $author$project$Lisp$Atom = function (a) {
	return {$: 0, a: a};
};
var $author$project$Lisp$Expression = function (a) {
	return {$: 1, a: a};
};
var $author$project$Lisp$Bool = function (a) {
	return {$: 5, a: a};
};
var $author$project$Lisp$Float = function (a) {
	return {$: 3, a: a};
};
var $author$project$Lisp$Int = function (a) {
	return {$: 4, a: a};
};
var $author$project$Lisp$Keyword = function (a) {
	return {$: 1, a: a};
};
var $author$project$Lisp$Nil = {$: 6};
var $author$project$Lisp$String = function (a) {
	return {$: 2, a: a};
};
var $author$project$Lisp$Symbol = function (a) {
	return {$: 0, a: a};
};
var $elm$parser$Parser$Advanced$backtrackable = function (_v0) {
	var parse = _v0;
	return function (s0) {
		var _v1 = parse(s0);
		if (_v1.$ === 1) {
			var x = _v1.b;
			return A2($elm$parser$Parser$Advanced$Bad, false, x);
		} else {
			var a = _v1.b;
			var s1 = _v1.c;
			return A3($elm$parser$Parser$Advanced$Good, false, a, s1);
		}
	};
};
var $elm$parser$Parser$backtrackable = $elm$parser$Parser$Advanced$backtrackable;
var $elm$parser$Parser$ExpectingKeyword = function (a) {
	return {$: 9, a: a};
};
var $elm$parser$Parser$Advanced$keyword = function (_v0) {
	var kwd = _v0.a;
	var expecting = _v0.b;
	var progress = !$elm$core$String$isEmpty(kwd);
	return function (s) {
		var _v1 = A5($elm$parser$Parser$Advanced$isSubString, kwd, s.e, s.lK, s.j9, s.d);
		var newOffset = _v1.a;
		var newRow = _v1.b;
		var newCol = _v1.c;
		return (_Utils_eq(newOffset, -1) || (0 <= A3(
			$elm$parser$Parser$Advanced$isSubChar,
			function (c) {
				return $elm$core$Char$isAlphaNum(c) || (c === '_');
			},
			newOffset,
			s.d))) ? A2(
			$elm$parser$Parser$Advanced$Bad,
			false,
			A2($elm$parser$Parser$Advanced$fromState, s, expecting)) : A3(
			$elm$parser$Parser$Advanced$Good,
			progress,
			0,
			{j9: newCol, k: s.k, o: s.o, e: newOffset, lK: newRow, d: s.d});
	};
};
var $elm$parser$Parser$keyword = function (kwd) {
	return $elm$parser$Parser$Advanced$keyword(
		A2(
			$elm$parser$Parser$Advanced$Token,
			kwd,
			$elm$parser$Parser$ExpectingKeyword(kwd)));
};
var $author$project$Lisp$boolparser = $elm$parser$Parser$oneOf(
	_List_fromArray(
		[
			A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$succeed(true),
			$elm$parser$Parser$keyword('#t')),
			A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$succeed(false),
			$elm$parser$Parser$keyword('#f'))
		]));
var $elm$parser$Parser$ExpectingFloat = {$: 5};
var $elm$parser$Parser$Advanced$consumeBase = _Parser_consumeBase;
var $elm$parser$Parser$Advanced$consumeBase16 = _Parser_consumeBase16;
var $elm$parser$Parser$Advanced$bumpOffset = F2(
	function (newOffset, s) {
		return {j9: s.j9 + (newOffset - s.e), k: s.k, o: s.o, e: newOffset, lK: s.lK, d: s.d};
	});
var $elm$parser$Parser$Advanced$chompBase10 = _Parser_chompBase10;
var $elm$parser$Parser$Advanced$isAsciiCode = _Parser_isAsciiCode;
var $elm$parser$Parser$Advanced$consumeExp = F2(
	function (offset, src) {
		if (A3($elm$parser$Parser$Advanced$isAsciiCode, 101, offset, src) || A3($elm$parser$Parser$Advanced$isAsciiCode, 69, offset, src)) {
			var eOffset = offset + 1;
			var expOffset = (A3($elm$parser$Parser$Advanced$isAsciiCode, 43, eOffset, src) || A3($elm$parser$Parser$Advanced$isAsciiCode, 45, eOffset, src)) ? (eOffset + 1) : eOffset;
			var newOffset = A2($elm$parser$Parser$Advanced$chompBase10, expOffset, src);
			return _Utils_eq(expOffset, newOffset) ? (-newOffset) : newOffset;
		} else {
			return offset;
		}
	});
var $elm$parser$Parser$Advanced$consumeDotAndExp = F2(
	function (offset, src) {
		return A3($elm$parser$Parser$Advanced$isAsciiCode, 46, offset, src) ? A2(
			$elm$parser$Parser$Advanced$consumeExp,
			A2($elm$parser$Parser$Advanced$chompBase10, offset + 1, src),
			src) : A2($elm$parser$Parser$Advanced$consumeExp, offset, src);
	});
var $elm$parser$Parser$Advanced$finalizeInt = F5(
	function (invalid, handler, startOffset, _v0, s) {
		var endOffset = _v0.a;
		var n = _v0.b;
		if (handler.$ === 1) {
			var x = handler.a;
			return A2(
				$elm$parser$Parser$Advanced$Bad,
				true,
				A2($elm$parser$Parser$Advanced$fromState, s, x));
		} else {
			var toValue = handler.a;
			return _Utils_eq(startOffset, endOffset) ? A2(
				$elm$parser$Parser$Advanced$Bad,
				_Utils_cmp(s.e, startOffset) < 0,
				A2($elm$parser$Parser$Advanced$fromState, s, invalid)) : A3(
				$elm$parser$Parser$Advanced$Good,
				true,
				toValue(n),
				A2($elm$parser$Parser$Advanced$bumpOffset, endOffset, s));
		}
	});
var $elm$parser$Parser$Advanced$fromInfo = F4(
	function (row, col, x, context) {
		return A2(
			$elm$parser$Parser$Advanced$AddRight,
			$elm$parser$Parser$Advanced$Empty,
			A4($elm$parser$Parser$Advanced$DeadEnd, row, col, x, context));
	});
var $elm$core$String$toFloat = _String_toFloat;
var $elm$parser$Parser$Advanced$finalizeFloat = F6(
	function (invalid, expecting, intSettings, floatSettings, intPair, s) {
		var intOffset = intPair.a;
		var floatOffset = A2($elm$parser$Parser$Advanced$consumeDotAndExp, intOffset, s.d);
		if (floatOffset < 0) {
			return A2(
				$elm$parser$Parser$Advanced$Bad,
				true,
				A4($elm$parser$Parser$Advanced$fromInfo, s.lK, s.j9 - (floatOffset + s.e), invalid, s.k));
		} else {
			if (_Utils_eq(s.e, floatOffset)) {
				return A2(
					$elm$parser$Parser$Advanced$Bad,
					false,
					A2($elm$parser$Parser$Advanced$fromState, s, expecting));
			} else {
				if (_Utils_eq(intOffset, floatOffset)) {
					return A5($elm$parser$Parser$Advanced$finalizeInt, invalid, intSettings, s.e, intPair, s);
				} else {
					if (floatSettings.$ === 1) {
						var x = floatSettings.a;
						return A2(
							$elm$parser$Parser$Advanced$Bad,
							true,
							A2($elm$parser$Parser$Advanced$fromState, s, invalid));
					} else {
						var toValue = floatSettings.a;
						var _v1 = $elm$core$String$toFloat(
							A3($elm$core$String$slice, s.e, floatOffset, s.d));
						if (_v1.$ === 1) {
							return A2(
								$elm$parser$Parser$Advanced$Bad,
								true,
								A2($elm$parser$Parser$Advanced$fromState, s, invalid));
						} else {
							var n = _v1.a;
							return A3(
								$elm$parser$Parser$Advanced$Good,
								true,
								toValue(n),
								A2($elm$parser$Parser$Advanced$bumpOffset, floatOffset, s));
						}
					}
				}
			}
		}
	});
var $elm$parser$Parser$Advanced$number = function (c) {
	return function (s) {
		if (A3($elm$parser$Parser$Advanced$isAsciiCode, 48, s.e, s.d)) {
			var zeroOffset = s.e + 1;
			var baseOffset = zeroOffset + 1;
			return A3($elm$parser$Parser$Advanced$isAsciiCode, 120, zeroOffset, s.d) ? A5(
				$elm$parser$Parser$Advanced$finalizeInt,
				c.kO,
				c.kE,
				baseOffset,
				A2($elm$parser$Parser$Advanced$consumeBase16, baseOffset, s.d),
				s) : (A3($elm$parser$Parser$Advanced$isAsciiCode, 111, zeroOffset, s.d) ? A5(
				$elm$parser$Parser$Advanced$finalizeInt,
				c.kO,
				c.iG,
				baseOffset,
				A3($elm$parser$Parser$Advanced$consumeBase, 8, baseOffset, s.d),
				s) : (A3($elm$parser$Parser$Advanced$isAsciiCode, 98, zeroOffset, s.d) ? A5(
				$elm$parser$Parser$Advanced$finalizeInt,
				c.kO,
				c.hp,
				baseOffset,
				A3($elm$parser$Parser$Advanced$consumeBase, 2, baseOffset, s.d),
				s) : A6(
				$elm$parser$Parser$Advanced$finalizeFloat,
				c.kO,
				c.hN,
				c.h7,
				c.hP,
				_Utils_Tuple2(zeroOffset, 0),
				s)));
		} else {
			return A6(
				$elm$parser$Parser$Advanced$finalizeFloat,
				c.kO,
				c.hN,
				c.h7,
				c.hP,
				A3($elm$parser$Parser$Advanced$consumeBase, 10, s.e, s.d),
				s);
		}
	};
};
var $elm$parser$Parser$Advanced$float = F2(
	function (expecting, invalid) {
		return $elm$parser$Parser$Advanced$number(
			{
				hp: $elm$core$Result$Err(invalid),
				hN: expecting,
				hP: $elm$core$Result$Ok($elm$core$Basics$identity),
				kE: $elm$core$Result$Err(invalid),
				h7: $elm$core$Result$Ok($elm$core$Basics$toFloat),
				kO: invalid,
				iG: $elm$core$Result$Err(invalid)
			});
	});
var $elm$parser$Parser$float = A2($elm$parser$Parser$Advanced$float, $elm$parser$Parser$ExpectingFloat, $elm$parser$Parser$ExpectingFloat);
var $elm$parser$Parser$ExpectingSymbol = function (a) {
	return {$: 8, a: a};
};
var $elm$parser$Parser$Advanced$symbol = $elm$parser$Parser$Advanced$token;
var $elm$parser$Parser$symbol = function (str) {
	return $elm$parser$Parser$Advanced$symbol(
		A2(
			$elm$parser$Parser$Advanced$Token,
			str,
			$elm$parser$Parser$ExpectingSymbol(str)));
};
var $author$project$Lisp$floatparser = $elm$parser$Parser$oneOf(
	_List_fromArray(
		[
			A2(
			$elm$parser$Parser$keeper,
			A2(
				$elm$parser$Parser$ignorer,
				$elm$parser$Parser$succeed($elm$core$Basics$negate),
				$elm$parser$Parser$symbol('-')),
			$elm$parser$Parser$float),
			$elm$parser$Parser$float
		]));
var $elm$parser$Parser$ExpectingInt = {$: 1};
var $elm$parser$Parser$Advanced$int = F2(
	function (expecting, invalid) {
		return $elm$parser$Parser$Advanced$number(
			{
				hp: $elm$core$Result$Err(invalid),
				hN: expecting,
				hP: $elm$core$Result$Err(invalid),
				kE: $elm$core$Result$Err(invalid),
				h7: $elm$core$Result$Ok($elm$core$Basics$identity),
				kO: invalid,
				iG: $elm$core$Result$Err(invalid)
			});
	});
var $elm$parser$Parser$int = A2($elm$parser$Parser$Advanced$int, $elm$parser$Parser$ExpectingInt, $elm$parser$Parser$ExpectingInt);
var $author$project$Lisp$intparser = $elm$parser$Parser$oneOf(
	_List_fromArray(
		[
			A2(
			$elm$parser$Parser$keeper,
			A2(
				$elm$parser$Parser$ignorer,
				$elm$parser$Parser$succeed($elm$core$Basics$negate),
				$elm$parser$Parser$symbol('-')),
			$elm$parser$Parser$int),
			$elm$parser$Parser$int
		]));
var $elm$core$Set$Set_elm_builtin = $elm$core$Basics$identity;
var $elm$core$Set$empty = $elm$core$Dict$empty;
var $elm$parser$Parser$ExpectingVariable = {$: 7};
var $elm$core$Set$member = F2(
	function (key, _v0) {
		var dict = _v0;
		return A2($elm$core$Dict$member, key, dict);
	});
var $elm$parser$Parser$Advanced$varHelp = F7(
	function (isGood, offset, row, col, src, indent, context) {
		varHelp:
		while (true) {
			var newOffset = A3($elm$parser$Parser$Advanced$isSubChar, isGood, offset, src);
			if (_Utils_eq(newOffset, -1)) {
				return {j9: col, k: context, o: indent, e: offset, lK: row, d: src};
			} else {
				if (_Utils_eq(newOffset, -2)) {
					var $temp$isGood = isGood,
						$temp$offset = offset + 1,
						$temp$row = row + 1,
						$temp$col = 1,
						$temp$src = src,
						$temp$indent = indent,
						$temp$context = context;
					isGood = $temp$isGood;
					offset = $temp$offset;
					row = $temp$row;
					col = $temp$col;
					src = $temp$src;
					indent = $temp$indent;
					context = $temp$context;
					continue varHelp;
				} else {
					var $temp$isGood = isGood,
						$temp$offset = newOffset,
						$temp$row = row,
						$temp$col = col + 1,
						$temp$src = src,
						$temp$indent = indent,
						$temp$context = context;
					isGood = $temp$isGood;
					offset = $temp$offset;
					row = $temp$row;
					col = $temp$col;
					src = $temp$src;
					indent = $temp$indent;
					context = $temp$context;
					continue varHelp;
				}
			}
		}
	});
var $elm$parser$Parser$Advanced$variable = function (i) {
	return function (s) {
		var firstOffset = A3($elm$parser$Parser$Advanced$isSubChar, i.jl, s.e, s.d);
		if (_Utils_eq(firstOffset, -1)) {
			return A2(
				$elm$parser$Parser$Advanced$Bad,
				false,
				A2($elm$parser$Parser$Advanced$fromState, s, i.hN));
		} else {
			var s1 = _Utils_eq(firstOffset, -2) ? A7($elm$parser$Parser$Advanced$varHelp, i.h6, s.e + 1, s.lK + 1, 1, s.d, s.o, s.k) : A7($elm$parser$Parser$Advanced$varHelp, i.h6, firstOffset, s.lK, s.j9 + 1, s.d, s.o, s.k);
			var name = A3($elm$core$String$slice, s.e, s1.e, s.d);
			return A2($elm$core$Set$member, name, i.i3) ? A2(
				$elm$parser$Parser$Advanced$Bad,
				false,
				A2($elm$parser$Parser$Advanced$fromState, s, i.hN)) : A3($elm$parser$Parser$Advanced$Good, true, name, s1);
		}
	};
};
var $elm$parser$Parser$variable = function (i) {
	return $elm$parser$Parser$Advanced$variable(
		{hN: $elm$parser$Parser$ExpectingVariable, h6: i.h6, i3: i.i3, jl: i.jl});
};
var $author$project$Lisp$symbolparser = function () {
	var special_chars = $elm$core$String$toList('_-+*/.<>=');
	var accept_chars = function (c) {
		return A2($elm$core$List$member, c, special_chars);
	};
	return $elm$parser$Parser$variable(
		{
			h6: function (c) {
				return $elm$core$Char$isAlphaNum(c) || accept_chars(c);
			},
			i3: $elm$core$Set$empty,
			jl: function (c) {
				return $elm$core$Char$isLower(c) || accept_chars(c);
			}
		});
}();
var $author$project$Lisp$keywordparser = A2(
	$elm$parser$Parser$keeper,
	A2(
		$elm$parser$Parser$ignorer,
		$elm$parser$Parser$succeed($elm$core$Basics$identity),
		$elm$parser$Parser$symbol('#:')),
	$author$project$Lisp$symbolparser);
var $author$project$Lisp$quote = $elm$core$String$fromChar('\"');
var $author$project$Lisp$stringparser = function () {
	var quotechar = '\"';
	return A2(
		$elm$parser$Parser$keeper,
		A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$succeed($elm$core$Basics$identity),
			$elm$parser$Parser$symbol($author$project$Lisp$quote)),
		A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$variable(
				{
					h6: $elm$core$Basics$neq(quotechar),
					i3: $elm$core$Set$empty,
					jl: $elm$core$Basics$always(true)
				}),
			$elm$parser$Parser$symbol($author$project$Lisp$quote)));
}();
var $author$project$Lisp$atomparser = $elm$parser$Parser$oneOf(
	_List_fromArray(
		[
			A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$succeed($author$project$Lisp$Nil),
			$elm$parser$Parser$keyword('nil')),
			A2($elm$parser$Parser$map, $author$project$Lisp$Bool, $author$project$Lisp$boolparser),
			A2($elm$parser$Parser$map, $author$project$Lisp$Keyword, $author$project$Lisp$keywordparser),
			A2($elm$parser$Parser$map, $author$project$Lisp$Symbol, $author$project$Lisp$symbolparser),
			A2($elm$parser$Parser$map, $author$project$Lisp$String, $author$project$Lisp$stringparser),
			$elm$parser$Parser$backtrackable(
			A2($elm$parser$Parser$map, $author$project$Lisp$Int, $author$project$Lisp$intparser)),
			A2($elm$parser$Parser$map, $author$project$Lisp$Float, $author$project$Lisp$floatparser)
		]));
var $elm$parser$Parser$Advanced$loopHelp = F4(
	function (p, state, callback, s0) {
		loopHelp:
		while (true) {
			var _v0 = callback(state);
			var parse = _v0;
			var _v1 = parse(s0);
			if (!_v1.$) {
				var p1 = _v1.a;
				var step = _v1.b;
				var s1 = _v1.c;
				if (!step.$) {
					var newState = step.a;
					var $temp$p = p || p1,
						$temp$state = newState,
						$temp$callback = callback,
						$temp$s0 = s1;
					p = $temp$p;
					state = $temp$state;
					callback = $temp$callback;
					s0 = $temp$s0;
					continue loopHelp;
				} else {
					var result = step.a;
					return A3($elm$parser$Parser$Advanced$Good, p || p1, result, s1);
				}
			} else {
				var p1 = _v1.a;
				var x = _v1.b;
				return A2($elm$parser$Parser$Advanced$Bad, p || p1, x);
			}
		}
	});
var $elm$parser$Parser$Advanced$loop = F2(
	function (state, callback) {
		return function (s) {
			return A4($elm$parser$Parser$Advanced$loopHelp, false, state, callback, s);
		};
	});
var $elm$parser$Parser$Advanced$Done = function (a) {
	return {$: 1, a: a};
};
var $elm$parser$Parser$Advanced$Loop = function (a) {
	return {$: 0, a: a};
};
var $elm$parser$Parser$toAdvancedStep = function (step) {
	if (!step.$) {
		var s = step.a;
		return $elm$parser$Parser$Advanced$Loop(s);
	} else {
		var a = step.a;
		return $elm$parser$Parser$Advanced$Done(a);
	}
};
var $elm$parser$Parser$loop = F2(
	function (state, callback) {
		return A2(
			$elm$parser$Parser$Advanced$loop,
			state,
			function (s) {
				return A2(
					$elm$parser$Parser$map,
					$elm$parser$Parser$toAdvancedStep,
					callback(s));
			});
	});
var $elm$parser$Parser$Done = function (a) {
	return {$: 1, a: a};
};
var $elm$parser$Parser$Loop = function (a) {
	return {$: 0, a: a};
};
var $elm$parser$Parser$Advanced$spaces = $elm$parser$Parser$Advanced$chompWhile(
	function (c) {
		return (c === ' ') || ((c === '\n') || (c === '\r'));
	});
var $elm$parser$Parser$spaces = $elm$parser$Parser$Advanced$spaces;
var $Punie$elm_parser_extras$Parser$Extras$manyHelp = F2(
	function (p, vs) {
		return $elm$parser$Parser$oneOf(
			_List_fromArray(
				[
					A2(
					$elm$parser$Parser$keeper,
					$elm$parser$Parser$succeed(
						function (v) {
							return $elm$parser$Parser$Loop(
								A2($elm$core$List$cons, v, vs));
						}),
					A2($elm$parser$Parser$ignorer, p, $elm$parser$Parser$spaces)),
					A2(
					$elm$parser$Parser$map,
					function (_v0) {
						return $elm$parser$Parser$Done(
							$elm$core$List$reverse(vs));
					},
					$elm$parser$Parser$succeed(0))
				]));
	});
var $Punie$elm_parser_extras$Parser$Extras$many = function (p) {
	return A2(
		$elm$parser$Parser$loop,
		_List_Nil,
		$Punie$elm_parser_extras$Parser$Extras$manyHelp(p));
};
var $Punie$elm_parser_extras$Parser$Extras$between = F3(
	function (opening, closing, p) {
		return A2(
			$elm$parser$Parser$keeper,
			A2(
				$elm$parser$Parser$ignorer,
				A2(
					$elm$parser$Parser$ignorer,
					$elm$parser$Parser$succeed($elm$core$Basics$identity),
					opening),
				$elm$parser$Parser$spaces),
			A2(
				$elm$parser$Parser$ignorer,
				A2($elm$parser$Parser$ignorer, p, $elm$parser$Parser$spaces),
				closing));
	});
var $Punie$elm_parser_extras$Parser$Extras$parens = A2(
	$Punie$elm_parser_extras$Parser$Extras$between,
	$elm$parser$Parser$symbol('('),
	$elm$parser$Parser$symbol(')'));
function $author$project$Lisp$cyclic$lispparser() {
	return $Punie$elm_parser_extras$Parser$Extras$parens(
		A2(
			$elm$parser$Parser$keeper,
			$elm$parser$Parser$succeed($author$project$Lisp$Expression),
			$Punie$elm_parser_extras$Parser$Extras$many(
				$author$project$Lisp$cyclic$argsparser())));
}
function $author$project$Lisp$cyclic$argsparser() {
	return A2(
		$elm$parser$Parser$keeper,
		A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$succeed($elm$core$Basics$identity),
			$elm$parser$Parser$spaces),
		A2(
			$elm$parser$Parser$ignorer,
			$elm$parser$Parser$oneOf(
				_List_fromArray(
					[
						A2($elm$parser$Parser$map, $author$project$Lisp$Atom, $author$project$Lisp$atomparser),
						$elm$parser$Parser$lazy(
						function (_v0) {
							return $author$project$Lisp$cyclic$lispparser();
						})
					])),
			$elm$parser$Parser$spaces));
}
var $author$project$Lisp$lispparser = $author$project$Lisp$cyclic$lispparser();
$author$project$Lisp$cyclic$lispparser = function () {
	return $author$project$Lisp$lispparser;
};
var $author$project$Lisp$argsparser = $author$project$Lisp$cyclic$argsparser();
$author$project$Lisp$cyclic$argsparser = function () {
	return $author$project$Lisp$argsparser;
};
var $author$project$Lisp$parse = function (formula) {
	var _v0 = A2($elm$parser$Parser$run, $author$project$Lisp$lispparser, formula);
	if (!_v0.$) {
		var parsed = _v0.a;
		return $elm$core$Maybe$Just(parsed);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $elm$html$Html$pre = _VirtualDom_node('pre');
var $elm$html$Html$br = _VirtualDom_node('br');
var $elm$core$List$concat = function (lists) {
	return A3($elm$core$List$foldr, $elm$core$List$append, _List_Nil, lists);
};
var $author$project$Lisp$noop = 'no-such-operator';
var $author$project$Lisp$spaces = function (qty) {
	return A2($elm$core$String$repeat, 4 * qty, ' ');
};
var $elm$core$List$sum = function (numbers) {
	return A3($elm$core$List$foldl, $elm$core$Basics$add, 0, numbers);
};
var $elm$core$List$tail = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(xs);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Lisp$width = function (formula) {
	if (!formula.$) {
		var atom = formula.a;
		switch (atom.$) {
			case 0:
				var sym = atom.a;
				return $elm$core$String$length(sym);
			case 1:
				var kw = atom.a;
				return $elm$core$String$length(kw) + 2;
			case 2:
				var str = atom.a;
				return $elm$core$String$length(str) + 2;
			case 3:
				var flo = atom.a;
				return $elm$core$String$length(
					$elm$core$String$fromFloat(flo));
			case 4:
				var _int = atom.a;
				return $elm$core$String$length(
					$elm$core$String$fromInt(_int));
			case 5:
				var bo = atom.a;
				return 2;
			default:
				return 3;
		}
	} else {
		var expr = formula.a;
		return (1 + $elm$core$List$length(expr)) + $elm$core$List$sum(
			A2($elm$core$List$map, $author$project$Lisp$width, expr));
	}
};
var $elm$core$Tuple$pair = F2(
	function (a, b) {
		return _Utils_Tuple2(a, b);
	});
var $author$project$Lisp$zip = $elm$core$List$map2($elm$core$Tuple$pair);
var $author$project$Lisp$viewargs = F5(
	function (overrides, operator, indent, _break, argslist) {
		var wrapindent = F3(
			function (arg, iskw, html) {
				var dobreak = _break && (!iskw);
				return $elm$core$List$concat(
					_List_fromArray(
						[
							dobreak ? _List_fromArray(
							[
								A2($elm$html$Html$br, _List_Nil, _List_Nil)
							]) : _List_Nil,
							dobreak ? _List_fromArray(
							[
								A2(
								$elm$html$Html$span,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('w')
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(
										$author$project$Lisp$spaces(indent))
									]))
							]) : _List_fromArray(
							[
								A2(
								$elm$html$Html$span,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('w')
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(' ')
									]))
							]),
							html
						]));
			});
		var override = A2($elm$core$Dict$get, operator, overrides);
		var wrappedviewatom = F2(
			function (index, arg) {
				if (override.$ === 1) {
					return A3($author$project$Lisp$viewatom, overrides, indent, arg);
				} else {
					var func = override.a;
					return A3(
						func,
						index,
						arg,
						A2($author$project$Lisp$viewatom, overrides, indent));
				}
			});
		var iskeyword = function (arg) {
			if ((!arg.$) && (arg.a.$ === 1)) {
				return true;
			} else {
				return false;
			}
		};
		var keywordargs = A2(
			$elm$core$List$cons,
			false,
			A2($elm$core$List$map, iskeyword, argslist));
		return A2(
			$elm$core$List$map,
			function (_v5) {
				var index = _v5.a;
				var _v6 = _v5.b;
				var arg = _v6.a;
				var iskw = _v6.b;
				return A3(
					wrapindent,
					arg,
					iskw,
					A2(wrappedviewatom, index, arg));
			},
			A2(
				$author$project$Lisp$zip,
				A2(
					$elm$core$List$range,
					0,
					$elm$core$List$length(argslist)),
				A2($author$project$Lisp$zip, argslist, keywordargs)));
	});
var $author$project$Lisp$viewatom = F3(
	function (overrides, indent, atomorexpr) {
		if (atomorexpr.$ === 1) {
			var expr = atomorexpr.a;
			return A3($author$project$Lisp$viewexpr, overrides, indent, expr);
		} else {
			var atom = atomorexpr.a;
			switch (atom.$) {
				case 0:
					var sym = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('nv')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(sym)
								]))
						]);
				case 1:
					var kw = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('ss')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('#:' + kw)
								]))
						]);
				case 2:
					var str = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('s')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(
									_Utils_ap(
										$author$project$Lisp$quote,
										_Utils_ap(str, $author$project$Lisp$quote)))
								]))
						]);
				case 3:
					var flo = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('mf')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(
									$elm$core$String$fromFloat(flo))
								]))
						]);
				case 4:
					var _int = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('mf')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(
									$elm$core$String$fromInt(_int))
								]))
						]);
				case 5:
					var bool = atom.a;
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('mv')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(
									bool ? '#t' : '#f')
								]))
						]);
				default:
					return _List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('mv')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('nil')
								]))
						]);
			}
		}
	});
var $author$project$Lisp$viewexpr = F3(
	function (overrides, indent, exprs) {
		var operator = function () {
			var _v1 = A2(
				$elm$core$Maybe$withDefault,
				$author$project$Lisp$Atom(
					$author$project$Lisp$Symbol($author$project$Lisp$noop)),
				$elm$core$List$head(exprs));
			if (_v1.$ === 1) {
				return $author$project$Lisp$noop;
			} else {
				var atom = _v1.a;
				if (!atom.$) {
					var sym = atom.a;
					return sym;
				} else {
					return $author$project$Lisp$noop;
				}
			}
		}();
		var exprswidth = $elm$core$List$sum(
			A2($elm$core$List$map, $author$project$Lisp$width, exprs));
		var breakargs = exprswidth > 70;
		var newindent = indent + (breakargs ? 1 : 0);
		var argslist = function () {
			var _v0 = $elm$core$List$tail(exprs);
			if (_v0.$ === 1) {
				return _List_Nil;
			} else {
				var rest = _v0.a;
				return rest;
			}
		}();
		var hasargs = $elm$core$List$length(argslist) > 0;
		return $elm$core$List$concat(
			_List_fromArray(
				[
					_List_fromArray(
					[
						A2(
						$elm$html$Html$span,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('p')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('(')
							]))
					]),
					_List_fromArray(
					[
						A2(
						$elm$html$Html$span,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('nv')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(operator)
							]))
					]),
					$elm$core$List$concat(
					A5($author$project$Lisp$viewargs, overrides, operator, newindent, breakargs, argslist)),
					_List_fromArray(
					[
						A2(
						$elm$html$Html$span,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('p')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(')')
							]))
					])
				]));
	});
var $author$project$Lisp$view = F2(
	function (formula, overrides) {
		if (formula.$ === 1) {
			var expr = formula.a;
			return _List_fromArray(
				[
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('highlight')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$pre,
							_List_Nil,
							_Utils_ap(
								_List_fromArray(
									[
										A2($elm$html$Html$span, _List_Nil, _List_Nil)
									]),
								A3($author$project$Lisp$viewexpr, overrides, 0, expr)))
						]))
				]);
		} else {
			return _List_fromArray(
				[
					A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('This is not a formula.')
						]))
				]);
		}
	});
var $author$project$Info$getstring = function (fromatom) {
	if (fromatom.$ === 1) {
		return 'nope';
	} else {
		var atom = fromatom.a;
		if (atom.$ === 2) {
			var str = atom.a;
			return str;
		} else {
			return 'nope';
		}
	}
};
var $author$project$Info$linkname = F2(
	function (model, arg) {
		var name = $author$project$Info$getstring(arg);
		var nameurl = A3(
			$elm$url$Url$Builder$crossOrigin,
			model.bv,
			_List_fromArray(
				['tsinfo']),
			_List_fromArray(
				[
					A2($elm$url$Url$Builder$string, 'name', name)
				]));
		return _List_fromArray(
			[
				A2(
				$elm$html$Html$a,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('s'),
						$elm$html$Html$Attributes$href(nameurl)
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$span,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('s')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(
								_Utils_ap(
									$author$project$Lisp$quote,
									_Utils_ap(name, $author$project$Lisp$quote)))
							]))
					]))
			]);
	});
var $author$project$Info$viewintegrationnames = F4(
	function (model, index, arg, baseview) {
		switch (index) {
			case 0:
				return A2($author$project$Info$linkname, model, arg);
			case 1:
				return A2($author$project$Info$linkname, model, arg);
			default:
				return baseview(arg);
		}
	});
var $author$project$Info$viewseriesname = F4(
	function (model, index, arg, baseview) {
		if (!index) {
			return A2($author$project$Info$linkname, model, arg);
		} else {
			return baseview(arg);
		}
	});
var $author$project$Info$layoutFormula = F2(
	function (model, formula) {
		var viewparsed = function (parsed) {
			if (parsed.$ === 1) {
				return _List_Nil;
			} else {
				var parsedformula = parsed.a;
				return A2(
					$author$project$Lisp$view,
					parsedformula,
					$elm$core$Dict$fromList(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'series',
								$author$project$Info$viewseriesname(model)),
								_Utils_Tuple2(
								'integration',
								$author$project$Info$viewintegrationnames(model))
							])));
			}
		};
		return A2(
			$elm$html$Html$span,
			_List_Nil,
			viewparsed(
				$author$project$Lisp$parse(formula)));
	});
var $elm$html$Html$Attributes$max = $elm$html$Html$Attributes$stringProperty('max');
var $elm$html$Html$Attributes$min = $elm$html$Html$Attributes$stringProperty('min');
var $elm$html$Html$Attributes$step = function (n) {
	return A2($elm$html$Html$Attributes$stringProperty, 'step', n);
};
var $author$project$Info$viewformula = F2(
	function (model, toggleevent) {
		var displayformula = function () {
			var _v2 = A2($elm$core$Dict$get, model.hR, model.ft);
			if (!_v2.$) {
				var formula = _v2.a;
				return $elm$core$Maybe$Just(formula);
			} else {
				var _v3 = A2($elm$core$Dict$get, 0, model.ft);
				if (!_v3.$) {
					var formula = _v3.a;
					return $elm$core$Maybe$Just(formula);
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}
		}();
		var depthslider = function (formula) {
			var _v1 = model.hS;
			if (!_v1) {
				return _List_Nil;
			} else {
				var maxdepth = _v1;
				return _List_fromArray(
					[
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$title(
								'expand the formula to the desired depth (max ' + ($elm$core$String$fromInt(maxdepth + 1) + ')'))
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$input,
								_List_fromArray(
									[
										A2($elm$html$Html$Attributes$attribute, 'type', 'range'),
										$elm$html$Html$Attributes$min('0'),
										$elm$html$Html$Attributes$max(
										$elm$core$String$fromInt(maxdepth)),
										$elm$html$Html$Attributes$value(
										$elm$core$String$fromInt(model.hR)),
										$elm$html$Html$Attributes$step('1'),
										A2(
										$elm$html$Html$Attributes$style,
										'width',
										$elm$core$String$fromInt(model.hS * 5) + 'em'),
										$elm$html$Html$Attributes$id('expand-formula'),
										$elm$html$Html$Events$onInput(toggleevent)
									]),
								_List_Nil)
							]))
					]);
			}
		};
		if (displayformula.$ === 1) {
			return A2($elm$html$Html$div, _List_Nil, _List_Nil);
		} else {
			var formula = displayformula.a;
			return A2(
				$elm$html$Html$div,
				_List_Nil,
				_Utils_ap(
					_List_fromArray(
						[
							A2(
							$elm$html$Html$h2,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text('Formula')
								]))
						]),
					_Utils_ap(
						depthslider(formula),
						_List_fromArray(
							[
								A2($author$project$Info$layoutFormula, model, formula)
							]))));
		}
	});
var $author$project$Tsinfo$ChangedHistoryIdate = function (a) {
	return {$: 47, a: a};
};
var $author$project$Tsinfo$ChangedIdate = function (a) {
	return {$: 7, a: a};
};
var $author$project$Tsinfo$UpdateMax = {$: 51};
var $author$project$Tsinfo$ViewAllHistory = {$: 49};
var $author$project$Plotter$defaultAxis = {ek: $elm$core$Maybe$Nothing, iZ: $elm$core$Maybe$Nothing};
var $author$project$Plotter$defaultDateAxis = $author$project$Plotter$defaultAxis;
var $author$project$Plotter$defaultValueAxis = _Utils_update(
	$author$project$Plotter$defaultAxis,
	{
		ek: $elm$core$Maybe$Just('n')
	});
var $author$project$Plotter$defaultLayoutOptions = {
	fm: $elm$core$Maybe$Nothing,
	fB: $elm$core$Maybe$Nothing,
	kZ: {jW: 50, kS: 40, lA: 20, l1: 45},
	gG: '.\u00A0',
	l4: $elm$core$Maybe$Nothing,
	g8: $author$project$Plotter$defaultDateAxis,
	hc: $author$project$Plotter$defaultValueAxis
};
var $author$project$Plotter$defaultTraceOptions = {kW: $elm$core$Maybe$Nothing, ls: 1, lU: false, g4: true};
var $author$project$Plotter$Dates = function (a) {
	return {$: 0, a: a};
};
var $author$project$Horizon$extractDates = function (bounds) {
	if (bounds.$ === 1) {
		return $elm$core$Maybe$Nothing;
	} else {
		var _v1 = bounds.a;
		var x0 = _v1.a;
		var x1 = _v1.b;
		return $elm$core$Maybe$Just(
			$author$project$Plotter$Dates(
				{
					iZ: _List_fromArray(
						[x0, x1])
				}));
	}
};
var $author$project$Plotter$Values = function (a) {
	return {$: 1, a: a};
};
var $author$project$Horizon$extractValues = function (bounds) {
	if (bounds.$ === 1) {
		return $elm$core$Maybe$Nothing;
	} else {
		var _v1 = bounds.a;
		var x0 = _v1.a;
		var x1 = _v1.b;
		return $elm$core$Maybe$Just(
			$author$project$Plotter$Values(
				{
					iZ: _List_fromArray(
						[x0, x1])
				}));
	}
};
var $elm$html$Html$Attributes$hidden = $elm$html$Html$Attributes$boolProperty('hidden');
var $author$project$Tsinfo$ChangeMaxRevs = function (a) {
	return {$: 50, a: a};
};
var $author$project$Tsinfo$extractMax = function (max) {
	if (max.$ === 1) {
		return '';
	} else {
		var nb = max.a;
		return $elm$core$String$fromInt(nb);
	}
};
var $author$project$Tsinfo$historyInput = function (model) {
	return (model.bH > 0) ? A2(
		$elm$html$Html$span,
		_List_Nil,
		_List_fromArray(
			[
				$elm$html$Html$text(
				'   ' + ($elm$core$String$fromInt(model.bH) + ' revisions. Only showing the last ')),
				A2(
				$elm$html$Html$input,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$value(
						$author$project$Tsinfo$extractMax(model.aM)),
						$elm$html$Html$Attributes$class('form-control-sm'),
						A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
						A2($elm$html$Html$Attributes$style, 'width', '4em'),
						$elm$html$Html$Events$onInput($author$project$Tsinfo$ChangeMaxRevs)
					]),
				_List_Nil)
			])) : A2($elm$html$Html$div, _List_Nil, _List_Nil);
};
var $author$project$Tsinfo$historyModeSwitch = function (model) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('custom-control custom-switch')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$input,
				_List_fromArray(
					[
						A2($elm$html$Html$Attributes$attribute, 'type', 'checkbox'),
						$elm$html$Html$Attributes$class('custom-control-input'),
						$elm$html$Html$Attributes$id('historyModeCheckDefault'),
						$elm$html$Html$Attributes$checked(model.b5),
						$elm$html$Html$Events$onCheck($author$project$Tsinfo$HistoryMode)
					]),
				_List_Nil),
				A2(
				$elm$html$Html$label,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('custom-control-label'),
						$elm$html$Html$Attributes$for('historyModeCheckDefault')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text('History mode')
					]))
			]));
};
var $elm$core$Array$isEmpty = function (_v0) {
	var len = _v0.a;
	return !len;
};
var $author$project$Tsinfo$showHoverData = function (model) {
	var _v0 = model.aI;
	if (_v0.$ === 1) {
		return $elm$html$Html$text('Hover-data : Nothing');
	} else {
		var data = _v0.a;
		return $elm$html$Html$text('Hover-data, name : ' + data.ao);
	}
};
var $elm$core$Dict$values = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, valueList) {
				return A2($elm$core$List$cons, value, valueList);
			}),
		_List_Nil,
		dict);
};
var $elm$virtual_dom$VirtualDom$map = _VirtualDom_map;
var $elm$html$Html$map = $elm$virtual_dom$VirtualDom$map;
var $Gizra$elm_debouncer$Debouncer$Basic$ProvideInput = function (a) {
	return {$: 0, a: a};
};
var $Gizra$elm_debouncer$Debouncer$Basic$provideInput = $Gizra$elm_debouncer$Debouncer$Basic$ProvideInput;
var $Gizra$elm_debouncer$Debouncer$Messages$provideInput = $Gizra$elm_debouncer$Debouncer$Basic$provideInput;
var $author$project$Tsinfo$viewDatesRange = F4(
	function (insertionDates, dateIndex, debouncerMsg, dateMsg) {
		var numidates = $elm$core$Array$length(insertionDates);
		var currdate = function () {
			var _v0 = A2($elm$core$Array$get, dateIndex, insertionDates);
			if (_v0.$ === 1) {
				return '';
			} else {
				var date = _v0.a;
				return date;
			}
		}();
		return (numidates < 2) ? A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$input,
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$attribute, 'type', 'range'),
							$elm$html$Html$Attributes$class('form-control-range'),
							$elm$html$Html$Attributes$disabled(true)
						]),
					_List_Nil)
				])) : A2(
			$elm$html$Html$map,
			A2($elm$core$Basics$composeR, $Gizra$elm_debouncer$Debouncer$Messages$provideInput, debouncerMsg),
			A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						A2(
						$elm$html$Html$input,
						_List_fromArray(
							[
								A2($elm$html$Html$Attributes$attribute, 'type', 'range'),
								$elm$html$Html$Attributes$min('0'),
								$elm$html$Html$Attributes$max(
								$elm$core$String$fromInt(numidates - 1)),
								$elm$html$Html$Attributes$value(
								$elm$core$String$fromInt(dateIndex)),
								$elm$html$Html$Attributes$class('form-control-range'),
								$elm$html$Html$Attributes$title(currdate),
								$elm$html$Html$Events$onInput(dateMsg)
							]),
						_List_Nil)
					])));
	});
var $author$project$Info$buildOptions = F4(
	function (_default, lastIdate, currentIdate, idate) {
		return _Utils_update(
			_default,
			{
				kW: $elm$core$Maybe$Just(
					{
						ka: _Utils_eq(idate, lastIdate) ? 'rgb(0, 0, 0)' : ((_Utils_cmp(idate, currentIdate) < 0) ? 'rgb(20, 200, 20)' : (_Utils_eq(idate, currentIdate) ? 'rgb(0, 0, 250)' : 'rgb(204, 12, 20)'))
					}),
				ls: (_Utils_eq(idate, lastIdate) || _Utils_eq(idate, currentIdate)) ? 1 : 0.2,
				lU: (_Utils_eq(idate, lastIdate) || _Utils_eq(idate, currentIdate)) ? true : false
			});
	});
var $author$project$Info$buildTrace = F2(
	function (partialOption, _v0) {
		var idate = _v0.a;
		var series = _v0.b;
		return {
			la: 'lines',
			ao: $author$project$Info$cleanMs(idate),
			lu: partialOption(idate),
			mb: 'scatter',
			de: $elm$core$Dict$keys(series),
			cl: $elm$core$Dict$values(series)
		};
	});
var $author$project$Plotter$defaultConfigOptions = {
	fi: true,
	fj: false,
	f3: _List_fromArray(
		['sendDataToCloud']),
	gy: true,
	lU: false
};
var $elm_community$list_extra$List$Extra$last = function (items) {
	last:
	while (true) {
		if (!items.b) {
			return $elm$core$Maybe$Nothing;
		} else {
			if (!items.b.b) {
				var x = items.a;
				return $elm$core$Maybe$Just(x);
			} else {
				var rest = items.b;
				var $temp$items = rest;
				items = $temp$items;
				continue last;
			}
		}
	}
};
var $elm$virtual_dom$VirtualDom$node = function (tag) {
	return _VirtualDom_node(
		_VirtualDom_noScript(tag));
};
var $elm$html$Html$node = $elm$virtual_dom$VirtualDom$node;
var $elm$json$Json$Encode$list = F2(
	function (func, entries) {
		return _Json_wrap(
			A3(
				$elm$core$List$foldl,
				_Json_addEntry(func),
				_Json_emptyArray(0),
				entries));
	});
var $author$project$Plotter$encodeConfig = function (configOptions) {
	return $elm$json$Json$Encode$object(
		$elm$core$List$concat(
			_List_fromArray(
				[
					_List_fromArray(
					[
						_Utils_Tuple2(
						'displaylogo',
						$elm$json$Json$Encode$bool(configOptions.fj)),
						_Utils_Tuple2(
						'displayModeBar',
						$elm$json$Json$Encode$bool(configOptions.fi)),
						_Utils_Tuple2(
						'modeBarButtonsToRemove',
						A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, configOptions.f3)),
						_Utils_Tuple2(
						'responsive',
						$elm$json$Json$Encode$bool(configOptions.gy)),
						_Utils_Tuple2(
						'showlegend',
						$elm$json$Json$Encode$bool(configOptions.lU))
					])
				])));
};
var $author$project$Plotter$encodeRange = function (range) {
	if (!range.$) {
		var record = range.a;
		return _List_fromArray(
			[
				_Utils_Tuple2(
				'range',
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$string,
					_List_fromArray(
						[
							A2(
							$elm$core$Maybe$withDefault,
							'',
							$elm$core$List$head(record.iZ)),
							A2(
							$elm$core$Maybe$withDefault,
							'',
							$elm_community$list_extra$List$Extra$last(record.iZ))
						])))
			]);
	} else {
		var record = range.a;
		return _List_fromArray(
			[
				_Utils_Tuple2(
				'range',
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$float,
					_List_fromArray(
						[
							A2(
							$elm$core$Maybe$withDefault,
							0,
							$elm$core$List$head(record.iZ)),
							A2(
							$elm$core$Maybe$withDefault,
							0,
							$elm_community$list_extra$List$Extra$last(record.iZ))
						])))
			]);
	}
};
var $author$project$Plotter$encodeAxis = F2(
	function (axisName, axis) {
		return _List_fromArray(
			[
				_Utils_Tuple2(
				axisName,
				$elm$json$Json$Encode$object(
					$elm$core$List$concat(
						_List_fromArray(
							[
								function () {
								var _v0 = axis.iZ;
								if (_v0.$ === 1) {
									return _List_Nil;
								} else {
									var range = _v0.a;
									return $author$project$Plotter$encodeRange(range);
								}
							}(),
								function () {
								var _v1 = axis.ek;
								if (_v1.$ === 1) {
									return _List_Nil;
								} else {
									var format = _v1.a;
									return _List_fromArray(
										[
											_Utils_Tuple2(
											'hoverformat',
											$elm$json$Json$Encode$string(format))
										]);
								}
							}()
							]))))
			]);
	});
var $author$project$Plotter$encodeLayout = function (layoutOptions) {
	return $elm$json$Json$Encode$object(
		$elm$core$List$concat(
			_List_fromArray(
				[
					function () {
					var _v0 = layoutOptions.l4;
					if (_v0.$ === 1) {
						return _List_Nil;
					} else {
						var title = _v0.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'title',
								$elm$json$Json$Encode$string(title))
							]);
					}
				}(),
					A2($author$project$Plotter$encodeAxis, 'xaxis', layoutOptions.g8),
					A2($author$project$Plotter$encodeAxis, 'yaxis', layoutOptions.hc),
					function () {
					var _v1 = layoutOptions.fm;
					if (_v1.$ === 1) {
						return _List_Nil;
					} else {
						var drag = _v1.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'dragmode',
								$elm$json$Json$Encode$string(drag))
							]);
					}
				}(),
					function () {
					var _v2 = layoutOptions.fB;
					if (_v2.$ === 1) {
						return _List_Nil;
					} else {
						var height = _v2.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'height',
								$elm$json$Json$Encode$int(height))
							]);
					}
				}(),
					_List_fromArray(
					[
						_Utils_Tuple2(
						'separators',
						$elm$json$Json$Encode$string(layoutOptions.gG))
					]),
					_List_fromArray(
					[
						_Utils_Tuple2(
						'margin',
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									't',
									$elm$json$Json$Encode$int(layoutOptions.kZ.l1)),
									_Utils_Tuple2(
									'b',
									$elm$json$Json$Encode$int(layoutOptions.kZ.jW)),
									_Utils_Tuple2(
									'l',
									$elm$json$Json$Encode$int(layoutOptions.kZ.kS)),
									_Utils_Tuple2(
									'r',
									$elm$json$Json$Encode$int(layoutOptions.kZ.lA))
								])))
					])
				])));
};
var $elm_community$json_extra$Json$Encode$Extra$maybe = function (encoder) {
	return A2(
		$elm$core$Basics$composeR,
		$elm$core$Maybe$map(encoder),
		$elm$core$Maybe$withDefault($elm$json$Json$Encode$null));
};
var $author$project$Plotter$encodetrace = function (t) {
	return $elm$json$Json$Encode$object(
		$elm$core$List$concat(
			_List_fromArray(
				[
					_List_fromArray(
					[
						_Utils_Tuple2(
						'type',
						$elm$json$Json$Encode$string(t.mb)),
						_Utils_Tuple2(
						'name',
						$elm$json$Json$Encode$string(t.ao)),
						_Utils_Tuple2(
						'x',
						A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, t.de)),
						_Utils_Tuple2(
						'y',
						A2(
							$elm$json$Json$Encode$list,
							$elm_community$json_extra$Json$Encode$Extra$maybe($elm$json$Json$Encode$float),
							t.cl)),
						_Utils_Tuple2(
						'mode',
						$elm$json$Json$Encode$string(t.la)),
						_Utils_Tuple2(
						'showlegend',
						$elm$json$Json$Encode$bool(t.lu.lU)),
						_Utils_Tuple2(
						'opacity',
						$elm$json$Json$Encode$float(t.lu.ls))
					]),
					function () {
					var _v0 = t.lu.kW;
					if (_v0.$ === 1) {
						return _List_Nil;
					} else {
						var line = _v0.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'line',
								$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'color',
											$elm$json$Json$Encode$string(line.ka))
										])))
							]);
					}
				}(),
					function () {
					var _v1 = t.lu.g4;
					if (_v1) {
						return _List_Nil;
					} else {
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'visible',
								$elm$json$Json$Encode$string('legendonly'))
							]);
					}
				}()
				])));
};
var $author$project$Plotter$encodeplotargs = F4(
	function (div, data, layoutOptions, configOptions) {
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'div',
					$elm$json$Json$Encode$string(div)),
					_Utils_Tuple2(
					'data',
					A2($elm$json$Json$Encode$list, $author$project$Plotter$encodetrace, data)),
					_Utils_Tuple2(
					'layout',
					$author$project$Plotter$encodeLayout(layoutOptions)),
					_Utils_Tuple2(
					'config',
					$author$project$Plotter$encodeConfig(configOptions))
				]));
	});
var $author$project$Plotter$serializedPlotArgs = F4(
	function (div, data, layoutOptions, configOptions) {
		return A2(
			$elm$json$Json$Encode$encode,
			0,
			A4($author$project$Plotter$encodeplotargs, div, data, layoutOptions, configOptions));
	});
var $author$project$Info$viewHistoryGraph = function (model) {
	var lastIdate = A2(
		$elm$core$Maybe$withDefault,
		'',
		$elm_community$list_extra$List$Extra$last(
			$elm$core$Array$toList(model.ih)));
	var currentIdate = A2(
		$elm$core$Maybe$withDefault,
		'',
		A2($elm$core$Array$get, model.kG, model.ih));
	var partialOption = A3($author$project$Info$buildOptions, $author$project$Plotter$defaultTraceOptions, lastIdate, currentIdate);
	var listTraces = A2(
		$elm$core$List$map,
		$author$project$Info$buildTrace(partialOption),
		$elm$core$Dict$toList(model.kH));
	var historyArgs = A4($author$project$Plotter$serializedPlotArgs, 'plot-history', listTraces, $author$project$Plotter$defaultLayoutOptions, $author$project$Plotter$defaultConfigOptions);
	return A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$id('plot-history')
					]),
				_List_Nil),
				A3(
				$elm$html$Html$node,
				'plot-figure',
				_List_fromArray(
					[
						A2($elm$html$Html$Attributes$attribute, 'history-args', historyArgs)
					]),
				_List_Nil)
			]));
};
var $author$project$Plotter$Trace = F6(
	function (type_, name, x, y, mode, options) {
		return {la: mode, ao: name, lu: options, mb: type_, de: x, cl: y};
	});
var $author$project$Plotter$scatterplot = $author$project$Plotter$Trace('scatter');
var $elm$core$List$sortBy = _List_sortBy;
var $author$project$Info$viewHoverGraph = function (dictData) {
	var title = 'Application date : ' + dictData.ao;
	var sortedData = A2(
		$elm$core$List$sortBy,
		function ($) {
			return $.ea;
		},
		dictData.kh);
	var values = A2(
		$elm$core$List$map,
		function (dict) {
			return $elm$core$Maybe$Just(dict.me);
		},
		sortedData);
	var dates = A2(
		$elm$core$List$map,
		function (dict) {
			return dict.ea;
		},
		sortedData);
	var plot = A5($author$project$Plotter$scatterplot, dictData.ao, dates, values, 'lines', $author$project$Plotter$defaultTraceOptions);
	var hoverArgs = A4(
		$author$project$Plotter$serializedPlotArgs,
		'plot-hover',
		_List_fromArray(
			[plot]),
		_Utils_update(
			$author$project$Plotter$defaultLayoutOptions,
			{
				kZ: {jW: 110, kS: 40, lA: 20, l1: 45},
				l4: $elm$core$Maybe$Just(title)
			}),
		$author$project$Plotter$defaultConfigOptions);
	return A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$id('plot-hover')
					]),
				_List_Nil),
				A3(
				$elm$html$Html$node,
				'plot-figure',
				_List_fromArray(
					[
						A2($elm$html$Html$Attributes$attribute, 'hover-args', hoverArgs)
					]),
				_List_Nil)
			]));
};
var $author$project$Tsinfo$Center = 1;
var $author$project$Tsinfo$IterIDate = function (a) {
	return {$: 48, a: a};
};
var $author$project$Tsinfo$Left = 0;
var $author$project$Tsinfo$Next = 1;
var $author$project$Tsinfo$Prev = 0;
var $author$project$Tsinfo$Right = 2;
var $author$project$Tsinfo$formatIDate = F3(
	function (date, position, actif) {
		if (!actif) {
			return '';
		} else {
			var fdate = A3(
				$elm$core$String$replace,
				'T',
				' ',
				A2(
					$elm$core$String$left,
					14,
					A2($elm$core$String$dropLeft, 2, date)));
			switch (position) {
				case 1:
					return fdate;
				case 0:
					return '<< ' + fdate;
				default:
					return fdate + ' >>';
			}
		}
	});
var $author$project$Tsinfo$maybeDate = F2(
	function (model, idx) {
		var _v0 = A2($elm$core$Array$get, idx, model.ih);
		if (!_v0.$) {
			var date = _v0.a;
			return _Utils_Tuple2(date, true);
		} else {
			return _Utils_Tuple2('', false);
		}
	});
var $author$project$Tsinfo$viewWidgetIdates = function (model) {
	var idate = A2(
		$elm$core$Maybe$withDefault,
		'',
		A2($elm$core$Array$get, model.kG, model.ih));
	var _v0 = A2($author$project$Tsinfo$maybeDate, model, model.kG - 1);
	var previous = _v0.a;
	var pactive = _v0.b;
	var _v1 = A2($author$project$Tsinfo$maybeDate, model, model.kG + 1);
	var next = _v1.a;
	var nactive = _v1.b;
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('widget-idates')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_Utils_ap(
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('idate-adjacent'),
							$elm$html$Html$Attributes$title('previous date')
						]),
					pactive ? _List_fromArray(
						[
							$elm$html$Html$Attributes$class('idate-exists'),
							$elm$html$Html$Events$onClick(
							$author$project$Tsinfo$IterIDate(0))
						]) : _List_Nil),
				_List_fromArray(
					[
						$elm$html$Html$text(
						A3($author$project$Tsinfo$formatIDate, previous, 0, pactive))
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('idate-history')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(
						A3($author$project$Tsinfo$formatIDate, idate, 1, true))
					])),
				A2(
				$elm$html$Html$div,
				_Utils_ap(
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('idate-adjacent button'),
							$elm$html$Html$Attributes$title('next date')
						]),
					nactive ? _List_fromArray(
						[
							$elm$html$Html$Attributes$class('idate-exists'),
							$elm$html$Html$Events$onClick(
							$author$project$Tsinfo$IterIDate(1))
						]) : _List_Nil),
				_List_fromArray(
					[
						$elm$html$Html$text(
						A3($author$project$Tsinfo$formatIDate, next, 2, nactive))
					]))
			]));
};
var $author$project$Info$viewgraph = F6(
	function (name, tskeys, tsvalues, layoutOptions, options, inferredFreq) {
		var plot = A5(
			$author$project$Plotter$scatterplot,
			name,
			tskeys,
			tsvalues,
			inferredFreq ? 'lines+markers' : 'lines',
			options);
		var args = A4(
			$author$project$Plotter$serializedPlotArgs,
			'plot',
			_List_fromArray(
				[plot]),
			layoutOptions,
			$author$project$Plotter$defaultConfigOptions);
		return A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('plot')
						]),
					_List_Nil),
					A3(
					$elm$html$Html$node,
					'plot-figure',
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$attribute, 'args', args)
						]),
					_List_Nil)
				]));
	});
var $author$project$Tsinfo$viewplot = function (model) {
	var ts = model.eT;
	var defaultLayout = _Utils_update(
		$author$project$Plotter$defaultLayoutOptions,
		{
			fm: $elm$core$Maybe$Just(
				model.eD ? 'pan' : 'zoom'),
			g8: _Utils_update(
				$author$project$Plotter$defaultDateAxis,
				{
					iZ: $author$project$Horizon$extractDates(model.A.bW)
				}),
			hc: _Utils_update(
				$author$project$Plotter$defaultValueAxis,
				{
					iZ: $author$project$Horizon$extractValues(model.A.e_)
				})
		});
	return model.b5 ? A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				$author$project$Tsinfo$historyModeSwitch(model),
				A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Zoom to select a range or '),
						A2(
						$elm$html$Html$button,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('btn btn-warning btn-sm'),
								A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
								$elm$html$Html$Events$onClick($author$project$Tsinfo$ViewAllHistory)
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('view all history')
							])),
						$author$project$Tsinfo$historyInput(model),
						A2(
						$elm$html$Html$button,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('btn btn-primary btn-sm'),
								A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
								$elm$html$Html$Events$onClick($author$project$Tsinfo$UpdateMax),
								$elm$html$Html$Attributes$hidden(
								_Utils_eq(
									model.aM,
									$elm$core$Maybe$Just(model.dL)) || _Utils_eq(model.aM, $elm$core$Maybe$Nothing))
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Submit')
							]))
					])),
				A6(
				$author$project$Info$viewgraph,
				model.ao,
				$elm$core$Dict$keys(ts),
				$elm$core$Dict$values(ts),
				defaultLayout,
				$author$project$Plotter$defaultTraceOptions,
				model.A.Y),
				A4($author$project$Tsinfo$viewDatesRange, model.ih, model.kG, $author$project$Tsinfo$DebounceChangedHistoryIdate, $author$project$Tsinfo$ChangedHistoryIdate),
				$author$project$Tsinfo$viewWidgetIdates(model),
				$author$project$Info$viewHistoryGraph(model),
				$elm$core$Array$isEmpty(model.ih) ? A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('placeholder-text-hover')
					]),
				_List_Nil) : A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Place the mouse on the graph above to see\n                             the versions of one application date: ')
					])),
				model.ff ? A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						$author$project$Tsinfo$showHoverData(model)
					])) : A2($elm$html$Html$div, _List_Nil, _List_Nil),
				function () {
				var _v0 = model.aI;
				if (!_v0.$) {
					var data = _v0.a;
					return $author$project$Info$viewHoverGraph(data);
				} else {
					return $author$project$Info$viewHoverGraph(
						{kh: _List_Nil, ao: ''});
				}
			}()
			])) : A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				$author$project$Tsinfo$historyModeSwitch(model),
				A4($author$project$Tsinfo$viewDatesRange, model.kN, model.ki, $author$project$Tsinfo$DebounceChangedIdate, $author$project$Tsinfo$ChangedIdate),
				A6(
				$author$project$Info$viewgraph,
				model.ao,
				$elm$core$Dict$keys(ts),
				$elm$core$Dict$values(ts),
				defaultLayout,
				$author$project$Plotter$defaultTraceOptions,
				model.A.Y)
			]));
};
var $elm$html$Html$Attributes$size = function (n) {
	return A2(
		_VirtualDom_attribute,
		'size',
		$elm$core$String$fromInt(n));
};
var $author$project$Info$viewrenameaction = F2(
	function (model, events) {
		if (model.gO !== 'local') {
			return A2($elm$html$Html$span, _List_Nil, _List_Nil);
		} else {
			if (model.lE) {
				var value = function () {
					var _v1 = model.iA;
					if (_v1.$ === 1) {
						return model.ao;
					} else {
						var newname = _v1.a;
						return newname;
					}
				}();
				return A2(
					$elm$html$Html$div,
					_List_Nil,
					_List_fromArray(
						[
							A2(
							$elm$html$Html$input,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('form-control-sm'),
									$elm$html$Html$Attributes$size(80),
									$elm$html$Html$Attributes$type_('text'),
									$elm$html$Html$Attributes$placeholder('new name'),
									$elm$html$Html$Attributes$value(value),
									$elm$html$Html$Events$onInput(events.kw)
								]),
							_List_Nil),
							function () {
							var _v0 = model.iA;
							if (!_v0.$) {
								var newname = _v0.a;
								return A2(
									$elm$html$Html$button,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$type_('button'),
											$elm$html$Html$Attributes$class('btn btn-warning'),
											$elm$html$Html$Events$onClick(events.ke)
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('confirm')
										]));
							} else {
								return A2($elm$html$Html$span, _List_Nil, _List_Nil);
							}
						}(),
							A2(
							$elm$html$Html$button,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$type_('button'),
									$elm$html$Html$Attributes$class('btn btn-success'),
									$elm$html$Html$Events$onClick(events.j1)
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('cancel')
								]))
						]));
			} else {
				return A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							A2($elm$html$Html$Attributes$style, 'float', 'right')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$button,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$type_('button'),
									$elm$html$Html$Attributes$class('btn btn-primary'),
									$elm$html$Html$Events$onClick(events.jU)
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('rename')
								]))
						]));
			}
		}
	});
var $author$project$Info$viewtitle = F3(
	function (model, copyclass, copyevent) {
		var supervision = A2($author$project$Metadata$dget, 'supervision_status', model.cN);
		var _v0 = $author$project$Info$tzawareseries(model) ? _Utils_Tuple3('tzaware', 'badge-success', 'This series is time zone aware.') : _Utils_Tuple3('tznaive', 'badge-warning', 'This series is not associated with a time zone.');
		var tzaware = _v0.a;
		var tzbadge = _v0.b;
		var tztitle = _v0.c;
		return A2(
			$elm$html$Html$p,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('series-info')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$i,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(copyclass),
							$elm$html$Html$Events$onClick(copyevent)
						]),
					_List_Nil),
					A2(
					$elm$html$Html$span,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('badges-spacing')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('font-italic h4')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(' ' + (model.ao + ' '))
								])),
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('badge h4'),
									$elm$html$Html$Attributes$class(tzbadge),
									$elm$html$Html$Attributes$title(tztitle)
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(tzaware)
								])),
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('badge badge-info h4'),
									$elm$html$Html$Attributes$title('Supervision status of the series.')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(supervision)
								])),
							A2(
							$elm$html$Html$span,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('badge badge-secondary h4'),
									$elm$html$Html$Attributes$title('Name of the series source.')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(model.gO)
								]))
						]))
				]));
	});
var $elm$html$Html$form = _VirtualDom_node('form');
var $elm$html$Html$Events$alwaysPreventDefault = function (msg) {
	return _Utils_Tuple2(msg, true);
};
var $elm$virtual_dom$VirtualDom$MayPreventDefault = function (a) {
	return {$: 2, a: a};
};
var $elm$html$Html$Events$preventDefaultOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayPreventDefault(decoder));
	});
var $elm$html$Html$Events$onSubmit = function (msg) {
	return A2(
		$elm$html$Html$Events$preventDefaultOn,
		'submit',
		A2(
			$elm$json$Json$Decode$map,
			$elm$html$Html$Events$alwaysPreventDefault,
			$elm$json$Json$Decode$succeed(msg)));
};
var $author$project$Info$viewusermetaheader = F3(
	function (model, events, showtitle) {
		var editaction = model.j2 ? ((!model.hI) ? A2(
			$elm$html$Html$button,
			_List_fromArray(
				[
					A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
					$elm$html$Html$Attributes$class('btn btn-primary'),
					$elm$html$Html$Events$onClick(events.k2)
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('edit')
				])) : A2(
			$elm$html$Html$button,
			_List_fromArray(
				[
					A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
					$elm$html$Html$Attributes$class('btn btn-warning'),
					$elm$html$Html$Events$onClick(events.k3)
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('cancel')
				]))) : A2($elm$html$Html$span, _List_Nil, _List_Nil);
		return showtitle ? A2(
			$elm$html$Html$h2,
			_List_Nil,
			_List_fromArray(
				[
					$elm$html$Html$text('User Metadata'),
					A2(
					$elm$html$Html$span,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text(' ')
						])),
					editaction
				])) : A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[editaction]));
	});
var $author$project$Info$editusermeta = F3(
	function (model, events, showtitle) {
		var deletefields = F2(
			function (key, val) {
				return A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('form-row')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('col-3')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$input,
									_List_fromArray(
										[
											A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
											$elm$html$Html$Attributes$class('form-control'),
											$elm$html$Html$Attributes$disabled(true),
											$elm$html$Html$Attributes$value(key)
										]),
									_List_Nil)
								])),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('col-6')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$input,
									_List_fromArray(
										[
											A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
											$elm$html$Html$Attributes$class('form-control'),
											$elm$html$Html$Attributes$placeholder('value'),
											$elm$html$Html$Attributes$value(val),
											$elm$html$Html$Events$onInput(
											events.kv(key))
										]),
									_List_Nil)
								])),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('col')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$button,
									_List_fromArray(
										[
											A2($elm$html$Html$Attributes$attribute, 'type', 'button'),
											$elm$html$Html$Attributes$class('btn btn-warning'),
											$elm$html$Html$Events$onClick(
											events.k4(key))
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('delete')
										]))
								]))
						]));
			});
		var editfields = function (ab) {
			return A2(
				deletefields,
				$author$project$Util$first(ab),
				$author$project$Util$snd(ab));
		};
		var addfields = F2(
			function (key, val) {
				return A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('form-row')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('col-3')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$input,
									_List_fromArray(
										[
											A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
											$elm$html$Html$Attributes$class('form-control'),
											$elm$html$Html$Attributes$placeholder('key'),
											$elm$html$Html$Attributes$value(key),
											$elm$html$Html$Events$onInput(events.le)
										]),
									_List_Nil)
								])),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('col-6')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$input,
									_List_fromArray(
										[
											A2($elm$html$Html$Attributes$attribute, 'type', 'text'),
											$elm$html$Html$Attributes$class('form-control'),
											$elm$html$Html$Attributes$placeholder('value'),
											$elm$html$Html$Attributes$value(val),
											$elm$html$Html$Events$onInput(events.lf)
										]),
									_List_Nil)
								]))
						]));
			});
		return A2(
			$elm$html$Html$div,
			_List_Nil,
			_List_fromArray(
				[
					A3($author$project$Info$viewusermetaheader, model, events, showtitle),
					A2(
					$elm$html$Html$form,
					_List_fromArray(
						[
							$elm$html$Html$Events$onSubmit(events.lL)
						]),
					_Utils_ap(
						A2(
							$elm$core$List$map,
							editfields,
							$elm$core$Dict$toList(model.ku)),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$button,
								_List_fromArray(
									[
										A2($elm$html$Html$Attributes$attribute, 'type', 'submit'),
										$elm$html$Html$Attributes$class('btn btn-primary col-sm-10')
									]),
								_List_fromArray(
									[
										$elm$html$Html$text('save entries')
									]))
							]))),
					A2(
					$elm$html$Html$form,
					_List_fromArray(
						[
							$elm$html$Html$Events$onSubmit(events.jN)
						]),
					_List_fromArray(
						[
							A2(
							addfields,
							$author$project$Util$first(model.iq),
							$author$project$Util$snd(model.iq)),
							A2(
							$elm$html$Html$button,
							_List_fromArray(
								[
									A2($elm$html$Html$Attributes$attribute, 'type', 'submit'),
									$elm$html$Html$Attributes$class('btn btn-primary col-sm-10')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('add entry')
								]))
						]))
				]));
	});
var $author$project$Info$metatype = function (val) {
	if (val.$ === 1) {
		return 'virt';
	} else {
		var x = val.a;
		switch (x.$) {
			case 0:
				return 'str';
			case 1:
				return 'int';
			case 2:
				return 'float';
			case 3:
				return 'bool';
			case 4:
				return 'list';
			default:
				return 'null';
		}
	}
};
var $author$project$Info$viewusermeta = F3(
	function (model, events, showtitle) {
		if (model.hI) {
			return A3($author$project$Info$editusermeta, model, events, showtitle);
		} else {
			var elt = function (_v0) {
				var k = _v0.a;
				var v = _v0.b;
				return A2(
					$elm$html$Html$li,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text(
							k + (' → ' + ($author$project$Metadata$metavaltostring(v) + (' [' + ($author$project$Info$metatype(
								$elm$core$Maybe$Just(v)) + ']')))))
						]));
			};
			return (!$elm$core$Dict$isEmpty(model.g3)) ? A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						A3($author$project$Info$viewusermetaheader, model, events, showtitle),
						A2(
						$elm$html$Html$ul,
						_List_Nil,
						A2(
							$elm$core$List$map,
							elt,
							$elm$core$Dict$toList(model.g3)))
					])) : A2(
				$elm$html$Html$div,
				_List_Nil,
				_List_fromArray(
					[
						A3($author$project$Info$viewusermetaheader, model, events, showtitle),
						$elm$html$Html$text('No user-defined metadata yet.')
					]));
		}
	});
var $author$project$Tsinfo$view = function (model) {
	var tablist = function () {
		var _v2 = model.jd;
		if (!_v2) {
			return _List_fromArray(
				[0, 2, 1]);
		} else {
			return _List_fromArray(
				[0, 2, 3]);
		}
	}();
	var tabs = A2(
		$NoRedInk$list_selection$List$Selection$select,
		model.df,
		$NoRedInk$list_selection$List$Selection$fromList(tablist));
	var renameEvents = A4($author$project$Tsinfo$RenameEvents, $author$project$Tsinfo$ConfirmRename, $author$project$Tsinfo$EditNewName, $author$project$Tsinfo$CancelRename, $author$project$Tsinfo$AskRename);
	var metaEvents = A8($author$project$NavTabs$MetaEvents, $author$project$Tsinfo$MetaEditAsked, $author$project$Tsinfo$MetaEditCancel, $author$project$Tsinfo$EditedValue, $author$project$Tsinfo$MetaItemToDelete, $author$project$Tsinfo$NewKey, $author$project$Tsinfo$NewValue, $author$project$Tsinfo$SaveMeta, $author$project$Tsinfo$AddMetaItem);
	var maybeMedian = $elm$core$Maybe$Nothing;
	var head = A2($author$project$NavTabs$header, $author$project$Tsinfo$Tab, tabs);
	var deleteEvents = A3($author$project$NavTabs$DeleteEvents, $author$project$Tsinfo$ConfirmDeletion, $author$project$Tsinfo$CancelDeletion, $author$project$Tsinfo$AskDeletion);
	return A2(
		$elm$html$Html$div,
		_List_Nil,
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('main-content')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$div,
						_List_Nil,
						_Utils_ap(
							_List_fromArray(
								[
									A2(
									$elm$html$Html$span,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$class('tsinfo action-container')
										]),
									_Utils_ap(
										A6(
											$author$project$Info$viewactionwidgets,
											model,
											$author$project$Tsinfo$convertMsg,
											$elm$core$Maybe$Nothing,
											true,
											'Series Info',
											$author$project$Horizon$getFromToDates(model.A)),
										_List_fromArray(
											[
												A2($author$project$Info$viewdeletion, model, deleteEvents),
												A2($author$project$Info$viewrenameaction, model, renameEvents)
											]))),
									A3($author$project$Info$viewtitle, model, model.$7, $author$project$Tsinfo$CopyNameToClipboard)
								]),
							model.ed ? _List_fromArray(
								[
									$author$project$Info$msgdoesnotexist('Series')
								]) : _List_fromArray(
								[
									function () {
									var _v0 = model.df;
									switch (_v0) {
										case 0:
											return $author$project$NavTabs$strseries(model.cN) ? A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[head])) : A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														head,
														$author$project$NavTabs$tabcontents(
														_List_fromArray(
															[
																$author$project$Tsinfo$viewplot(model),
																A2($author$project$Info$viewformula, model, $author$project$Tsinfo$SwitchLevel)
															]))
													]));
										case 2:
											return A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														head,
														$author$project$NavTabs$tabcontents(
														_List_fromArray(
															[
																A3($author$project$Info$viewusermeta, model, metaEvents, false)
															]))
													]));
										case 1:
											return A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														head,
														$author$project$NavTabs$tabcontents(
														_List_fromArray(
															[
																function () {
																var _v1 = model.jd;
																if (!_v1) {
																	return A4($author$project$Info$viewlog, model, false, $author$project$Tsinfo$LogsNumber, $author$project$Tsinfo$SeeLogs);
																} else {
																	return A2($elm$html$Html$span, _List_Nil, _List_Nil);
																}
															}()
															]))
													]));
										default:
											return A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														head,
														$author$project$NavTabs$tabcontents(
														_List_fromArray(
															[
																$author$project$Tsinfo$viewcache(model)
															]))
													]));
									}
								}(),
									$author$project$Info$viewerrors(model)
								])))
					]))
			]));
};
var $elm$json$Json$Decode$index = _Json_decodeIndex;
var $author$project$Tsinfo$zoomPlot = _Platform_incomingPort(
	'zoomPlot',
	A2(
		$elm$json$Json$Decode$andThen,
		function (_v0) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (_v1) {
					return $elm$json$Json$Decode$succeed(
						_Utils_Tuple2(_v0, _v1));
				},
				A2(
					$elm$json$Json$Decode$index,
					1,
					A2(
						$elm$json$Json$Decode$andThen,
						function (_v0) {
							return A2(
								$elm$json$Json$Decode$andThen,
								function (_v1) {
									return $elm$json$Json$Decode$succeed(
										_Utils_Tuple2(_v0, _v1));
								},
								A2($elm$json$Json$Decode$index, 1, $elm$json$Json$Decode$float));
						},
						A2($elm$json$Json$Decode$index, 0, $elm$json$Json$Decode$float))));
		},
		A2(
			$elm$json$Json$Decode$index,
			0,
			A2(
				$elm$json$Json$Decode$andThen,
				function (_v0) {
					return A2(
						$elm$json$Json$Decode$andThen,
						function (_v1) {
							return $elm$json$Json$Decode$succeed(
								_Utils_Tuple2(_v0, _v1));
						},
						A2($elm$json$Json$Decode$index, 1, $elm$json$Json$Decode$string));
				},
				A2($elm$json$Json$Decode$index, 0, $elm$json$Json$Decode$string)))));
var $author$project$Tsinfo$main = $elm$browser$Browser$element(
	{
		kM: $author$project$Tsinfo$init,
		l_: function (_v0) {
			return $elm$core$Platform$Sub$batch(
				_List_fromArray(
					[
						$author$project$Tsinfo$zoomPlot($author$project$Tsinfo$FromZoom),
						$author$project$Tsinfo$dataFromHover($author$project$Tsinfo$NewDataFromHover),
						$author$project$Tsinfo$panActive($author$project$Tsinfo$NewDragMode),
						$author$project$Horizon$loadFromLocalStorage(
						function (s) {
							return $author$project$Tsinfo$convertMsg(
								$author$project$Horizon$FromLocalStorage(s));
						})
					]));
		},
		mc: $author$project$Tsinfo$update,
		mg: $author$project$Tsinfo$view
	});
_Platform_export({'Tsinfo':{'init':$author$project$Tsinfo$main(
	A2(
		$elm$json$Json$Decode$andThen,
		function (name) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (min) {
					return A2(
						$elm$json$Json$Decode$andThen,
						function (max) {
							return A2(
								$elm$json$Json$Decode$andThen,
								function (debug) {
									return A2(
										$elm$json$Json$Decode$andThen,
										function (baseurl) {
											return $elm$json$Json$Decode$succeed(
												{bv: baseurl, ff: debug, fY: max, f0: min, ao: name});
										},
										A2($elm$json$Json$Decode$field, 'baseurl', $elm$json$Json$Decode$string));
								},
								A2($elm$json$Json$Decode$field, 'debug', $elm$json$Json$Decode$string));
						},
						A2($elm$json$Json$Decode$field, 'max', $elm$json$Json$Decode$string));
				},
				A2($elm$json$Json$Decode$field, 'min', $elm$json$Json$Decode$string));
		},
		A2($elm$json$Json$Decode$field, 'name', $elm$json$Json$Decode$string)))(0)}});}(this));